"""H.D.D. file operations center — local Windows explorer (Patch 006).

Only selected files are acted on. Deletes request the Windows Recycle Bin,
never an unprompted permanent unlink/rmtree. ZIP extraction is bounded and
confined to a newly created directory.
"""
from __future__ import annotations

import ctypes
import hashlib
import os
from pathlib import Path, PurePosixPath
import shutil
import stat
import tempfile
import zipfile

from PySide6.QtCore import QDir, QFile, QIODevice, QSaveFile, Qt, QSize, QSettings, QModelIndex
from PySide6.QtWidgets import (
    QApplication, QDialog, QFileDialog, QFileSystemModel, QHBoxLayout,
    QInputDialog, QLabel, QLineEdit, QListView, QMessageBox,
    QPlainTextEdit, QPushButton, QTreeView, QHeaderView, QStackedWidget,
    QVBoxLayout, QWidget,
)
from hdd.ui.file_explorer_thumbnails import FileThumbnailDelegate


MAX_EDIT_BYTES = 2 * 1024 * 1024
MAX_ZIP_FILES = 1600
MAX_ZIP_BYTES = 600 * 1024 * 1024
MAX_ZIP_FILE_BYTES = 240 * 1024 * 1024


def _safe_name(name: str) -> bool:
    if not name or name in ('.', '..') or len(name) > 180:
        return False
    if name.rstrip(' .') != name:
        return False
    if any(c in name for c in '\\/:*?"<>|\x00'):
        return False
    base = name.split('.')[0].upper()
    return base not in ('CON', 'PRN', 'AUX', 'NUL') and not (
        len(base) == 4 and base[:3] in ('COM', 'LPT') and base[3] in '123456789'
    )


def _recycle_windows(path: Path):
    """Windows shell Recycle Bin, using FOF_ALLOWUNDO; no permanent fallback."""
    if os.name != 'nt':
        raise RuntimeError('A operação de Lixeira está disponível apenas no Windows.')
    if not path.exists():
        raise FileNotFoundError(path)
    if path == Path(path.anchor) or path.is_symlink():
        raise ValueError('Não é permitido excluir a raiz de unidade ou links.')
    if str(path).startswith('\\\\'):
        raise ValueError('A Lixeira desta versão não aceita caminhos de rede.')

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [('hwnd', ctypes.c_void_p), ('wFunc', ctypes.c_uint),
                    ('pFrom', ctypes.c_wchar_p), ('pTo', ctypes.c_wchar_p),
                    ('fFlags', ctypes.c_ushort), ('fAnyOperationsAborted', ctypes.c_int),
                    ('hNameMappings', ctypes.c_void_p),
                    ('lpszProgressTitle', ctypes.c_wchar_p)]

    source = str(path) + '\0\0'
    struct = SHFILEOPSTRUCTW()
    struct.wFunc = 3  # FO_DELETE
    struct.pFrom = source
    struct.fFlags = 0x0040 | 0x4000  # FOF_ALLOWUNDO | FOF_WANTNUKEWARNING
    shell = ctypes.windll.shell32
    shell.SHFileOperationW.argtypes = [ctypes.POINTER(SHFILEOPSTRUCTW)]
    shell.SHFileOperationW.restype = ctypes.c_int
    result = shell.SHFileOperationW(ctypes.byref(struct))
    if result or struct.fAnyOperationsAborted:
        raise OSError(f'O Windows cancelou ou não concluiu o envio à Lixeira ({result}).')


def _extract_zip_safely(source: Path, destination_parent: Path) -> Path:
    """Reject traversal/links/bombs/conflicts; extract into a new directory."""
    target = destination_parent / source.stem
    if target.exists() or target.is_symlink():
        raise FileExistsError('Já existe uma pasta com o nome do arquivo ZIP no destino.')
    with zipfile.ZipFile(source, 'r') as archive:
        members = archive.infolist()
        if len(members) > MAX_ZIP_FILES:
            raise ValueError('ZIP com arquivos demais para esta versão do explorador.')
        total = 0
        safe = []
        for member in members:
            name = member.filename
            if '\\' in name or name.startswith('/') or '\x00' in name or ':' in name:
                raise ValueError('ZIP contém um caminho inválido.')
            parts = PurePosixPath(name).parts
            if not parts or any(x in ('', '..', '.') or not _safe_name(x) for x in parts):
                raise ValueError('ZIP contém um caminho que não pode ser extraído com segurança.')
            mode = member.external_attr >> 16
            if stat.S_ISLNK(mode):
                raise ValueError('ZIP contém um link simbólico não permitido.')
            if member.flag_bits & 0x1:
                raise ValueError('ZIP protegido por senha não é suportado nesta versão.')
            if member.file_size > MAX_ZIP_FILE_BYTES:
                raise ValueError('ZIP contém um arquivo individual acima do limite.')
            total += member.file_size
            if total > MAX_ZIP_BYTES:
                raise ValueError('ZIP excede o limite de extração de 600 MB.')
            safe.append((member, parts))
        # Temp extraction on the SAME volume lets the final rename be atomic.
        with tempfile.TemporaryDirectory(prefix='.hdd_extract_', dir=destination_parent) as td:
            stage = Path(td) / 'content'
            stage.mkdir()
            for member, parts in safe:
                dest = stage.joinpath(*parts)
                if not dest.resolve().is_relative_to(stage.resolve()):
                    raise ValueError('Caminho fora do destino.')
                if member.is_dir():
                    dest.mkdir(parents=True, exist_ok=True)
                    continue
                dest.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(member, 'r') as origin, dest.open('wb') as output:
                    shutil.copyfileobj(origin, output, length=1024 * 1024)
            if target.exists():
                raise FileExistsError('A pasta de destino foi criada durante a extração.')
            stage.rename(target)
    return target


class TextEditorDialog(QDialog):
    """Edit small text files only; atomic save and external-change detection."""

    def __init__(self, filename: Path, parent=None):
        super().__init__(parent)
        self.path = filename
        self.raw = filename.read_bytes()
        if len(self.raw) > MAX_EDIT_BYTES or b'\0' in self.raw:
            raise ValueError('O editor aceita apenas arquivos de texto de até 2 MB.')
        try:
            if self.raw.startswith(b'\xef\xbb\xbf'):
                self.encoding = 'utf-8-sig'
                contents = self.raw.decode('utf-8-sig')
            else:
                self.encoding = 'utf-8'
                contents = self.raw.decode('utf-8')
        except UnicodeDecodeError as exc:
            raise ValueError('Este arquivo não está em UTF-8; abra-o em um editor compatível.') from exc
        self.line_endings = '\r\n' if b'\r\n' in self.raw else '\n'
        self.before = hashlib.sha256(self.raw).digest()
        self.setWindowTitle('H.D.D. // EDITOR — ' + filename.name)
        self.resize(820, 575)
        self.setStyleSheet('''
            QDialog {background: #081e30;}
            QLabel {color: #c6e8f5; font: 11px Consolas;}
            QPlainTextEdit {color: #e4f9ff; background: #061624;
                border: 1px solid #396c84; font: 13px Consolas; padding: 12px;}
            QPushButton {color: #d6f9ff; background: #153952;
                border: 1px solid #477e9c; padding: 10px;}
        ''')
        layout = QVBoxLayout(self)
        layout.addWidget(QLabel(str(filename)))
        self.editor = QPlainTextEdit(contents)
        self.editor.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        layout.addWidget(self.editor, 1)
        actions = QHBoxLayout()
        save = QPushButton('SALVAR ALTERAÇÕES')
        save.clicked.connect(self.save)
        actions.addWidget(save)
        cancel = QPushButton('VOLTAR')
        cancel.clicked.connect(self.reject)
        actions.addWidget(cancel)
        layout.addLayout(actions)

    def save(self):
        try:
            if not self.path.is_file() or hashlib.sha256(self.path.read_bytes()).digest() != self.before:
                raise RuntimeError('O arquivo mudou fora do editor. Salvar foi cancelado.')
            text = self.editor.toPlainText().replace('\n', self.line_endings)
            data = text.encode(self.encoding)
            if len(data) > MAX_EDIT_BYTES:
                raise ValueError('Texto acima do limite de 2 MB.')
            writer = QSaveFile(str(self.path))
            if not writer.open(QIODevice.OpenModeFlag.WriteOnly):
                raise OSError('Falha ao abrir o arquivo para gravação.')
            if writer.write(data) != len(data) or not writer.commit():
                writer.cancelWriting()
                raise OSError('Falha ao salvar o arquivo com segurança.')
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self, 'H.D.D. // Editor', str(exc))


class FileExplorerDialog(QDialog):
    """An integrated, real Windows file manager with explicit user actions."""

    def __init__(self, parent=None, on_code_file=None, on_integrate_file=None):
        super().__init__(parent)
        self.on_code_file=on_code_file
        self.on_integrate_file=on_integrate_file
        self._view_settings=QSettings("HDD-Project","HDD-System")
        self._showing_icons=False
        self._was_maximized=False
        self.setObjectName('hddExplorer')
        self.setWindowTitle('H.D.D. // EXPLORADOR DE ARQUIVOS')
        self.resize(1050, 670)
        self.setMinimumSize(770, 500)
        self.setStyleSheet('''
            QDialog#hddExplorer {background: #061a2a;}
            QLabel {color: #b2e9f6; font: 11px Consolas;}
            QLabel#explorerTitle {color: #e6fbff; font: 800 27px 'zero 5', 'Segoe UI';}
            QTreeView, QListView {background: #0b273b; color: #d5f1fc; alternate-background-color: #0f3045;
                border: 1px solid #3a7390; font: 12px 'Segoe UI'; selection-background-color: #245a78;}
            QHeaderView::section {background: #12374e; color: #dafaff; padding: 6px;
                border: 1px solid #2a5b73;}
            QListView::item {padding: 6px; border-radius: 5px;}
            QListView::item:selected {background: #215877; border: 1px solid #61a7c5;}
            QListView::item:hover {background: #163d57;}
            QLineEdit {color: #e9fbff; background: #091f30; border: 1px solid #3b7792;
                padding: 8px; font: 12px Consolas;}
            QPushButton {background: #133c56; border: 1px solid #487e99; border-radius: 3px;
                padding: 9px 11px; color: #d8f7ff; font: 700 11px 'Segoe UI';}
            QPushButton:hover {background: #256382;}
            QPushButton:disabled {color: #719aaa; background: #123047;}
        ''')
        self.current = Path.home()
        if not self.current.is_dir():
            self.current = Path.cwd()
        self.history = []
        self.setLayout(QVBoxLayout())
        layout = self.layout()
        layout.setContentsMargins(20, 17, 20, 18)
        layout.setSpacing(11)
        layout.addWidget(self._label('ARQUIVOS LOCAIS  //  FILE MANAGEMENT', 'explorerTitle'))
        layout.addWidget(QLabel('HELIOS  /  EXPLORADOR LOCAL  /  OPERAÇÕES CONFIRMADAS'))
        nav = QHBoxLayout()
        for text, fn in [('VOLTAR', self.go_back), ('ACIMA', self.go_up), ('INÍCIO', self.go_home)]:
            b = QPushButton(text)
            b.clicked.connect(fn)
            nav.addWidget(b)
        self.address = QLineEdit()
        self.address.returnPressed.connect(self.go_address)
        nav.addWidget(self.address, 1)
        go = QPushButton('IR')
        go.clicked.connect(self.go_address)
        nav.addWidget(go)
        layout.addLayout(nav)
        # Both views share ONE QFileSystemModel and one set of safe file actions.
        display_row=QHBoxLayout()
        self.view_hint=QLabel()
        display_row.addWidget(self.view_hint)
        display_row.addStretch(1)
        self.details_btn=QPushButton()
        self.details_btn.setCheckable(True)
        self.details_btn.clicked.connect(lambda:self.set_view_mode("details"))
        display_row.addWidget(self.details_btn)
        self.large_btn=QPushButton()
        self.large_btn.setCheckable(True)
        self.large_btn.clicked.connect(lambda:self.set_view_mode("large"))
        display_row.addWidget(self.large_btn)
        self.fullscreen_btn=QPushButton()
        self.fullscreen_btn.clicked.connect(self.toggle_fullscreen)
        display_row.addWidget(self.fullscreen_btn)
        layout.addLayout(display_row)
        self.model = QFileSystemModel(self)
        self.model.setFilter(QDir.Filter.AllDirs | QDir.Filter.Files |
                             QDir.Filter.NoDotAndDotDot | QDir.Filter.Hidden | QDir.Filter.System)
        self.model.setRootPath(str(self.current))
        self.tree = QTreeView()
        self.tree.setModel(self.model)
        self.tree.setAlternatingRowColors(True)
        self.tree.setUniformRowHeights(True)
        # A readable filename column, instead of the old ~100 px truncation.
        header=self.tree.header()
        header.setStretchLastSection(False)
        header.setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
        for col,width in ((1,118),(2,150),(3,170)):
            header.setSectionResizeMode(col,QHeaderView.ResizeMode.Interactive)
            self.tree.setColumnWidth(col,width)
        self.tree.setSelectionBehavior(QTreeView.SelectionBehavior.SelectRows)
        self.tree.setSelectionMode(QTreeView.SelectionMode.SingleSelection)
        self.tree.doubleClicked.connect(self.activate)
        self.icons=QListView()
        self.icons.setObjectName("hddExplorerLargeIcons")
        self.icons.setModel(self.model)
        self.icons.setViewMode(QListView.ViewMode.IconMode)
        self.icons.setFlow(QListView.Flow.LeftToRight)
        self.icons.setWrapping(True)
        self.icons.setResizeMode(QListView.ResizeMode.Adjust)
        self.icons.setLayoutMode(QListView.LayoutMode.Batched)
        self.icons.setBatchSize(75)
        self.icons.setMovement(QListView.Movement.Static)
        self.icons.setGridSize(QSize(172,163))
        self.icons.setIconSize(QSize(132,106))
        self.icons.setWordWrap(True)
        self.icons.setTextElideMode(Qt.TextElideMode.ElideMiddle)
        self.icons.setSpacing(6)
        self.icons.setUniformItemSizes(True)
        self.icons.setSelectionMode(QListView.SelectionMode.SingleSelection)
        self.icons.doubleClicked.connect(self.activate)
        self.thumb_delegate=FileThumbnailDelegate(self)
        self.icons.setItemDelegate(self.thumb_delegate)
        self.views=QStackedWidget()
        self.views.addWidget(self.tree)
        self.views.addWidget(self.icons)
        layout.addWidget(self.views, 1)
        actions = QHBoxLayout()
        for text, fn in (
            ('ABRIR', self.open_selection), ('EDITAR TEXTO', self.edit_selection),
            ('EDITOR CÓDIGO', self.edit_code_selection),
            ('NOVA PASTA', self.new_folder), ('RENOMEAR', self.rename_selection),
            ('COPIAR', self.copy_selection), ('MOVER', self.move_selection),
            ('LIXEIRA', self.recycle_selection), ('EXTRAIR ZIP', self.extract_selection),
        ):
            b = QPushButton(text)
            b.clicked.connect(fn)
            actions.addWidget(b)
        layout.addLayout(actions)
        integration=QHBoxLayout()
        send=QPushButton("ENVIAR ARQUIVO / PASTA À CENTRAL DE INTEGRAÇÕES  →")
        send.clicked.connect(self.integrate_selection)
        integration.addWidget(send)
        integration.addStretch()
        layout.addLayout(integration)
        self.status = QLabel('Ações de exclusão enviam à Lixeira do Windows; nenhum comando é executado automaticamente.')
        layout.addWidget(self.status)
        self._navigate(self.current, save=False)
        self.set_view_mode(str(self._view_settings.value("explorer_view_mode","details")),
                           remember=False)
        bridge=getattr(QApplication.instance(),"_hdd_language_bridge",None)
        if bridge is not None:
            bridge.changed.connect(lambda _lang:self._sync_view_controls())

    def _labels(self):
        code=str(self._view_settings.value("interface_language","en-US"))
        return {
            "en-US":("VIEW  //","DETAILS","LARGE ICONS","FULL SCREEN","WINDOWED"),
            "pt-BR":("EXIBIÇÃO  //","DETALHES","ÍCONES GRANDES","TELA CHEIA","JANELA"),
            "es-ES":("VISTA  //","DETALLES","ICONOS GRANDES","PANTALLA COMPLETA","VENTANA"),
        }.get(code,("VIEW  //","DETAILS","LARGE ICONS","FULL SCREEN","WINDOWED"))

    def _sync_view_controls(self):
        label,details,large,fullscreen,windowed=self._labels()
        self.view_hint.setText(label)
        self.details_btn.setText(details)
        self.large_btn.setText(large)
        self.fullscreen_btn.setText(windowed if self.isFullScreen() else fullscreen)
        self.details_btn.setChecked(not self._showing_icons)
        self.large_btn.setChecked(self._showing_icons)

    def set_view_mode(self,mode,*,remember=True):
        if mode not in ("details","large"):
            mode="details"
        selected=self._active_view().currentIndex()
        # Reuse the same QModelIndex for both layouts so file operations
        # always target the item the user actually sees selected.
        self._showing_icons=mode=="large"
        self.views.setCurrentWidget(self.icons if self._showing_icons else self.tree)
        other=self.tree if self._showing_icons else self.icons
        other.clearSelection()
        if selected.isValid():
            self._active_view().setCurrentIndex(selected)
        if remember:self._view_settings.setValue("explorer_view_mode",mode)
        self._sync_view_controls()

    def _active_view(self):
        return self.icons if self._showing_icons else self.tree

    def toggle_fullscreen(self):
        if self.isFullScreen():
            if self._was_maximized:self.showMaximized()
            else:self.showNormal()
        else:
            self._was_maximized=self.isMaximized()
            self.showFullScreen()
        self._sync_view_controls()

    def keyPressEvent(self,event):
        if event.key()==Qt.Key.Key_F11:
            self.toggle_fullscreen()
            event.accept()
            return
        if event.key()==Qt.Key.Key_Escape and self.isFullScreen():
            self.toggle_fullscreen()
            event.accept()
            return
        if event.modifiers() & Qt.KeyboardModifier.ControlModifier:
            if event.key()==Qt.Key.Key_1:
                self.set_view_mode("details");event.accept();return
            if event.key()==Qt.Key.Key_2:
                self.set_view_mode("large");event.accept();return
        super().keyPressEvent(event)

    @staticmethod
    def _label(text, name):
        widget = QLabel(text)
        widget.setObjectName(name)
        return widget

    def _navigate(self, location, *, save=True):
        path = Path(location).expanduser()
        if not path.is_dir():
            self._message('A pasta selecionada não existe ou está inacessível.')
            return
        path = path.resolve()
        if save and path != self.current:
            self.history.append(self.current)
        self.current = path
        self.address.setText(str(path))
        root_index=self.model.setRootPath(str(path))
        self.tree.setRootIndex(root_index)
        self.icons.setRootIndex(root_index)
        # Selection never silently carries over to a different folder.
        self.tree.setCurrentIndex(QModelIndex())
        self.icons.setCurrentIndex(QModelIndex())
        self.status.setText('PASTA ATUAL   //   ' + str(path))

    def go_back(self):
        if self.history:
            self._navigate(self.history.pop(), save=False)

    def go_up(self):
        self._navigate(self.current.parent)

    def go_home(self):
        self._navigate(Path.home())

    def go_address(self):
        self._navigate(self.address.text().strip())

    def _selected(self):
        ix = self._active_view().currentIndex()
        if not ix.isValid():
            self._message('Selecione um arquivo ou pasta primeiro.')
            return None
        path = Path(self.model.filePath(ix))
        if not path.exists():
            self._message('O arquivo ou pasta não existe mais.')
            return None
        return path

    def _message(self, text):
        self.status.setText(str(text))

    def _failed(self, exc):
        self._message(str(exc))
        QMessageBox.warning(self, 'H.D.D. // Explorador', str(exc))

    def _confirm(self, title, message):
        return QMessageBox.question(self, title, message,
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No) == QMessageBox.StandardButton.Yes

    def activate(self, index):
        path = Path(self.model.filePath(index))
        if path.is_dir():
            self._navigate(path)
        else:
            self._open(path)

    def _open(self, path):
        try:
            if path.is_dir():
                self._navigate(path)
            elif os.name == 'nt':
                os.startfile(str(path))
            else:
                raise RuntimeError('Abrir no programa padrão exige Windows.')
        except Exception as exc:
            self._failed(exc)

    def open_selection(self):
        path = self._selected()
        if path:
            self._open(path)

    def edit_selection(self):
        path = self._selected()
        if path is None:
            return
        try:
            if not path.is_file() or path.is_symlink():
                raise ValueError('Selecione um arquivo de texto regular.')
            dlg = TextEditorDialog(path, self)
            if dlg.exec() == QDialog.DialogCode.Accepted:
                self._message('Arquivo salvo: ' + str(path))
        except Exception as exc:
            self._failed(exc)

    def edit_code_selection(self):
        path=self._selected()
        if path is None:return
        if not path.is_file() or path.is_symlink():
            self._message('Selecione um arquivo de código ou texto regular.')
            return
        if self.on_code_file:
            self.on_code_file(path)
            return
        from hdd.ui.code_editor import CodeEditorDialog
        try:
            dialog=CodeEditorDialog(self,filename=path)
            dialog.exec()
        except Exception as error:
            self._failed(error)

    def integrate_selection(self):
        path=self._selected()
        if path is None:return
        if path.is_symlink() or (hasattr(path,"is_junction") and path.is_junction()):
            self._message("Links e junções não são aceitos na Central de Integrações.")
            return
        if self.on_integrate_file:
            self.on_integrate_file(path)
        else:
            self._message("Abra este explorador através do H.D.D. para integrar módulos.")

    def new_folder(self):
        name, ok = QInputDialog.getText(self, 'Nova pasta', 'Nome da pasta:')
        if not ok:
            return
        try:
            if not _safe_name(name):
                raise ValueError('Nome de pasta inválido.')
            (self.current / name).mkdir(exist_ok=False)
            self._message('Pasta criada: ' + name)
        except Exception as exc:
            self._failed(exc)

    def rename_selection(self):
        path = self._selected()
        if path is None:
            return
        name, ok = QInputDialog.getText(self, 'Renomear', 'Novo nome:', text=path.name)
        if not ok or name == path.name:
            return
        try:
            if not _safe_name(name) or path.is_symlink():
                raise ValueError('Nome inválido ou arquivo de link não suportado.')
            target = path.with_name(name)
            if target.exists() or target.is_symlink():
                raise FileExistsError('Já existe um arquivo ou pasta com este nome.')
            path.rename(target)
            self._message('Renomeado: ' + target.name)
        except Exception as exc:
            self._failed(exc)

    def _copy_or_move(self, move):
        path = self._selected()
        if path is None:
            return
        folder = QFileDialog.getExistingDirectory(self, 'Selecionar pasta de destino', str(self.current))
        if not folder:
            return
        try:
            if path.is_symlink():
                raise ValueError('Links de arquivos não são suportados nesta operação.')
            destination = Path(folder).resolve()
            target = destination / path.name
            if target.exists() or target.is_symlink():
                raise FileExistsError('O destino já contém um arquivo ou pasta com esse nome.')
            if path.is_dir() and destination.is_relative_to(path.resolve()):
                raise ValueError('Não é possível copiar/mover uma pasta para dentro dela mesma.')
            if not self._confirm('Confirmar operação',
                    ('Mover' if move else 'Copiar') + f'\n{path}\n\nPara\n{target}?'):
                return
            if move:
                shutil.move(str(path), str(target))
            elif path.is_dir():
                shutil.copytree(path, target, symlinks=True)
            else:
                shutil.copy2(path, target)
            self._message(('Movido: ' if move else 'Copiado: ') + str(target))
        except Exception as exc:
            self._failed(exc)

    def copy_selection(self):
        self._copy_or_move(False)

    def move_selection(self):
        self._copy_or_move(True)

    def recycle_selection(self):
        path = self._selected()
        if path is None:
            return
        if not self._confirm('Enviar à Lixeira do Windows',
                'Enviar o item selecionado à Lixeira?\n\n' + str(path) +
                '\n\nA operação solicitará a Lixeira. Se o Windows alertar que será permanente, cancele.'):
            return
        try:
            _recycle_windows(path)
            self._message('Item enviado à Lixeira: ' + path.name)
        except Exception as exc:
            self._failed(exc)

    def extract_selection(self):
        path = self._selected()
        if path is None:
            return
        if not path.is_file() or path.suffix.lower() != '.zip':
            self._message('Selecione um arquivo ZIP. Outros formatos virão depois.')
            return
        folder = QFileDialog.getExistingDirectory(self, 'Extrair ZIP em qual pasta?', str(self.current))
        if not folder:
            return
        if not self._confirm('Confirmar extração',
                f'Extrair {path.name} em uma nova pasta dentro de\n{folder}?'):
            return
        try:
            output = _extract_zip_safely(path, Path(folder).resolve())
            self._message('ZIP extraído: ' + str(output))
        except Exception as exc:
            self._failed(exc)
