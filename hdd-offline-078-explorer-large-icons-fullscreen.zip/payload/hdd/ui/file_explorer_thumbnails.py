"""Asynchronous image previews for H.D.D. large-icon explorer.
Only QImage decoding happens off the GUI thread. No file modifications.
"""
from __future__ import annotations
from collections import OrderedDict
from pathlib import Path
import stat
from PySide6.QtCore import QObject,QRunnable,QThreadPool,QSize,Qt,Signal
from PySide6.QtGui import QIcon,QImage,QImageReader,QPixmap
from PySide6.QtWidgets import QStyledItemDelegate

SUPPORTED={".png",".jpg",".jpeg",".jfif",".webp",".bmp",".gif",".tif",".tiff"}
MAX_BYTES=48*1024*1024
MAX_PIXELS=55_000_000
THUMB_SIZE=QSize(132,106)

class _Signals(QObject):
    ready=Signal(str,object,object)

class _PreviewTask(QRunnable):
    def __init__(self,path,identity,signals):
        super().__init__()
        self.path=path
        self.identity=identity
        self.signals=signals
    def run(self):
        image=QImage()
        try:
            p=Path(self.path)
            details=p.stat()
            if (details.st_size==self.identity[0] and
                details.st_mtime_ns==self.identity[1] and
                stat.S_ISREG(details.st_mode) and details.st_size<=MAX_BYTES):
                reader=QImageReader(str(p))
                reader.setAutoTransform(True)
                dimensions=reader.size()
                if dimensions.isValid() and 0<dimensions.width()*dimensions.height()<=MAX_PIXELS:
                    reader.setScaledSize(dimensions.scaled(THUMB_SIZE,Qt.AspectRatioMode.KeepAspectRatio))
                    image=reader.read()
        except (OSError,ValueError):
            pass
        self.signals.ready.emit(self.path,self.identity,image)

class FileThumbnailDelegate(QStyledItemDelegate):
    def __init__(self,explorer):
        super().__init__(explorer.icons)
        self.explorer=explorer
        self.signals=_Signals()
        self.signals.ready.connect(self._received)
        self.pool=QThreadPool.globalInstance()
        self.cache=OrderedDict()
        self.pending=set()

    def thumbnail(self,index):
        try:
            p=Path(self.explorer.model.filePath(index))
            if p.suffix.lower() not in SUPPORTED or not p.is_file():
                return None
            info=p.stat()
            if not stat.S_ISREG(info.st_mode) or info.st_size>MAX_BYTES:
                return None
            ident=(info.st_size,info.st_mtime_ns)
            key=(str(p),ident)
            if key in self.cache:
                self.cache.move_to_end(key)
                return self.cache[key]
            if key not in self.pending and len(self.pending)<12:
                self.pending.add(key)
                self.pool.start(_PreviewTask(str(p),ident,self.signals))
        except (OSError,ValueError):
            pass
        return None

    def initStyleOption(self,option,index):
        super().initStyleOption(option,index)
        thumb=self.thumbnail(index)
        if thumb is not None and not thumb.isNull():
            option.icon=QIcon(thumb)
            option.decorationSize=THUMB_SIZE

    def _received(self,path,identity,image):
        key=(path,identity)
        self.pending.discard(key)
        # Cache failed decodes too, to avoid retrying corrupt images on
        # every repaint of folders containing unsupported/corrupt files.
        pixmap=QPixmap.fromImage(image) if not image.isNull() else QPixmap()
        self.cache[key]=pixmap
        self.cache.move_to_end(key)
        while len(self.cache)>300:self.cache.popitem(last=False)
        if self.explorer.icons.isVisible():
            self.explorer.icons.viewport().update()
