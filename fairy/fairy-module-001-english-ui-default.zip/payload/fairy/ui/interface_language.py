"""Independent UI language (PT-BR / EN-US / ES-ES).

Stores presentation preference independently of spoken answer/TTS language and
microphone/STT language. Existing installations without this file continue
using their output language for UI until the user chooses a distinct one.
"""
from __future__ import annotations
import json
import os
from pathlib import Path
from fairy.core.language_manager import LANGUAGES, default_language, project_root

def ui_language_path(root: Path | None = None) -> Path:
    return Path(root or project_root()).resolve() / "userdata" / "ui_language.json"

def interface_language(root: Path | None = None) -> str:
    p = ui_language_path(root)
    try:
        data = json.loads(p.read_text(encoding="utf-8"))
        code = data.get("language")
        if code in LANGUAGES:
            return str(code)
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    # Interface language is INDEPENDENT from reply language and microphone.
    # For an unconfigured installation, the factory UI defaults to English,
    # even if the user's spoken-output language is Portuguese.
    return "en-US"

def save_interface_language(code: str, root: Path | None = None) -> str:
    if code not in LANGUAGES:
        raise ValueError("Unsupported Fairy UI language")
    p = ui_language_path(root)
    p.parent.mkdir(parents=True, exist_ok=True)
    temp = p.with_suffix(".json.tmp")
    try:
        temp.write_text(
            json.dumps({"version":1, "language":code}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        os.replace(temp,p)
    finally:
        temp.unlink(missing_ok=True)
    return code
