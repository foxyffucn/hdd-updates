from __future__ import annotations

import sys

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QApplication,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QLabel,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QVBoxLayout,
)

from fairy.ui.interface_language import interface_language, save_interface_language
from fairy.ui.i18n import manager
from fairy.core.language_manager import (
    LANGUAGES,
    language_name,
    load_settings,
    recognition_languages,
    save_settings,
    stt_primary_language,
)


_UI = {
    "en-US": {
        "title":"Fairy // Language V1.5",
        "intro":"Fairy's reply/voice, microphone and interface languages are independent. You can speak Portuguese, see Portuguese menus and still receive English replies.",
        "reply":"Fairy replies/speaks in:",
        "interface":"Interface / menus language:",
        "mic":"Microphone priority:",
        "understood":"Languages Fairy may understand from the microphone:",
        "out":"Output/TTS", "voice":"Edge-TTS voice", "input":"Microphone languages",
        "priority":"STT priority", "ui":"Interface / menus",
        "need_mic":"Enable at least one microphone language.",
        "saved_note":"Voice, microphone and interface languages are independent.",
    },
    "pt-BR": {
        "title":"Fairy // Idiomas V1.5",
        "intro":"Os idiomas de resposta/voz, do microfone e da interface são independentes. Você pode falar português, ver os menus em português e receber respostas em inglês.",
        "reply":"Fairy responde/fala em:",
        "interface":"Idioma da interface / menus:",
        "mic":"Prioridade do microfone:",
        "understood":"Idiomas que a Fairy pode entender pelo microfone:",
        "out":"Resposta/TTS", "voice":"Voz Edge-TTS", "input":"Idiomas do microfone",
        "priority":"Prioridade STT", "ui":"Interface / menus",
        "need_mic":"Ative pelo menos um idioma para o microfone.",
        "saved_note":"Os idiomas da voz, do microfone e da interface são independentes.",
    },
    "es-ES": {
        "title":"Fairy // Idiomas V1.5",
        "intro":"Los idiomas de respuesta/voz, micrófono e interfaz son independientes. Puedes hablar portugués, ver los menús en español y recibir respuestas en inglés.",
        "reply":"Fairy responde/habla en:",
        "interface":"Idioma de la interfaz / menús:",
        "mic":"Prioridad del micrófono:",
        "understood":"Idiomas que Fairy puede entender por el micrófono:",
        "out":"Respuesta/TTS", "voice":"Voz Edge-TTS", "input":"Idiomas del micrófono",
        "priority":"Prioridad STT", "ui":"Interfaz / menús",
        "need_mic":"Activa al menos un idioma para el micrófono.",
        "saved_note":"Los idiomas de voz, micrófono e interfaz son independientes.",
    },
}

def _ui_text(key):
    return _UI.get(interface_language(), _UI["en-US"])[key]


class LanguageSettingsDialog(QDialog):
    """V1.5: output, microphone and interface languages are independent."""

    def __init__(self, parent=None) -> None:
        super().__init__(parent)

        self.setWindowTitle(_ui_text("title"))
        self.setMinimumWidth(540)

        settings = load_settings()

        root = QVBoxLayout(self)

        self.intro = QLabel(_ui_text("intro"))
        self.intro.setWordWrap(True)
        root.addWidget(self.intro)

        form = QFormLayout()

        self.output = QComboBox()
        for code, profile in LANGUAGES.items():
            self.output.addItem(
                str(profile["name"]),
                code,
            )

        output_code = str(
            settings[
                "default_language"
            ]
        )
        index = self.output.findData(
            output_code
        )
        if index >= 0:
            self.output.setCurrentIndex(
                index
            )

        self.reply_label = QLabel(_ui_text("reply"))
        form.addRow(self.reply_label, self.output)

        # Independent third preference: this affects only the appearance
        # of menus, panels and dialogs, NEVER response/TTS or STT.
        self.interface = QComboBox()
        for code, profile in LANGUAGES.items():
            self.interface.addItem(str(profile["name"]), code)
        ui_code = interface_language()
        ui_index = self.interface.findData(ui_code)
        if ui_index >= 0:
            self.interface.setCurrentIndex(ui_index)
        self.interface_label = QLabel(_ui_text("interface"))
        form.addRow(self.interface_label, self.interface)

        self.stt_primary = QComboBox()
        self.mic_label = QLabel(_ui_text("mic"))
        form.addRow(self.mic_label, self.stt_primary)

        root.addLayout(form)

        self.understood_label = QLabel(_ui_text("understood"))
        root.addWidget(self.understood_label)

        self.understood = QListWidget()

        selected = set(
            settings.get(
                "understood_languages",
                recognition_languages(),
            )
        )

        for code, profile in LANGUAGES.items():
            item = QListWidgetItem(
                str(profile["name"])
            )
            item.setData(
                Qt.UserRole,
                code,
            )
            item.setFlags(
                item.flags()
                | Qt.ItemIsUserCheckable
            )
            item.setCheckState(
                Qt.Checked
                if code in selected
                else Qt.Unchecked
            )
            self.understood.addItem(
                item
            )

        root.addWidget(
            self.understood
        )

        self.summary = QLabel("")
        self.summary.setWordWrap(True)
        root.addWidget(self.summary)

        self.output.currentIndexChanged.connect(
            self._refresh_summary
        )
        self.understood.itemChanged.connect(
            self._refresh_inputs
        )
        self.stt_primary.currentIndexChanged.connect(
            self._refresh_summary
        )
        self.interface.currentIndexChanged.connect(self._refresh_summary)
        manager().changed.connect(self._refresh_ui_copy)

        self._refresh_inputs(
            preserve=str(
                settings.get(
                    "stt_primary_language",
                    stt_primary_language(),
                )
            )
        )

        buttons = QDialogButtonBox(
            QDialogButtonBox.Save
            | QDialogButtonBox.Cancel
        )
        buttons.accepted.connect(
            self._save
        )
        buttons.rejected.connect(
            self.reject
        )
        root.addWidget(buttons)

    def _checked_languages(self):
        out = []
        for index in range(
            self.understood.count()
        ):
            item = self.understood.item(
                index
            )
            if (
                item.checkState()
                == Qt.Checked
            ):
                code = str(
                    item.data(
                        Qt.UserRole
                    )
                )
                if code in LANGUAGES:
                    out.append(code)
        return out

    def _refresh_inputs(
        self,
        *_args,
        preserve=None,
    ):
        old = (
            preserve
            or self.stt_primary.currentData()
        )
        checked = (
            self._checked_languages()
        )

        self.stt_primary.blockSignals(
            True
        )
        self.stt_primary.clear()

        for code in checked:
            self.stt_primary.addItem(
                str(
                    LANGUAGES[
                        code
                    ]["name"]
                ),
                code,
            )

        index = self.stt_primary.findData(
            old
        )
        if index >= 0:
            self.stt_primary.setCurrentIndex(
                index
            )
        elif self.stt_primary.count():
            self.stt_primary.setCurrentIndex(
                0
            )

        self.stt_primary.blockSignals(
            False
        )
        self._refresh_summary()

    def _refresh_summary(
        self,
        *_args,
    ):
        output = str(
            self.output.currentData()
            or "en-US"
        )
        checked = (
            self._checked_languages()
        )
        primary = str(
            self.stt_primary.currentData()
            or (
                checked[0]
                if checked
                else ""
            )
        )

        voice = str(
            LANGUAGES.get(
                output,
                LANGUAGES["en-US"],
            )["edge_voice"]
        )

        understood_text = (
            ", ".join(
                str(
                    LANGUAGES[
                        code
                    ]["name"]
                )
                for code in checked
            )
            if checked
            else "NONE"
        )

        primary_text = (
            str(
                LANGUAGES[
                    primary
                ]["name"]
            )
            if primary in LANGUAGES
            else "NONE"
        )

        self.summary.setText(
            _ui_text("out") + ": " + language_name(output)
            + "\n" + _ui_text("voice") + ": " + voice
            + "\n" + _ui_text("input") + ": " + understood_text
            + "\n" + _ui_text("priority") + ": " + primary_text
            + "\n" + _ui_text("ui") + ": "
            + language_name(str(self.interface.currentData() or output))
        )

    def _refresh_ui_copy(self):
        self.setWindowTitle(_ui_text("title"))
        self.intro.setText(_ui_text("intro"))
        self.reply_label.setText(_ui_text("reply"))
        self.interface_label.setText(_ui_text("interface"))
        self.mic_label.setText(_ui_text("mic"))
        self.understood_label.setText(_ui_text("understood"))
        self._refresh_summary()

    def _save(self):
        output = str(
            self.output.currentData()
            or "en-US"
        )
        understood = (
            self._checked_languages()
        )

        if not understood:
            QMessageBox.warning(
                self,
                _ui_text("title"),
                _ui_text("need_mic"),
            )
            return

        primary = str(
            self.stt_primary.currentData()
            or understood[0]
        )
        if primary not in understood:
            primary = understood[0]

        saved = save_settings(
            {
                "version": 2,
                "default_language": output,
                "understood_languages": understood,
                "stt_primary_language": primary,
            }
        )
        ui_code = str(self.interface.currentData() or output)
        save_interface_language(ui_code)
        manager().refresh()

        QMessageBox.information(
            self,
            _ui_text("title"),
            _ui_text("out") + ": "
            + language_name(saved["default_language"])
            + "\n" + _ui_text("input") + ": "
            + ", ".join(language_name(code) for code in saved["understood_languages"])
            + "\n" + _ui_text("priority") + ": "
            + language_name(saved["stt_primary_language"])
            + "\n" + _ui_text("ui") + ": " + language_name(ui_code)
            + "\n\n" + _ui_text("saved_note"),
        )
        self.accept()


def main() -> int:
    app = (
        QApplication.instance()
        or QApplication(sys.argv)
    )
    dialog = LanguageSettingsDialog()
    dialog.exec()
    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )
