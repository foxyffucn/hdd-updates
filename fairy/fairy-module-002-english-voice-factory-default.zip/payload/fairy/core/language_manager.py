from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
import json
import os
from pathlib import Path
import re
import unicodedata
from typing import Any

LANGUAGE_SYSTEM_VERSION = "1.3"

LANGUAGES: dict[str, dict[str, Any]] = {
    "pt-BR": {
        "name": "Português (Brasil)",
        "edge_voice": "pt-BR-FranciscaNeural",
        "response_instruction": (
            "Responda em português brasileiro por padrão, independentemente do "
            "idioma usado pelo usuário. Só responda em outro idioma quando ele "
            "pedir explicitamente."
        ),
    },
    "en-US": {
        "name": "English (United States)",
        "edge_voice": "en-US-JennyNeural",
        "response_instruction": (
            "Reply in natural American English by default, regardless of the "
            "language used by the user. Only switch languages when the user "
            "explicitly asks you to."
        ),
    },
    "es-ES": {
        "name": "Español",
        "edge_voice": "es-ES-ElviraNeural",
        "response_instruction": (
            "Responde en español natural por defecto, independientemente del "
            "idioma usado por el usuario. Solo cambia de idioma cuando el "
            "usuario lo pida explícitamente."
        ),
    },
}

DEFAULT_SETTINGS = {
    "version": 1,
    "default_language": "en-US",
    "understand_multiple_languages": True,
    "secondary_languages": ["pt-BR", "es-ES"],
}

WAKE_ALIASES = {
    "fairy", "faery", "ferry", "ferri", "feri", "fery", "feiri",
    "feyri", "feyre", "ferre", "fari", "farii", "fairi", "serie", "fada",
}
WAKE_PREFIXES = {"ei", "hey", "oi", "ola", "o", "alo", "opa", "fala", "ok", "okay"}

LANGUAGE_HINT_WORDS = {
    "pt-BR": {
        "eu", "voce", "que", "como", "abre", "abrir", "fecha", "fechar",
        "pesquisa", "procura", "quero", "pode", "faz", "fazer", "agora", "isso",
        "aqui", "qual", "onde", "porque", "obrigado", "valeu", "meu", "minha",
    },
    "en-US": {
        "i", "you", "the", "what", "how", "open", "close", "search", "find",
        "please", "can", "could", "do", "this", "that", "here", "where", "why",
        "thanks", "thank", "my", "your", "is", "are", "it", "now",
    },
    "es-ES": {
        "yo", "tu", "que", "como", "abre", "abrir", "cierra", "buscar", "busca",
        "puedes", "haz", "esto", "aqui", "donde", "gracias", "mi", "ahora",
        "por", "favor",
    },
}


def project_root() -> Path:
    return Path(__file__).resolve().parents[2]


def settings_path(root: Path | None = None) -> Path:
    root = Path(root or project_root()).resolve()
    return root / "userdata" / "language_settings.json"


def _sanitize_settings(data: dict[str, Any] | None) -> dict[str, Any]:
    data = dict(data or {})
    out = dict(DEFAULT_SETTINGS)

    primary = str(data.get("default_language") or out["default_language"])
    if primary not in LANGUAGES:
        primary = "en-US"
    out["default_language"] = primary

    out["understand_multiple_languages"] = bool(
        data.get("understand_multiple_languages", out["understand_multiple_languages"])
    )

    secondary = data.get("secondary_languages", out["secondary_languages"])
    if not isinstance(secondary, list):
        secondary = []

    clean = []
    for code in secondary:
        code = str(code)
        if code in LANGUAGES and code != primary and code not in clean:
            clean.append(code)
    out["secondary_languages"] = clean
    out["version"] = int(data.get("version") or 1)
    return out


def load_settings(root: Path | None = None) -> dict[str, Any]:
    path = settings_path(root)
    try:
        return _sanitize_settings(json.loads(path.read_text(encoding="utf-8")))
    except Exception:
        return _sanitize_settings(DEFAULT_SETTINGS)


def save_settings(data: dict[str, Any], root: Path | None = None) -> dict[str, Any]:
    clean = _sanitize_settings(data)
    path = settings_path(root)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(clean, ensure_ascii=False, indent=2), encoding="utf-8")
    return clean


def default_language() -> str:
    return str(load_settings()["default_language"])


def language_name(code: str | None = None) -> str:
    code = code or default_language()
    return str(LANGUAGES.get(code, LANGUAGES["en-US"])["name"])


def recognition_languages() -> list[str]:
    settings = load_settings()
    primary = str(settings["default_language"])
    out = [primary]

    if settings.get("understand_multiple_languages", True):
        for code in settings.get("secondary_languages", []):
            if code in LANGUAGES and code not in out:
                out.append(code)

    extra = os.getenv("FAIRY_STT_EXTRA_LANGUAGES", "")
    for raw in extra.split(","):
        code = raw.strip()
        if code in LANGUAGES and code not in out:
            out.append(code)

    return out


def current_edge_voice() -> str:
    override = (os.getenv("FAIRY_EDGE_VOICE") or "").strip()
    if override:
        return override
    return str(LANGUAGES.get(default_language(), LANGUAGES["en-US"])["edge_voice"])


def response_language_instruction() -> str:
    profile = LANGUAGES.get(default_language(), LANGUAGES["en-US"])
    return (
        " IMPORTANT LANGUAGE POLICY: You can understand messages in multiple "
        "languages. " + str(profile["response_instruction"]) +
        " This language policy overrides any earlier default-language instruction."
    )


def normalize(text: str) -> str:
    value = unicodedata.normalize("NFKD", str(text).lower())
    value = "".join(ch for ch in value if not unicodedata.combining(ch))
    value = re.sub(r"[^a-z0-9\s]", " ", value)
    return " ".join(value.split())


def wake_strength(text: str) -> float:
    words = normalize(text).split()
    if not words:
        return 0.0
    idx = 1 if words[0] in WAKE_PREFIXES and len(words) >= 2 else 0
    token = words[idx]
    if token == "fairy":
        return 3.0
    if token in WAKE_ALIASES:
        return 2.4
    return 0.0


def wake_aliases() -> set[str]:
    return set(WAKE_ALIASES)


def wake_prefixes() -> set[str]:
    return set(WAKE_PREFIXES)


@dataclass(slots=True)
class RecognitionCandidate:
    language: str
    text: str
    confidence: float | None
    score: float


@dataclass(slots=True)
class RecognitionResult:
    text: str
    language: str
    confidence: float | None
    candidates: list[RecognitionCandidate]

    def summary(self) -> str:
        parts = []
        for c in self.candidates:
            conf = "?" if c.confidence is None else f"{c.confidence:.2f}"
            parts.append(f"{c.language}={c.text!r} conf={conf} score={c.score:.2f}")
        return " | ".join(parts)


def _language_hint_score(text: str, language: str) -> float:
    words = set(normalize(text).split())
    hints = LANGUAGE_HINT_WORDS.get(language, set())
    return min(1.5, len(words.intersection(hints)) * 0.18)


def _candidate_score(text: str, language: str, confidence: float | None, primary: str) -> float:
    score = wake_strength(text) * 10.0
    score += (max(0.0, min(1.0, confidence)) * 5.0) if confidence is not None else 1.6
    score += _language_hint_score(text, language)
    if language == primary:
        score += 0.20

    words = normalize(text).split()
    if words:
        idx = 1 if words[0] in WAKE_PREFIXES and len(words) > 1 else 0
        if idx < len(words) and words[idx] == "fairy":
            score += 2.0
    return score


def recognize_multilingual_google(recognizer, audio) -> RecognitionResult:
    import speech_recognition as sr

    languages = recognition_languages()
    primary = languages[0] if languages else "pt-BR"
    candidates: list[RecognitionCandidate] = []
    request_errors: list[Exception] = []

    for language in languages:
        try:
            raw = recognizer.recognize_google(audio, language=language, show_all=True)
        except sr.UnknownValueError:
            continue
        except sr.RequestError as exc:
            request_errors.append(exc)
            continue

        alternatives = []
        if isinstance(raw, dict) and isinstance(raw.get("alternative"), list):
            alternatives = [x for x in raw["alternative"] if isinstance(x, dict)]
        elif isinstance(raw, str) and raw.strip():
            alternatives = [{"transcript": raw.strip()}]

        if not alternatives:
            try:
                fallback = recognizer.recognize_google(audio, language=language)
            except sr.UnknownValueError:
                continue
            except sr.RequestError as exc:
                request_errors.append(exc)
                continue
            if str(fallback or "").strip():
                alternatives = [{"transcript": str(fallback).strip()}]

        for alt in alternatives[:3]:
            text = str(alt.get("transcript") or "").strip()
            if not text:
                continue
            raw_conf = alt.get("confidence")
            try:
                confidence = float(raw_conf) if raw_conf is not None else None
            except Exception:
                confidence = None
            candidates.append(
                RecognitionCandidate(
                    language=language,
                    text=text,
                    confidence=confidence,
                    score=_candidate_score(text, language, confidence, primary),
                )
            )

    if not candidates:
        if request_errors:
            raise request_errors[0]
        raise sr.UnknownValueError()

    candidates.sort(key=lambda x: x.score, reverse=True)
    best = candidates[0]
    return RecognitionResult(best.text, best.language, best.confidence, candidates)


def _localized_title(raw: str, language: str) -> str:
    raw = str(raw or "Mestre")
    if normalize(raw) != "mestre":
        return raw
    return {"pt-BR": "Mestre", "en-US": "Master", "es-ES": "Maestro"}.get(language, raw)


def install_personality_localization(cls) -> None:
    if getattr(cls, "_fairy_language_system_v13", False):
        return

    original_core_prompt = cls.core_prompt

    def core_prompt(self) -> str:
        return original_core_prompt(self) + response_language_instruction()

    cls.core_prompt = core_prompt

    def context(self):
        lang = default_language()
        title = _localized_title(getattr(self, "user_title", "Mestre"), lang)
        return lang, title

    def choose(lang, pt, en, es):
        return {"pt-BR": pt, "en-US": en, "es-ES": es}.get(lang, pt)

    def busy(self):
        l, t = context(self)
        return choose(l, f"Minha fila de processamento está ocupada, {t}. Um momento.",
                      f"My processing queue is busy, {t}. One moment.",
                      f"Mi cola de procesamiento está ocupada, {t}. Un momento.")

    def error(self, detail: str):
        l, t = context(self)
        return choose(l, f"A operação falhou, {t}: {detail}. A causa foi registrada para diagnóstico.",
                      f"The operation failed, {t}: {detail}. The cause was logged for diagnostics.",
                      f"La operación falló, {t}: {detail}. La causa fue registrada para diagnóstico.")

    def time_reply(self, now: datetime):
        l, t = context(self)
        return choose(l, f"Agora são {now.hour:02d}:{now.minute:02d}, {t}.",
                      f"It is {now.strftime('%I:%M %p').lstrip('0')}, {t}.",
                      f"Ahora son las {now.hour:02d}:{now.minute:02d}, {t}.")

    def date_reply(self, now: datetime):
        l, t = context(self)
        return choose(l, f"Hoje é {now.day:02d}/{now.month:02d}/{now.year}, {t}.",
                      f"Today is {now.strftime('%B')} {now.day}, {now.year}, {t}.",
                      f"Hoy es {now.day:02d}/{now.month:02d}/{now.year}, {t}.")

    def window_reply(self, external_window: str):
        l, t = context(self)
        if external_window:
            return choose(l, f"A última janela externa registrada é {external_window}, {t}.",
                          f"The last external window I registered is {external_window}, {t}.",
                          f"La última ventana externa registrada es {external_window}, {t}.")
        return choose(l, f"Ainda não tenho uma janela externa registrada, {t}.",
                      f"I do not have an external window registered yet, {t}.",
                      f"Todavía no tengo una ventana externa registrada, {t}.")

    def identity(self):
        l, t = context(self)
        return choose(l, f"Eu sou Fairy, {t}. Uma IA voltada a análise, navegação e assistência operacional.",
                      f"I am Fairy, {t}. An AI focused on analysis, navigation, and operational assistance.",
                      f"Soy Fairy, {t}. Una IA orientada al análisis, navegación y asistencia operativa.")

    def capabilities(self):
        l, t = context(self)
        return choose(l,
                      f"Nesta versão eu consigo conversar, acompanhar o contexto do desktop, usar visão quando necessário e operar as ferramentas realmente conectadas a mim, {t}.",
                      f"In this version I can converse, follow desktop context, use vision when needed, and operate tools that are actually connected to me, {t}.",
                      f"En esta versión puedo conversar, seguir el contexto del escritorio, usar visión cuando sea necesario y operar las herramientas realmente conectadas a mí, {t}.")

    def mic_status(self):
        l, t = context(self)
        return choose(l, f"O microfone está conectado ao pipeline de voz, {t}.",
                      f"The microphone is connected to the voice pipeline, {t}.",
                      f"El micrófono está conectado al sistema de voz, {t}.")

    def greeting(self):
        l, t = context(self)
        return choose(l, f"Estou ouvindo, {t}.", f"I'm listening, {t}.", f"Te escucho, {t}.")

    def thanks(self):
        l, t = context(self)
        return choose(l, f"Sempre, {t}.", f"Always, {t}.", f"Siempre, {t}.")

    def test_status(self):
        l, t = context(self)
        return choose(l, f"Sistemas respondendo normalmente, {t}.",
                      f"Systems are responding normally, {t}.",
                      f"Los sistemas responden con normalidad, {t}.")

    def voice_ready(self):
        l, t = context(self)
        return choose(l, f"Inicialização concluída, {t}. Sistemas de voz disponíveis.",
                      f"Initialization complete, {t}. Voice systems are available.",
                      f"Inicialización completada, {t}. Sistemas de voz disponibles.")

    def presentation(self, mode: str):
        l, t = context(self)
        if mode == "corner":
            return choose(l, f"Entendido, {t}. Continuo ouvindo do canto.",
                          f"Understood, {t}. I'll keep listening from the corner.",
                          f"Entendido, {t}. Seguiré escuchando desde la esquina.")
        if mode == "hidden":
            return choose(l, f"Entendido, {t}. Permanecerei em segundo plano.",
                          f"Understood, {t}. I'll remain in the background.",
                          f"Entendido, {t}. Permaneceré en segundo plano.")
        return choose(l, f"Estou aqui, {t}.", f"I'm here, {t}.", f"Estoy aquí, {t}.")

    def session_end(self):
        l, t = context(self)
        return choose(l, f"Entendido, {t}. Entrando em espera.",
                      f"Understood, {t}. Entering standby.",
                      f"Entendido, {t}. Entrando en espera.")

    def listening(self):
        return greeting(self)

    def vision_unavailable(self):
        l, t = context(self)
        return choose(l,
                      f"Capturei a janela, {t}, mas não há um modelo de visão disponível para interpretar a imagem. A captura em si está funcionando.",
                      f"I captured the window, {t}, but no vision model is available to interpret the image. The capture itself is working.",
                      f"Capturé la ventana, {t}, pero no hay un modelo de visión disponible para interpretar la imagen. La captura funciona correctamente.")

    def llm_unavailable(self, heard_text: str):
        l, t = context(self)
        return choose(l,
                      f"Recebi o pedido: {heard_text}. Meu roteador está ativo, {t}, mas nenhum provedor de linguagem disponível conseguiu responder. As funções locais continuam operacionais.",
                      f"I received the request: {heard_text}. My router is active, {t}, but no available language provider could answer. Local functions remain operational.",
                      f"Recibí la solicitud: {heard_text}. Mi enrutador está activo, {t}, pero ningún proveedor de lenguaje disponible pudo responder. Las funciones locales siguen operativas.")

    def code_popup_ack(self):
        l, t = context(self)
        return choose(l, f"Mostrei o código na tela, {t}.",
                      f"I displayed the code on screen, {t}.",
                      f"Mostré el código en pantalla, {t}.")

    cls.busy = busy
    cls.error = error
    cls.time_reply = time_reply
    cls.date_reply = date_reply
    cls.window_reply = window_reply
    cls.identity = identity
    cls.capabilities = capabilities
    cls.mic_status = mic_status
    cls.greeting = greeting
    cls.thanks = thanks
    cls.test_status = test_status
    cls.voice_ready = voice_ready
    cls.presentation = presentation
    cls.session_end = session_end
    cls.listening = listening
    cls.vision_unavailable = vision_unavailable
    cls.llm_unavailable = llm_unavailable
    cls.code_popup_ack = code_popup_ack
    cls._fairy_language_system_v13 = True

# FAIRY_LANGUAGE_VISION_HOTFIX_V1_3_1

_VISUAL_CUES_MULTILINGUAL = (
    # PT-BR
    "na minha tela", "na tela", "olha isso", "olhe isso", "olha aqui",
    "olhe aqui", "ve isso", "veja isso", "ta vendo", "esta vendo",
    "consegue ver", "esse erro", "essa mensagem", "essa janela",
    "essa pagina", "esse site", "essa imagem", "esse codigo",
    "o que tem aqui", "o que esta escrito", "analisa a tela",
    "analise a tela", "le isso", "leia isso",
    # EN-US
    "on my screen", "my screen", "look at this", "look here",
    "can you see", "do you see", "what do you see", "read this",
    "read the screen", "this error", "this message", "this window",
    "this page", "this site", "this image", "this code",
    "analyze the screen", "analyse the screen", "check my screen",
    "see this",
    # ES
    "en mi pantalla", "en la pantalla", "mira esto", "mira aqui",
    "puedes ver", "ves esto", "que ves", "lee esto", "lee la pantalla",
    "este error", "este mensaje", "esta ventana", "esta pagina",
    "este sitio", "esta imagen", "este codigo", "analiza la pantalla",
)


def needs_vision_multilingual(text: str) -> bool:
    n = normalize(text)
    return any(cue in n for cue in _VISUAL_CUES_MULTILINGUAL)


def response_language_instruction() -> str:
    code = default_language()
    target = {
        "pt-BR": "Brazilian Portuguese (pt-BR)",
        "en-US": "American English (en-US)",
        "es-ES": "Spanish (es-ES)",
    }.get(code, "Brazilian Portuguese (pt-BR)")

    return (
        f" MANDATORY OUTPUT LANGUAGE: {target}. "
        "The user may speak or be transcribed in any supported language. "
        "The input language alone is NEVER permission to switch your response language. "
        f"Every user-facing sentence MUST remain in {target} unless the user explicitly "
        "asks for the answer itself to be in another language. "
        "Names, commands, URLs, code and quoted text may remain unchanged."
    )


def _language_hint_score(text: str, language: str) -> float:
    words = set(normalize(text).split())
    hints = LANGUAGE_HINT_WORDS.get(language, set())
    if not words or not hints:
        return 0.0
    return min(3.0, len(words.intersection(hints)) * 0.75)


def _candidate_score(
    text: str,
    language: str,
    confidence: float | None,
    primary: str,
) -> float:
    # Wake is special: exact "Fairy" should beat PT-BR aliases.
    wake = wake_strength(text)
    words = normalize(text).split()
    idx = 1 if words and words[0] in WAKE_PREFIXES and len(words) > 1 else 0
    token = words[idx] if idx < len(words) else ""

    if wake > 0.0:
        score = 50.0 if token == "fairy" else 38.0
        if confidence is not None:
            score += max(0.0, min(1.0, confidence)) * 3.0
        if language == primary:
            score += 0.5
        return score

    # Normal conversation: give the configured language a meaningful preference.
    score = (
        max(0.0, min(1.0, confidence)) * 3.0
        if confidence is not None
        else 1.0
    )
    score += _language_hint_score(text, language)

    if language == primary:
        score += 1.4

    return score

# FAIRY_LANGUAGE_INPUT_OUTPUT_SPLIT_V1_4
#
# V1.3 coupled Fairy's output language to microphone recognition.
# V1.4 separates:
#   default_language       -> reply/TTS language
#   understood_languages   -> STT-enabled languages
#   stt_primary_language   -> preferred STT language

LANGUAGE_INPUT_OUTPUT_VERSION = "1.4"


def _v14_valid_codes(values):
    if not isinstance(values, list):
        return []
    out = []
    for raw in values:
        code = str(raw)
        if code in LANGUAGES and code not in out:
            out.append(code)
    return out


def _v14_migrate_input_languages(data, output_language):
    explicit = _v14_valid_codes(
        data.get("understood_languages")
        or data.get("input_languages")
    )
    if explicit:
        return explicit

    # Preserve exact V1.3 behavior during generic migration.
    legacy = [output_language]
    if bool(data.get("understand_multiple_languages", True)):
        for code in _v14_valid_codes(
            data.get("secondary_languages", [])
        ):
            if code not in legacy:
                legacy.append(code)

    return legacy or ["en-US"]


def _sanitize_settings(data):
    data = dict(data or {})

    output = str(
        data.get("default_language")
        or "en-US"
    )
    if output not in LANGUAGES:
        output = "en-US"

    understood = _v14_migrate_input_languages(
        data,
        output,
    )
    if not understood:
        understood = ["en-US"]

    stt_primary = str(
        data.get("stt_primary_language")
        or data.get("input_primary_language")
        or understood[0]
    )
    if stt_primary not in understood:
        stt_primary = understood[0]

    ordered = [stt_primary] + [
        code
        for code in understood
        if code != stt_primary
    ]

    # Compatibility mirrors for older modules only.
    legacy_secondary = [
        code
        for code in ordered
        if code != output
    ]

    return {
        "version": 2,
        "language_system_version": "1.4",
        "default_language": output,
        "understood_languages": ordered,
        "stt_primary_language": stt_primary,
        "understand_multiple_languages": len(ordered) > 1,
        "secondary_languages": legacy_secondary,
    }


def load_settings(root=None):
    path = settings_path(root)
    try:
        data = json.loads(
            path.read_text(
                encoding="utf-8"
            )
        )
    except Exception:
        data = dict(DEFAULT_SETTINGS)
    return _sanitize_settings(data)


def save_settings(data, root=None):
    clean = _sanitize_settings(data)
    path = settings_path(root)
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    temp = path.with_name(
        path.name + ".v14.tmp"
    )
    try:
        temp.write_text(
            json.dumps(
                clean,
                ensure_ascii=False,
                indent=2,
            ),
            encoding="utf-8",
        )
        temp.replace(path)
    finally:
        temp.unlink(missing_ok=True)

    return clean


def understood_languages():
    return list(
        load_settings()[
            "understood_languages"
        ]
    )


def stt_primary_language():
    settings = load_settings()
    understood = list(
        settings[
            "understood_languages"
        ]
    )
    primary = str(
        settings[
            "stt_primary_language"
        ]
    )
    if primary in understood:
        return primary
    return (
        understood[0]
        if understood
        else "pt-BR"
    )


def recognition_languages():
    """Microphone/STT languages only; output language is irrelevant."""
    settings = load_settings()
    out = list(
        settings[
            "understood_languages"
        ]
    )

    primary = str(
        settings[
            "stt_primary_language"
        ]
    )
    if primary in out:
        out = [primary] + [
            code
            for code in out
            if code != primary
        ]

    # Advanced explicit override remains supported.
    extra = os.getenv(
        "FAIRY_STT_EXTRA_LANGUAGES",
        "",
    )
    for raw in extra.split(","):
        code = raw.strip()
        if (
            code in LANGUAGES
            and code not in out
        ):
            out.append(code)

    return out or ["en-US"]


def language_profile_summary():
    settings = load_settings()
    output = str(
        settings[
            "default_language"
        ]
    )
    return {
        "output_language": output,
        "output_name": language_name(output),
        "edge_voice": current_edge_voice(),
        "stt_primary_language": stt_primary_language(),
        "understood_languages": recognition_languages(),
    }
