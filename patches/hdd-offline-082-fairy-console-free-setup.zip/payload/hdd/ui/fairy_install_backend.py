"""Private H.D.D. Fairy factory package operations.

ZIP source is bundled with the H.D.D. (never the developer's local folder).
No secrets or user data copied from the creator's Fairy.
The worker verifies a file manifest BEFORE launching the factory installer.
Real pip/Playwright downloads only happen after user explicitly clicks Install.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import threading
import zipfile

from hdd.paths import asset_path

BUNDLED_PACKAGE=asset_path("fairy_factory","Fairy_FACTORY_FOR_HDD.zip")
FACTORY_ROOT_NAME="Fairy"
MAX_ENTRIES=600
MAX_FILE=75*1024*1024
MAX_UNPACKED=80*1024*1024
STATUS_FILE=Path("userdata/factory_install_status.json")


def file_hash(path):
    digest=hashlib.sha256()
    with Path(path).open("rb") as src:
        for chunk in iter(lambda:src.read(1024*1024),b""):
            digest.update(chunk)
    return digest.hexdigest()


def installed_state(target):
    target=Path(target)
    state=target/STATUS_FILE
    if not state.is_file() or state.is_symlink():
        return None
    try:
        data=json.loads(state.read_text(encoding="utf-8"))
        if data.get("installed") is True and (target/"start_fairy.bat").is_file() and (
            target/".venv/Scripts/python.exe").is_file():
            return data
    except (OSError,ValueError):
        pass
    return None


def default_target():
    return Path.home()/"Fairy-HDD"


def check_target(folder):
    raw=str(folder).strip()
    if not raw:raise ValueError("Escolha uma pasta de instalação.")
    p=Path(raw).expanduser()
    if p.exists():
        if p.is_symlink() or not p.is_dir():raise ValueError("Destino inválido ou link simbólico.")
        # Existing folder is permitted only for resumable factory installs.
        if not (p/"factory_manifest.json").is_file() or not (p/"factory_install.py").is_file():
            raise ValueError("A pasta já existe e não contém uma instalação da Fairy. Escolha uma pasta nova.")
    if p.parent.exists() and p.parent.is_symlink():
        raise ValueError("Não instale dentro de um link simbólico.")
    return p.resolve()


def validate_package(package=BUNDLED_PACKAGE):
    package=Path(package)
    if not package.is_file() or package.is_symlink():
        raise ValueError("Pacote de fábrica ausente no H.D.D.")
    if package.stat().st_size>40*1024*1024:
        raise ValueError("Pacote de fábrica excede tamanho permitido.")
    with zipfile.ZipFile(package) as z:
        entries=z.infolist()
        if not 1<=len(entries)<=MAX_ENTRIES:raise ValueError("Número de arquivos inválido.")
        total=0
        files={}
        for entry in entries:
            raw=entry.filename
            p=PurePosixPath(raw)
            if raw!=p.as_posix() or p.is_absolute() or "\\" in raw or ".." in p.parts or "\x00" in raw:
                raise ValueError("Caminho inseguro no pacote Fairy.")
            if len(p.parts)<2 or p.parts[0]!=FACTORY_ROOT_NAME or entry.is_dir():
                raise ValueError("Estrutura inesperada do pacote Fairy.")
            if (entry.external_attr>>16)&0o170000==0o120000:
                raise ValueError("Links não são permitidos.")
            if entry.file_size>MAX_FILE:raise ValueError("Arquivo da Fairy muito grande.")
            total+=entry.file_size
            if total>MAX_UNPACKED:raise ValueError("Pacote extraído muito grande.")
            rel=p.relative_to(FACTORY_ROOT_NAME).as_posix()
            if rel in files:raise ValueError("Arquivo duplicado no pacote Fairy.")
            files[rel]=entry
        if "factory_manifest.json" not in files or "factory_install.py" not in files or "HDD_PACKAGE.json" not in files:
            raise ValueError("Pacote sem manifesto ou instalador.")
        manifest=json.loads(z.read(files["factory_manifest.json"]).decode("utf-8"))
        declared=manifest.get("files")
        if not isinstance(declared,dict) or len(declared)!=len(files)-1:
            raise ValueError("Manifesto de fábrica inconsistente.")
        if set(declared)!=(set(files)-{"factory_manifest.json"}):
            raise ValueError("Arquivos extras ou ausentes no pacote Fairy.")
        for rel,entry in files.items():
            if rel=="factory_manifest.json":continue
            digest=hashlib.sha256()
            with z.open(entry) as stream:
                for chunk in iter(lambda:stream.read(1024*1024),b""):
                    digest.update(chunk)
            if digest.hexdigest()!=declared[rel]:
                raise ValueError("Falha de integridade: "+rel)
        spec=json.loads(z.read(files["HDD_PACKAGE.json"]))
        if spec.get("package_id")!="fairy.desktop" or spec.get("install_entry")!="factory_install.py":
            raise ValueError("Este arquivo não é o pacote de fábrica autorizado.")
        return {"files":len(files),"version":spec.get("factory_version"),"bytes":total}


def python_command():
    if os.name!="nt":raise RuntimeError("O instalador desktop requer Windows.")
    if (3,12)<=sys.version_info[:2]<(3,15) and sys.maxsize>2**32 and not getattr(sys,"frozen",False):
        return [sys.executable]
    launcher=shutil.which("py")
    if not launcher:
        raise RuntimeError("Python 3.12 (64 bits) não encontrado. Instale Python 3.12 para continuar.")
    probe=subprocess.run([launcher,"-3.12","-c","import sys;assert sys.maxsize>2**32"],
                         capture_output=True,timeout=15,
                         creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
    if probe.returncode:
        raise RuntimeError("Python 3.12 (64 bits) não encontrado.")
    return [launcher,"-3.12"]


def run_factory_install(package, target, emit, cancel, stage_only=False):
    """Blocking implementation intended for a QThread, never called in GUI."""
    target=check_target(target)
    if installed_state(target):
        from hdd.ui.factory_sfx import provision_private_sfx
        provision_private_sfx(target,emit)
        emit("A instalação da Fairy já está concluída neste destino.")
        return target
    validate_package(package)
    if cancel.is_set():raise InterruptedError("Operação cancelada.")
    cmd_prefix=python_command()
    with tempfile.TemporaryDirectory(prefix="hdd-fairy-factory-") as tmp:
        base=Path(tmp)/FACTORY_ROOT_NAME
        base.mkdir()
        emit("Pacote verificado. Preparando arquivos de fábrica...")
        with zipfile.ZipFile(package) as z:
            for member in z.infolist():
                if cancel.is_set():raise InterruptedError("Operação cancelada.")
                rel=PurePosixPath(member.filename).relative_to(FACTORY_ROOT_NAME)
                dest=base.joinpath(*rel.parts)
                dest.parent.mkdir(parents=True,exist_ok=True)
                with z.open(member) as src, dest.open("xb") as dst:
                    shutil.copyfileobj(src,dst)
        emit("Arquivos preparados; iniciando instalador oficial da Fairy.")
        if target.exists():
            cmd=cmd_prefix+[str(target/"factory_install.py")]
            cwd=target
        else:
            cmd=cmd_prefix+[str(base/"factory_install.py"),"--target",str(target)]
            cwd=base
        if stage_only and not target.exists():
            cmd.append("--stage-only")
        elif stage_only and target.exists():
            emit("Pasta existente preservada; nenhuma dependência será alterada.")
            return target
        else:
            emit("Instalando dependências. Esta etapa pode baixar pacotes e Chromium.")
        creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)
        proc=subprocess.Popen(cmd,cwd=str(cwd),stdout=subprocess.PIPE,
                              stderr=subprocess.STDOUT,text=True,encoding="utf-8",
                              errors="replace",bufsize=1,creationflags=creationflags)
        try:
            for line in proc.stdout:
                if cancel.is_set():
                    if os.name=="nt":
                        subprocess.run(["taskkill","/PID",str(proc.pid),"/T","/F"],
                                       capture_output=True,timeout=12,
                                       creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
                    else: proc.terminate()
                    raise InterruptedError("Instalação interrompida. A pasta parcial foi preservada para retomada.")
                # Hide unlikely credentials in pip provider URLs.
                cleaned=line.strip().replace(str(Path.home()),"~")
                if cleaned:
                    emit(cleaned[:320])
            code=proc.wait()
            if code:
                raise RuntimeError(f"Instalador da Fairy retornou erro {code}. A instalação pode ser retomada.")
        finally:
            if proc.poll() is None:proc.terminate()
            if proc.stdout:proc.stdout.close()
    if not stage_only and not installed_state(target):
        raise RuntimeError("Instalador terminou sem status de instalação válido.")
    if not stage_only:
        # This is the owner-only HDD build. Public builds do not ship these
        # private samples; missing assets are handled as optional.
        from hdd.ui.factory_sfx import provision_private_sfx
        provision_private_sfx(target,emit)
    emit("Arquivos da Fairy prontos." if stage_only else "Fairy instalada. Configure idioma e provedores antes de iniciar.")
    return target
