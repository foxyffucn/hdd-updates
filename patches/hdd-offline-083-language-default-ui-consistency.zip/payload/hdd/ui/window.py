"""Interface inicial navegavel do H.D.D. System (v0.2-dev)."""
from datetime import datetime
from pathlib import Path
import platform
import shutil
import sys

from PySide6.QtCore import Qt, QSettings, QTimer, Signal, QSignalBlocker
from hdd.ui import windows_autostart
from hdd.ui.fairy_activation import activated
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QFrame, QHBoxLayout, QLabel,
    QMessageBox, QInputDialog, QLineEdit, QMenu, QToolButton, QDialog,
    QListWidget, QMainWindow, QPlainTextEdit, QPushButton, QScrollArea,
    QStackedWidget, QVBoxLayout, QWidget, QSizePolicy,
)

from hdd import __version__
from hdd.accounts import AccountStore
from hdd.quick_unlock import QuickUnlockStore
from hdd.ui.accounts_page import AccountAccessPage
from hdd.paths import asset_path, project_root
from hdd.ui.deep_dive_home import DeepDiveHome
from hdd.ui.update_center import UpdateCenterDialog
from hdd.ui.fairy_management import FairyManagementPage
from hdd.ui.fairy_install_backend import installed_state, default_target
from hdd.ui.boot import CinematicBoot
from hdd.ui.boot_glitch import LoginGlitchOverlay
from hdd.ui import boot_policy
from hdd.ui.ui_sfx import HDDUISounds
from hdd.ui.language_bridge import HDDLanguageBridge, LANGUAGES, painted_ui_text, _localized_paint


def text_label(value, style="body", wrap=False):
    widget = QLabel(painted_ui_text(value))
    widget.setProperty("_hdd_original",value)
    widget.setProperty("_hdd_last_localized",widget.text())
    widget.setObjectName(style)
    widget.setWordWrap(wrap)
    return widget


def button(value, kind="action"):
    widget = QPushButton(painted_ui_text(value))
    widget.setProperty("_hdd_original",value)
    widget.setProperty("_hdd_last_localized",widget.text())
    widget.setObjectName(kind)
    widget.setCursor(Qt.CursorShape.PointingHandCursor)
    widget.setMinimumHeight(42)
    return widget


def pane():
    result = QFrame()
    result.setObjectName("pane")
    return result


class DashboardPage(QWidget):
    locked = Signal()
    restart_requested = Signal()

    def __init__(self, settings, store, quick_unlock, parent=None):
        super().__init__(parent)
        self._settings = settings
        self.store = store
        self.quick_unlock = quick_unlock
        self.account = None
        self._nav = []
        self._update_panel = None
        # Patch 002: real bottom command dock, not a decorative duplicate.
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        sidebar = QFrame()
        sidebar.setObjectName("dockBar")
        sidebar.setFixedHeight(118)
        dock = QVBoxLayout(sidebar)
        dock.setContentsMargins(14, 6, 14, 7)
        dock.setSpacing(5)

        # Main navigation, preserved from Patch 002.
        side = QHBoxLayout()
        side.setContentsMargins(0,0,0,0)
        side.setSpacing(5)
        side.addWidget(text_label("H.D.D.", "dockLogo"))
        for index,title in enumerate(("INÍCIO","DIAGNÓSTICO","REGISTROS","AJUSTES","OPERADOR")):
            item=button(title,"dockbutton")
            item.setCheckable(True)
            item.setMinimumHeight(40)
            item.clicked.connect(lambda _checked=False,i=index:self.navigate(i))
            side.addWidget(item,1)
            self._nav.append(item)
        # Conditional Fairy module tab, only for real installed HDD builds.
        self.fairy_nav=button("FAIRY","dockbutton")
        self.fairy_nav.setCheckable(True)
        self.fairy_nav.clicked.connect(lambda _checked=False:self.navigate(5))
        self.fairy_nav.setVisible(False)
        side.addWidget(self.fairy_nav)
        update_action=button("ATUALIZAR","dockUpdate")
        update_action.setMinimumHeight(38)
        update_action.clicked.connect(self.show_update_center)
        side.addWidget(update_action)
        lock=button("BLOQUEAR","dockLock")
        lock.setMinimumHeight(38)
        lock.clicked.connect(self.request_lock)
        side.addWidget(lock)
        self.account_label=text_label("SEM SESSÃO","dockOperator")
        self.account_label.setMaximumWidth(112)
        self.account_label.setMinimumWidth(60)
        side.addWidget(self.account_label)
        dock.addLayout(side,1)

        # Rapid launch strip. Buttons remain fully functional from any page;
        # all tools are the same unique modeless instances as the holographic map.
        shortcuts=QHBoxLayout()
        shortcuts.setContentsMargins(3,0,3,0)
        shortcuts.setSpacing(6)
        dock_label=text_label("ACESSOS  //","dockQuickTitle")
        dock_label.setMinimumWidth(82)
        shortcuts.addWidget(dock_label)
        self.quick_buttons={}
        for key,title in (
            ("downloads","DOWNLOADS"),
            ("files","ARQUIVOS"),
            ("terminal","TERMINAL"),
            ("network","REDE"),
            ("remote","DISPOSITIVOS"),
        ):
            item=button(title,"dockShortcut")
            item.setMinimumHeight(34)
            item.clicked.connect(lambda _checked=False,what=key:self.open_quick_module(what))
            item.setToolTip("Abrir "+title.lower()+" pelo H.D.D.")
            shortcuts.addWidget(item,1)
            self.quick_buttons[key]=item
        self.tools_menu=QMenu(sidebar)
        self.tools_menu.setObjectName("dockToolsMenu")
        for title,key in (
            ("CENTRAL DE TAREFAS","tasks"),
            ("CENTRAL DE INTEGRAÇÕES","integration"),
            ("NÚCLEO DE INTELIGÊNCIA","intelligence_core"),
            ("PROTOCOLOS","protocols"),("CÓDIGO","code"),
            ("RECUPERAÇÃO / BACKUPS","recovery"),("MONITOR","monitor"),
            ("ARMAZENAMENTO","storage"),("APLICATIVOS","applications"),
            ("DIAGNÓSTICO E REPAROS","diagnostics"),
            ("CENTRAL DE ATUALIZAÇÕES","update"),
        ):
            action=self.tools_menu.addAction(title)
            action.triggered.connect(lambda _checked=False,what=key:self.open_quick_module(what))
        menu_button=QToolButton(sidebar)
        menu_button.setText("MAIS  ▾")
        menu_button.setObjectName("dockMore")
        menu_button.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
        menu_button.setMenu(self.tools_menu)
        menu_button.setMinimumHeight(34)
        shortcuts.addWidget(menu_button)
        dock.addLayout(shortcuts,1)

        main = QWidget()
        main.setObjectName("mainArea")
        content = QVBoxLayout(main)
        content.setContentsMargins(31, 26, 31, 19)
        content.setSpacing(18)
        heading = QHBoxLayout()
        self.heading = text_label("VISÃO GERAL", "eyebrow")
        heading.addWidget(self.heading)
        heading.addStretch()
        self.clock = text_label("", "mono")
        heading.addWidget(self.clock)
        content.addLayout(heading)
        self.clock_timer = QTimer(self)
        self.clock_timer.timeout.connect(self.update_clock)
        self.clock_timer.start(1000)
        self.update_clock()

        self.pages = QStackedWidget()
        self.pages.addWidget(self.create_home())
        self.pages.addWidget(self.create_diagnostics())
        self.pages.addWidget(self.create_logs())
        self.pages.addWidget(self.create_settings())
        self.pages.addWidget(self.create_account_data())
        self.fairy_manager=FairyManagementPage(self._settings)
        self.pages.addWidget(self.fairy_manager)
        self.fairy_manager.installation_changed.connect(self.refresh_fairy_presence)
        content.addWidget(self.pages, 1)
        footer = QHBoxLayout()
        footer.addWidget(text_label(f"H.D.D. SYSTEM  //  {__version__}", "eyebrow"))
        footer.addStretch()
        footer.addWidget(text_label("●  NÚCLEO LOCAL ATIVO", "online"))
        content.addLayout(footer)
        root.addWidget(main, 1)
        root.addWidget(sidebar, 0)

        self.add_log("Interface carregada.")
        self.refresh_fairy_presence()
        self.fairy_presence_timer=QTimer(self)
        self.fairy_presence_timer.timeout.connect(self.refresh_fairy_presence)
        self.fairy_presence_timer.start(3000)
        self.navigate(0)

    def open_quick_module(self,key):
        if key=="update":
            return self.show_update_center()
        routes={
            "downloads":"open_downloads",
            "files":"open_files",
            "terminal":"open_terminal",
            "network":"open_network",
            "remote":"open_remote",
            "protocols":"open_protocols",
            "integration":"open_integration",
            "intelligence_core":"open_intelligence_core",
            "tasks":"open_tasks",
            "code":"open_code",
            "recovery":"open_recovery",
            "monitor":"open_monitor",
            "storage":"open_storage",
            "applications":"open_applications",
            "diagnostics":"open_diagnostics",
        }
        method=routes.get(key)
        if method is None:
            return
        try:
            return getattr(self.home_view,method)()
        except Exception as exc:
            QMessageBox.warning(self,"Atalho H.D.D.","Não foi possível abrir o módulo: "+str(exc)[:240])

    def show_update_center(self):
        """Update window no longer freezes the parent UI on background clicks."""
        panel = self._update_panel
        if panel is not None:
            panel.show()
            panel.raise_()
            panel.activateWindow()
            return panel
        panel = UpdateCenterDialog(self)
        panel.setWindowModality(Qt.WindowModality.NonModal)
        self._update_panel = panel
        panel.finished.connect(lambda _result, p=panel: self._forget_update_panel(p))
        panel.show()
        return panel

    def auto_check_updates_once(self):
        if not self._settings.value("updates_auto_check",True,type=bool):
            return
        if not str(self._settings.value("updates_feed_url","")).strip():
            return  # No publisher configured, no network request.
        panel=self._update_panel
        if panel is None:
            panel=UpdateCenterDialog(self)
            self._update_panel=panel
            panel.finished.connect(lambda _result,p=panel:self._forget_update_panel(p))
        panel.check_now(auto=True)

    def _forget_update_panel(self, panel):
        if self._update_panel is panel:
            self._update_panel = None
        panel.deleteLater()

    def request_lock(self):
        """Do not leave any modeless operations available behind a locked session."""
        if not self.home_view.close_tools():
            return
        if self._update_panel is not None and self._update_panel.isVisible():
            if not self._update_panel.close():
                return
        self.locked.emit()

    def update_clock(self):
        self.clock.setText(datetime.now().strftime("%d/%m/%Y  •  %H:%M:%S"))

    def refresh_fairy_presence(self):
        target=Path(str(self._settings.value("fairy_install_target",str(default_target()))))
        present=bool(installed_state(target))
        if self.fairy_nav.isVisible()!=present:
            self.fairy_nav.setVisible(present)
        if not present and self.pages.currentIndex()==5:
            self.navigate(0)
        if self.pages.currentIndex()==5:
            self.fairy_manager.refresh()
        self.refresh_startup_controls()

    def navigate(self, index):
        titles = ("VISÃO GERAL", "DIAGNÓSTICO", "REGISTROS", "CONFIGURAÇÕES", "OPERADOR", "FAIRY")
        if index==5 and not installed_state(Path(str(self._settings.value("fairy_install_target",str(default_target()))))):
            return
        self.pages.setCurrentIndex(index)
        self.heading.setText("SISTEMA  /  " + titles[index])
        for n, item in enumerate(self._nav):
            item.setChecked(n == index)
        self.fairy_nav.setChecked(index==5)
        if index == 1:
            self.refresh_diagnostics()
        elif index == 4:
            self.refresh_fairy_data()
        elif index==5:
            self.fairy_manager.refresh()

    def create_home(self):
        # Interactive 2.5D local map; original module pages stay intact.
        self.home_view = DeepDiveHome(self._settings)
        self.home_view.module_requested.connect(self.navigate)
        return self.home_view

    def create_diagnostics(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 5, 0, 0)
        layout.setSpacing(17)
        layout.addWidget(text_label("DIAGNÓSTICO LOCAL", "sectionTitle"))
        layout.addWidget(text_label(
            "Leitura do ambiente atual. Não executa varreduras externas nem acessa a Fairy.",
            "muted", True
        ))
        card = pane()
        inside = QVBoxLayout(card)
        inside.setContentsMargins(22, 19, 22, 19)
        inside.setSpacing(15)
        self.diagnostics = []
        for field in ("PLATAFORMA", "VERSÃO DO PYTHON", "ARMAZENAMENTO DA UNIDADE", "RECURSOS INSTALADOS"):
            group = QHBoxLayout()
            group.addWidget(text_label(field, "eyebrow"))
            group.addStretch()
            value = text_label("–", "mono")
            value.setAlignment(Qt.AlignmentFlag.AlignRight | Qt.AlignmentFlag.AlignVCenter)
            group.addWidget(value)
            inside.addLayout(group)
            self.diagnostics.append(value)
        layout.addWidget(card)
        reload_btn = button("ATUALIZAR INFORMAÇÕES", "primary")
        reload_btn.clicked.connect(self.refresh_diagnostics)
        layout.addWidget(reload_btn, 0, Qt.AlignmentFlag.AlignLeft)
        advanced = button("ABRIR DIAGNÓSTICO E REPAROS  →", "primary")
        advanced.clicked.connect(self.home_view.open_diagnostics)
        layout.addWidget(advanced, 0, Qt.AlignmentFlag.AlignLeft)
        layout.addStretch()
        return page

    def refresh_diagnostics(self):
        try:
            disk = shutil.disk_usage(str(project_root()))
            used = disk.total - disk.free
            storage = f"{used / 2**30:.1f} / {disk.total / 2**30:.1f} GiB"
            resources = sum(
                1 for p in asset_path().rglob("*")
                if p.is_file() and p.name not in (".gitkeep", "README.md")
            )
            values = (
                f"{platform.system()} {platform.release()}",
                sys.version.split()[0],
                storage,
                f"{resources} arquivos de mídia",
            )
            for element, value in zip(self.diagnostics, values):
                element.setText(value)
            self.add_log("Diagnóstico do ambiente atualizado.")
        except OSError as exc:
            self.add_log(f"Falha ao ler diagnósticos: {exc}")

    def refresh_startup_controls(self):
        if not hasattr(self,"windows_fairy_toggle"):return
        fairy_ready=activated(windows_autostart.fairy_target(self._settings))
        self.windows_fairy_toggle.setVisible(fairy_ready)
        with QSignalBlocker(self.windows_hdd_toggle):
            self.windows_hdd_toggle.setChecked(windows_autostart.hdd_enabled())
        with QSignalBlocker(self.windows_fairy_toggle):
            self.windows_fairy_toggle.setChecked(
                self._settings.value(windows_autostart.FAIRY_PREF,True,type=bool)
                if fairy_ready else False)
        self._set_startup_language(
            str(self._settings.value("interface_language","en-US")))

    def _set_startup_language(self,locale):
        tr={
           "en-US":(
             "Start H.D.D. automatically when Windows starts",
             "Start Fairy automatically when Windows starts",
             "H.D.D. is off by default. Fairy appears only after first activation "
             "and is on by default; the options are independent."),
           "pt-BR":(
             "Iniciar o H.D.D. com o Windows",
             "Iniciar a Fairy com o Windows",
             "H.D.D. desativado por padrão. Fairy disponível após a primeira ativação, "
             "ativada por padrão; opções independentes."),
           "es-ES":(
             "Iniciar H.D.D. con Windows",
             "Iniciar Fairy con Windows",
             "H.D.D. desactivado de forma predeterminada. Fairy aparece tras la "
             "primera activación, activada por defecto; controles independientes."),
        }.get(locale)
        if tr is None:tr=(
             "Start H.D.D. automatically when Windows starts",
             "Start Fairy automatically when Windows starts",
             "Independent Windows startup settings.")
        if hasattr(self,"windows_hdd_toggle"):
            self.windows_hdd_toggle.setText(tr[0])
            self.windows_fairy_toggle.setText(tr[1])
            self.windows_startup_note.setText(tr[2])

    def _toggle_windows_startup(self,what,enabled):
        try:
            windows_autostart.enable_preference(self._settings,what,enabled)
            self.windows_startup_error.setText("")
        except (OSError,RuntimeError) as exc:
            self.windows_startup_error.setText("Windows startup: "+str(exc))
            QMessageBox.warning(self,"H.D.D. // WINDOWS STARTUP",str(exc))
        self.refresh_startup_controls()

    def create_logs(self):
        page = QWidget()
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 5, 0, 0)
        layout.addWidget(text_label("REGISTROS DA SESSÃO", "sectionTitle"))
        layout.addWidget(text_label(
            "Eventos desta execução. Não é um console de comandos.", "muted"
        ))
        self.log_output = QPlainTextEdit()
        self.log_output.setReadOnly(True)
        self.log_output.setObjectName("log")
        self._session_events=[]
        layout.addWidget(self.log_output, 1)
        buttons = QHBoxLayout()
        copy = button("COPIAR REGISTROS", "primary")
        copy.clicked.connect(self.copy_logs)
        clear = button("LIMPAR TELA", "quiet")
        clear.clicked.connect(self.clear_logs)
        buttons.addWidget(copy)
        buttons.addWidget(clear)
        buttons.addStretch()
        layout.addLayout(buttons)
        return page

    def add_log(self, message):
        stamp = datetime.now().strftime("%H:%M:%S")
        # Store only this session's original event strings. Re-translate when
        # language changes; never replace path fragments or process output.
        self._session_events.append((stamp,str(message)))
        if len(self._session_events)>800:
            self._session_events=self._session_events[-800:]
        self.log_output.appendPlainText(
            f"[{stamp}] HDD :: {painted_ui_text(str(message))}")

    def clear_logs(self):
        self._session_events.clear()
        self.log_output.clear()

    def retranslate_logs(self,_code=None):
        if not hasattr(self,"log_output"):return
        scroll=self.log_output.verticalScrollBar()
        near_end=(scroll.maximum()-scroll.value())<=3
        code=_code or str(self._settings.value("interface_language","en-US"))
        lines=[f"[{stamp}] HDD :: {_localized_paint(code,source)}"
               for stamp,source in self._session_events]
        self.log_output.setPlainText("\n".join(lines))
        if near_end:scroll.setValue(scroll.maximum())

    def copy_logs(self):
        QApplication.clipboard().setText(self.log_output.toPlainText())
        self.add_log("Registros copiados para a área de transferência.")

    def create_settings(self):
        page = QWidget()
        page.setObjectName("settingsPage")
        layout = QVBoxLayout(page)
        layout.setContentsMargins(0, 5, 0, 0)
        layout.setSpacing(12)
        layout.addWidget(text_label("PREFERÊNCIAS DE INTERFACE", "sectionTitle"))
        layout.addWidget(text_label(
            "Estas preferências são salvas localmente no Windows.", "muted"
        ))

        # This page contains more controls than the available window height.
        # Scroll instead of compressing widget rows until text is clipped.
        self.settings_scroll = QScrollArea(page)
        self.settings_scroll.setObjectName("settingsScroll")
        self.settings_scroll.setWidgetResizable(True)
        self.settings_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.settings_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.settings_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAsNeeded)
        content = QWidget()
        content.setObjectName("settingsContent")
        scroll_layout = QVBoxLayout(content)
        scroll_layout.setContentsMargins(2, 2, 13, 8)
        scroll_layout.setSpacing(13)
        card = pane()
        card.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        inner = QVBoxLayout(card)
        inner.setContentsMargins(22, 22, 22, 22)
        inner.setSpacing(13)
        # The Fairy UI-only language is shared through userdata/ui_language.json.
        # This is independent from microphone language and spoken replies.
        language_label=text_label("Idioma da interface / Interface language", "eyebrow")
        inner.addWidget(language_label)
        self.interface_language_selector = QComboBox()
        self.interface_language_selector.setObjectName("hddInterfaceLanguage")
        for language, title in LANGUAGES.items():
            self.interface_language_selector.addItem(title,language)
        inner.addWidget(self.interface_language_selector)
        scanlines = QCheckBox("Ativar linhas de varredura nos gráficos")
        scanlines.setChecked(self._settings.value("scanlines", True, type=bool))
        scanlines.toggled.connect(self.set_scanlines)
        scanlines.setMinimumHeight(38)
        inner.addWidget(scanlines)
        bloom_toggle = QCheckBox("Bloom real (destaques luminosos com desfoque)")
        bloom_toggle.setChecked(self._settings.value("boot_bloom", True, type=bool))
        bloom_toggle.toggled.connect(lambda value: self._settings.setValue("boot_bloom", value))
        bloom_toggle.setMinimumHeight(38)
        inner.addWidget(bloom_toggle)
        inner.addWidget(text_label("BOOT SEQUENCE  /  CONFIGURAÇÃO POR EVENTO", "eyebrow"))
        self.custom_boot_panel = QFrame(card)
        self.custom_boot_panel.setObjectName("bootCustomPanel")
        custom_layout = QVBoxLayout(self.custom_boot_panel)
        custom_layout.setContentsMargins(15, 13, 15, 13)
        custom_layout.setSpacing(9)
        custom_heading = text_label("ESCOLHA A ANIMAÇÃO DE CADA EVENTO", "eyebrow")
        custom_heading.setMinimumHeight(26)
        custom_layout.addWidget(custom_heading)
        self.custom_boot_selectors = {}
        for event,label,_default in boot_policy.CUSTOM_EVENTS:
            title = text_label(label.upper(), "eyebrow")
            title.setMinimumHeight(25)
            custom_layout.addWidget(title)
            selector = QComboBox()
            selector.setObjectName("customBoot_"+event)
            for option, key in boot_policy.CUSTOM_STYLES:
                selector.addItem(option,key)
            saved = boot_policy.preview_event_styles(self._settings)[event]
            selector.setCurrentIndex(max(0,selector.findData(saved)))
            selector.setMinimumHeight(43)
            selector.currentIndexChanged.connect(
                lambda _index,ev=event,control=selector:
                    self.set_custom_boot_event(ev,control.currentData())
            )
            custom_layout.addWidget(selector)
            self.custom_boot_selectors[event] = selector
        inner.addWidget(self.custom_boot_panel)
        self.custom_boot_hint = text_label(
            "Mude qualquer opção acima para ativar automaticamente sua "
            "combinação personalizada. Você também pode usar um modelo pronto "
            "abaixo, sem perder suas escolhas anteriores.",
            "muted", True
        )
        inner.addWidget(self.custom_boot_hint)
        inner.addWidget(text_label("BOOT SEQUENCE  /  MODELOS PRONTOS (OPCIONAL)", "eyebrow"))
        self.boot_trigger = QComboBox()
        for title, key in boot_policy.MODES:
            self.boot_trigger.addItem(title, key)
        self.boot_trigger.setCurrentIndex(max(
            0, self.boot_trigger.findData(boot_policy.current_mode(self._settings))
        ))
        self.boot_trigger.setMinimumHeight(43)
        self.boot_trigger.currentIndexChanged.connect(self.set_boot_trigger)
        inner.addWidget(self.boot_trigger)
        self.boot_trigger_info = text_label(
            "Os modelos prontos preenchem as três opções acima. "
            "Editar uma delas ativa o modo personalizado automaticamente.",
            "muted", True
        )
        inner.addWidget(self.boot_trigger_info)
        # Three independent event choices instead of combinatorial preset lists.
        # Values are stored separately and never change during UI reconstruction.
        inner.addWidget(text_label(
            "BOOT SEQUENCE  /  ESTILO PADRÃO E REPRODUÇÃO MANUAL", "eyebrow"
        ))
        self.boot_mode = QComboBox()
        for title, key in boot_policy.STYLES:
            self.boot_mode.addItem(title, key)
        style = boot_policy.current_style(self._settings)
        self.boot_mode.setCurrentIndex(max(0, self.boot_mode.findData(style)))
        self.boot_mode.currentIndexChanged.connect(self.set_boot_mode)
        self.boot_mode.setMinimumHeight(43)
        inner.addWidget(self.boot_mode)
        self.boot_style_info = text_label(
            "Compacta: logo Helios → glitch → H.D.D. Loading, sem "
            "sincronização numérica e sem códigos falsos. Os efeitos visuais "
            "permanecem os mesmos.",
            "muted", True
        )
        inner.addWidget(self.boot_style_info)
        self.refresh_boot_style_info()

        inner.addWidget(text_label("Velocidade das animações", "eyebrow"))
        self.boot_speed = QComboBox()
        self.boot_speed.addItem("Lenta", "slow")
        self.boot_speed.addItem("Normal", "normal")
        self.boot_speed.addItem("Rápida", "fast")
        self.boot_speed.setCurrentIndex(max(
            0, self.boot_speed.findData(self._settings.value("boot_speed", "normal"))
        ))
        self.boot_speed.currentIndexChanged.connect(
            lambda _i: self._settings.setValue("boot_speed", self.boot_speed.currentData())
        )
        self.boot_speed.setMinimumHeight(43)
        inner.addWidget(self.boot_speed)

        self.boot_audio = QCheckBox("Sons de inicialização (quando houver arquivos WAV)")
        self.boot_audio.setChecked(self._settings.value("boot_audio", True, type=bool))
        self.boot_audio.toggled.connect(
            lambda checked: self._settings.setValue("boot_audio", checked)
        )
        self.boot_audio.setMinimumHeight(38)
        inner.addWidget(self.boot_audio)

        # Fairy UI sounds, separately controllable from cinematic boot audio.
        self.ui_sounds_toggle = QCheckBox("Sons de interface (cliques e menus da Fairy)")
        self.ui_sounds_toggle.setChecked(
            self._settings.value("ui_sounds_enabled", True, type=bool))
        self.ui_sounds_toggle.toggled.connect(
            lambda active:self._settings.setValue("ui_sounds_enabled",active))
        self.ui_sounds_toggle.setMinimumHeight(38)
        inner.addWidget(self.ui_sounds_toggle)

        self.boot_code = QCheckBox("Exibir mensagens técnicas do carregamento")
        self.boot_code.setChecked(self._settings.value("boot_code", True, type=bool))
        self.boot_code.toggled.connect(
            lambda checked: self._settings.setValue("boot_code", checked)
        )
        self.boot_code.setMinimumHeight(38)
        inner.addWidget(self.boot_code)

        inner.addWidget(text_label("ACESSO RÁPIDO  /  OPERADOR LOCAL", "eyebrow"))
        self.auto_login_check = QCheckBox("Entrar automaticamente no H.D.D. sem senha ou PIN")
        self.auto_login_check.setChecked(
            self.account is not None and
            self._settings.value("auto_login_account_id", "") == self.account.id
        )
        self.auto_login_check.toggled.connect(self.toggle_auto_login)
        self.auto_login_check.setMinimumHeight(38)
        inner.addWidget(self.auto_login_check)
        self.auto_login_status=text_label("", "autoLoginStatus", True)
        inner.addWidget(self.auto_login_status)
        self.refresh_auto_login_status()
        inner.addWidget(text_label(
            "Somente neste usuário do Windows. Ao ativar, qualquer pessoa que use "
            "esta sessão do Windows poderá acessar os dados locais do H.D.D. "
            "A senha da conta será solicitada uma vez para confirmar a escolha. "
            "O botão BLOQUEAR continua exigindo login nesta execução. "
            "Não altera o login nem o PIN do Windows.",
            "muted", True
        ))
        inner.addWidget(text_label(
            "As contas locais possuem senha. A sincronização online ainda está em desenvolvimento.",
            "muted", True
        ))
        # Windows Run entries are opt-in for H.D.D. and independently
        # manageable for Fairy AFTER its one-time confirmed activation.
        inner.addWidget(text_label("WINDOWS STARTUP  /  SESSION OPTIONS","eyebrow"))
        self.windows_hdd_toggle=QCheckBox("Start H.D.D. automatically when Windows starts")
        self.windows_hdd_toggle.setObjectName("hddWindowsAutostart")
        self.windows_hdd_toggle.setChecked(windows_autostart.hdd_enabled())
        self.windows_hdd_toggle.toggled.connect(
            lambda checked:self._toggle_windows_startup("hdd",checked))
        inner.addWidget(self.windows_hdd_toggle)
        self.windows_fairy_toggle=QCheckBox("Start Fairy automatically when Windows starts")
        self.windows_fairy_toggle.setObjectName("fairyWindowsAutostart")
        self.windows_fairy_toggle.setChecked(False)
        self.windows_fairy_toggle.toggled.connect(
            lambda checked:self._toggle_windows_startup("fairy",checked))
        inner.addWidget(self.windows_fairy_toggle)
        self.windows_startup_note=text_label(
            "H.D.D. starts disabled. Fairy appears after the first successful Reboot "
            "and defaults to enabled. Both can be changed independently.",
            "muted",True)
        inner.addWidget(self.windows_startup_note)
        self.windows_startup_error=text_label("","muted",True)
        inner.addWidget(self.windows_startup_error)
        self.refresh_startup_controls()

        # Keep long descriptions at their real height even if window is short.
        scroll_layout.addWidget(card)
        replay = button("REPRODUZIR INICIALIZAÇÃO", "primary")
        replay.clicked.connect(self.restart_requested.emit)
        replay.setMinimumHeight(44)
        scroll_layout.addWidget(replay, 0, Qt.AlignmentFlag.AlignLeft)
        scroll_layout.addStretch(1)
        self.settings_scroll.setWidget(content)
        layout.addWidget(self.settings_scroll, 1)
        return page

    def _auto_login_id(self):
        # Read QSettings instead of trusting widget appearance.
        return str(self._settings.value("auto_login_account_id","") or "").strip()

    def refresh_auto_login_status(self):
        account=self.account
        saved=self._auto_login_id()
        is_enabled=bool(account is not None and saved==account.id)
        self.auto_login_check.blockSignals(True)
        try:
            self.auto_login_check.setChecked(is_enabled)
        finally:
            self.auto_login_check.blockSignals(False)
        if is_enabled:
            self.auto_login_status.setText(
                "● ATIVO  //  O H.D.D. entrará na conta "+
                account.username+" automaticamente nas próximas inicializações.")
        elif saved:
            self.auto_login_status.setText(
                "● CONFIGURADO PARA OUTRA CONTA  //  Não alterado.")
        else:
            self.auto_login_status.setText(
                "○ DESATIVADO  //  A identificação continuará obrigatória.")
        return is_enabled

    def toggle_auto_login(self,enabled):
        from hdd.ui.auto_login_consent import AutoLoginConsentDialog
        account=self.account
        if account is None:
            self.refresh_auto_login_status()
            return
        old=self._auto_login_id()
        if not enabled:
            # Only a deliberate OFF click from the current account can
            # remove this preference. Loading windows must never change it.
            if old==account.id:
                self._settings.remove("auto_login_account_id")
                self._settings.sync()
                if self._settings.status()!=QSettings.Status.NoError:
                    self.auto_login_status.setText(
                        "Falha ao salvar as preferências do Windows.")
                    self.refresh_auto_login_status()
                    return
                self.add_log("Entrada automática local desativada pelo operador.")
            self.refresh_auto_login_status()
            return
        def verify(username,password):
            verified=self.store.authenticate(username,password)
            return bool(verified is not None and verified.id==account.id)
        modal=AutoLoginConsentDialog(account,verify,self)
        if modal.exec()!=QDialog.DialogCode.Accepted:
            self.refresh_auto_login_status()
            return
        self._settings.setValue("auto_login_account_id",account.id)
        self._settings.sync()
        if self._settings.status()!=QSettings.Status.NoError or self._auto_login_id()!=account.id:
            self.auto_login_status.setText("Não foi possível salvar o acesso automático.")
            self.refresh_auto_login_status()
            QMessageBox.warning(self,"H.D.D. // Configuração",
                                "Falha ao guardar a preferência no Windows.")
            return
        self.refresh_auto_login_status()
        self.add_log("Entrada automática local ativada e salva para próximas inicializações.")

    def create_account_data(self):
        """Read-only Fairy bridge, with uncompressed labels in a scrolling page."""
        page = QWidget()
        page.setObjectName("fairyAccountPage")
        outer = QVBoxLayout(page)
        outer.setContentsMargins(0,0,0,0)
        outer.setSpacing(10)
        outer.addWidget(text_label("CONTA / MEMÓRIA DA FAIRY", "sectionTitle"))
        self.fairy_scroll = QScrollArea(page)
        self.fairy_scroll.setObjectName("fairyScroll")
        self.fairy_scroll.setWidgetResizable(True)
        self.fairy_scroll.setFrameShape(QFrame.Shape.NoFrame)
        self.fairy_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        inner_page = QWidget()
        inner_page.setObjectName("fairyContent")
        layout = QVBoxLayout(inner_page)
        layout.setContentsMargins(3,4,14,12)
        layout.setSpacing(15)
        self.profile_identity = text_label("SEM SESSÃO", "mono")
        layout.addWidget(self.profile_identity)
        layout.addWidget(text_label(
            "Quando a integração estiver pronta, as memórias, rotinas e "
            "tarefas que você autorizar serão registradas pela Fairy e "
            "aparecerão aqui automaticamente, sem formulários manuais.",
            "muted", True
        ))

        state = pane()
        state.setObjectName("fairyConnectionsPane")
        state.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
        info = QVBoxLayout(state)
        info.setContentsMargins(18, 15, 18, 15)
        info.setSpacing(11)
        connection_title = None
        connection_title = text_label("CONEXÕES E SINCRONIZAÇÃO", "eyebrow")
        connection_title.setMinimumHeight(23)
        info.addWidget(connection_title)
        self.fairy_connection = text_label(
            "FAIRY NO PC       //  AINDA NÃO CONECTADA", "mono"
        )
        self.cloud_connection = text_label(
            "NUVEM            //  NÃO CONFIGURADA", "mono"
        )
        self.android_connection = text_label(
            "OUTROS DISPOSITIVOS   //  NÃO VINCULADOS", "mono"
        )
        for label in (self.fairy_connection, self.cloud_connection, self.android_connection):
            label.setMinimumHeight(31)
            label.setWordWrap(True)
            label.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Minimum)
            info.addWidget(label)
        layout.addWidget(state)

        layout.addWidget(text_label("MEMÓRIAS E ATIVIDADES REGISTRADAS PELA FAIRY", "eyebrow"))
        self.fairy_memory_list = QListWidget()
        self.fairy_memory_list.setObjectName("reminderList")
        self.fairy_memory_list.setMinimumHeight(115)
        self.fairy_memory_list.setMaximumHeight(175)
        layout.addWidget(self.fairy_memory_list)

        layout.addWidget(text_label("ROTINAS E LEMBRETES DA FAIRY", "eyebrow"))
        self.fairy_reminder_list = QListWidget()
        self.fairy_reminder_list.setObjectName("reminderList")
        self.fairy_reminder_list.setMinimumHeight(115)
        self.fairy_reminder_list.setMaximumHeight(175)
        layout.addWidget(self.fairy_reminder_list)

        self.account_status = text_label(
            "Nenhum dispositivo está sincronizando ainda. A lista será "
            "atualizada automaticamente quando a integração estiver pronta.",
            "muted", True
        )
        layout.addWidget(self.account_status)
        self.legacy_status = text_label("", "muted", True)
        layout.addWidget(self.legacy_status)

        actions = QHBoxLayout()
        refresh = button("ATUALIZAR INFORMAÇÕES", "quiet")
        refresh.clicked.connect(self.refresh_fairy_data)
        actions.addWidget(refresh)
        forget = button("ESQUECER PIN DESTE PC", "quiet")
        forget.clicked.connect(self.forget_saved_pin)
        actions.addWidget(forget)
        actions.addStretch()
        layout.addLayout(actions)
        layout.addStretch(1)
        self.fairy_scroll.setWidget(inner_page)
        outer.addWidget(self.fairy_scroll, 1)
        return page

    def set_account(self, account):
        """Refresh the account view without creating fake Fairy reminders."""
        self.account = account
        name = account.username if account else "NENHUMA CONTA"
        self.account_label.setText(name.upper()[:13])
        self.account_label.setToolTip("OPERADOR / " + name.upper())
        self.profile_identity.setText("OPERADOR: " + name)
        self.home_view.set_operator(name)
        self.refresh_auto_login_status()
        self.refresh_fairy_data()
        self.navigate(0)

    def refresh_fairy_data(self):
        self.fairy_memory_list.clear()
        self.fairy_reminder_list.clear()
        self.fairy_connection.setText("FAIRY NO PC       //  AINDA NÃO CONECTADA")
        self.cloud_connection.setText("NUVEM            //  NÃO CONFIGURADA")
        self.android_connection.setText("OUTROS DISPOSITIVOS   //  NÃO VINCULADOS")
        if self.account is None:
            self.fairy_memory_list.addItem("Entre na sua conta para ver registros.")
            self.fairy_reminder_list.addItem("Entre na sua conta para ver lembretes.")
            self.legacy_status.setText("")
            return

        entries = self.store.list_records(self.account.id)
        fairy_count = 0
        legacy_count = 0
        for record in entries:
            payload = record.get("payload") or {}
            source = payload.get("source_app", payload.get("origin", ""))
            if source != "fairy":
                legacy_count += 1
                continue
            fairy_count += 1
            kind = record.get("kind")
            title = str(payload.get("title") or payload.get("summary") or
                        payload.get("text") or "Registro da Fairy").strip()
            title = title.replace("\\n", " ").replace("\\r", " ")[:170]
            when = str(payload.get("next_due") or payload.get("due_at") or "").strip()
            detail = (title + ("  /  " + when[:36] if when else ""))
            if kind == "reminder":
                self.fairy_reminder_list.addItem(detail)
            else:
                self.fairy_memory_list.addItem(detail)

        if self.fairy_memory_list.count() == 0:
            self.fairy_memory_list.addItem("Nenhuma memória automática recebida da Fairy.")
        if self.fairy_reminder_list.count() == 0:
            self.fairy_reminder_list.addItem("Nenhum lembrete automático recebido da Fairy.")
        self.account_status.setText(
            "Registros identificados como Fairy neste PC: " + str(fairy_count) +
            ". Nenhuma sincronização remota está ativa."
        )
        self.legacy_status.setText(
            (str(legacy_count) + " registro(s) manuais do protótipo anterior "
             "continuam preservados no banco local, sem exclusão.")
            if legacy_count else ""
        )

    def forget_saved_pin(self):
        if self.account is None:
            return
        self.quick_unlock.forget(self.account.id)
        self.account_status.setText(
            "PIN deste PC desativado. A conta e os dados permanecem salvos."
        )

    def set_scanlines(self, checked):
        self._settings.setValue("scanlines", checked)
        self.home_view.set_scanlines(checked)
        self.add_log("Linhas de varredura " + ("ativadas." if checked else "desativadas."))

    def refresh_boot_style_info(self):
        mode = self.boot_trigger.currentData()
        style = self.boot_mode.currentData()
        # Event editor is THE main boot UI: always visible for every preset.
        self.custom_boot_panel.setVisible(True)
        preview = boot_policy.preview_event_styles(self._settings, mode)
        for event,selector in self.custom_boot_selectors.items():
            position = selector.findData(preview[event])
            selector.blockSignals(True)
            try:
                selector.setCurrentIndex(max(0,position))
            finally:
                selector.blockSignals(False)
        if mode == "custom":
            self.boot_trigger_info.setText(
                "PERSONALIZADO ATIVO  //  As três animações acima são "
                "independentes e foram salvas automaticamente."
            )
        else:
            self.boot_trigger_info.setText(
                "MODELO PRONTO ATIVO  //  As opções acima mostram o "
                "resultado do modelo. Mude qualquer uma para personalizar."
            )
        if style in ("compact","compact_quick"):
            text = ("COMPACTA  //  Helios → glitch → H.D.D. Loading. "
                    "Sem números nem códigos fictícios.")
        elif style in ("intermediate","intermediate_quick"):
            text = ("INTERMEDIÁRIA  //  Helios → números → H.D.D. Loading. "
                    "Sem etapa de códigos.")
        else:
            text = ("COMPLETA  //  Helios → números → códigos → H.D.D. Loading.")
        if mode == "custom":
            text += (" Este estilo é usado para REPRODUZIR INICIALIZAÇÃO "
                     "manualmente; os três eventos usam os estilos acima.")
        else:
            text += (" Este estilo determina a animação do modelo pronto "
                     "e da reprodução manual.")
        self.boot_style_info.setText(text)

    def set_custom_boot_event(self,event,style):
        # Editing a preset copies its three visible events first, so the
        # unedited choices keep their meaning. Saved custom presets persist
        # until the operator deliberately changes an event.
        current = self.boot_trigger.currentData()
        if current != "custom":
            choices = boot_policy.preview_event_styles(self._settings,current)
            choices[event] = style
            for key,value in choices.items():
                boot_policy.set_custom_style(self._settings,key,value)
            boot_policy.change_mode(
                self._settings,"custom",boot_policy.latest_update_id()
            )
            selector_index = self.boot_trigger.findData("custom")
            self.boot_trigger.blockSignals(True)
            try:
                self.boot_trigger.setCurrentIndex(selector_index)
            finally:
                self.boot_trigger.blockSignals(False)
        else:
            boot_policy.set_custom_style(self._settings,event,style)
        self.refresh_boot_style_info()
        self.add_log("Boot personalizado: "+event+" → "+style+".")

    def set_boot_trigger(self, _index):
        mode = self.boot_trigger.currentData()
        boot_policy.change_mode(
            self._settings, mode, boot_policy.latest_update_id()
        )
        self.refresh_boot_style_info()
        self.add_log("Frequência da sequência cinematográfica: "+mode+".")

    def set_boot_mode(self, _index):
        mode = self.boot_mode.currentData()
        self._settings.setValue("boot_mode", mode)
        self._settings.setValue("skip_boot", False)
        self._settings.sync()
        self.refresh_boot_style_info()
        self.add_log("Estilo da sequência cinematográfica: " + mode + ".")


STYLE = """
QMainWindow { background: #07121d; }
QWidget { background: transparent; }
QWidget#mainArea, QStackedWidget { background: #081826; }
QLabel { color: #e6f6fd; font-family: 'Segoe UI'; }
QLabel#eyebrow { color: #80aabd; font: 600 10px 'Consolas'; letter-spacing: 1px; }
QLabel#mono { color: #9edcf0; font: 600 13px 'Consolas'; }
QLabel#online { color: #7ce0bb; font: 600 11px 'Consolas'; }
QLabel#mega { font: 900 75px 'zero 5', 'Segoe UI'; color: #f0fbff; }
QLabel#subtitle { font: 700 18px 'Consolas'; color: #9bc9df; }
QLabel#sectionTitle { font: 800 28px 'zero 5', 'Segoe UI'; color: #eaf9ff; }
QLabel#heroTitle { font: 900 45px 'zero 5', 'Segoe UI'; color: #f0faff; }
QLabel#sideLogo { font: 900 34px 'zero 5', 'Segoe UI'; color: #eaf9ff; }
QLabel#body { font-size: 16px; }
QLabel#muted { color: #b4cfdb; font: 14px 'Segoe UI'; }
QWidget#settingsPage QLabel#eyebrow {
    color: #9cd9ec; font: 700 12px 'Consolas';
    padding: 5px 1px;
}
QWidget#settingsPage QLabel#muted {
    color: #c2dbe7; font: 14px 'Segoe UI';
    padding: 3px 1px;
}
QWidget#settingsPage QCheckBox {
    color: #e3f7ff; font: 14px 'Segoe UI';
    spacing: 11px;
}
QWidget#settingsPage QComboBox {
    font: 14px 'Segoe UI';
    color: #e9faff;
}
QScrollArea#settingsScroll, QWidget#settingsContent {
    background: transparent;
    border: none;
}
QScrollArea#settingsScroll QScrollBar:vertical {
    background: #0c2537;
    width: 9px; margin: 1px;
}
QScrollArea#settingsScroll QScrollBar::handle:vertical {
    background: #438ba7;
    border-radius: 4px;
    min-height: 35px;
}
QScrollArea#settingsScroll QScrollBar::add-line:vertical,
QScrollArea#settingsScroll QScrollBar::sub-line:vertical {
    height: 0px; background: transparent;
}
QWidget#fairyAccountPage QLabel#eyebrow {
    color: #a2e0f1;
    font: 700 12px 'Consolas';
    padding: 3px 1px;
}
QWidget#fairyAccountPage QLabel#mono {
    color: #d4f5ff;
    font: 600 13px 'Consolas';
    padding: 4px 2px;
}
QWidget#fairyAccountPage QLabel#muted {
    color: #c9e1ed;
    font: 14px 'Segoe UI';
    padding: 3px 1px;
}
QScrollArea#fairyScroll, QWidget#fairyContent {
    border: none;
    background: transparent;
}
QScrollArea#fairyScroll QScrollBar:vertical {
    background: #0c2537;
    width: 9px; margin: 1px;
}
QScrollArea#fairyScroll QScrollBar::handle:vertical {
    background: #438ba7; border-radius: 4px; min-height: 35px;
}
QScrollArea#fairyScroll QScrollBar::add-line:vertical,
QScrollArea#fairyScroll QScrollBar::sub-line:vertical {
    height: 0px; background: transparent;
}
QFrame#bootCustomPanel {
    background: rgba(12, 46, 70, 185);
    border: 1px solid #397f9b;
    border-radius: 6px;
}
QFrame#bootCustomPanel QLabel#eyebrow {
    border: none;
    color: #a3dff1;
    background: transparent;
    font: 700 12px 'Consolas';
}
QFrame#bootCustomPanel QComboBox {
    color: #e2f9ff;
    background: #10374e;
    border: 1px solid #4e91ac;
    border-radius: 4px;
    padding: 5px 10px;
    font: 14px 'Segoe UI';
}
QLabel#autoLoginStatus {
    color: #9ddfed; font: 700 12px 'Consolas';
    padding: 4px 2px;
}
QFrame#sidebar { background: #091d2b; border-right: 1px solid #24516b; }
/* Patch 002 bottom in-world command dock */
/* Patch 004: separate in-world update action */
QPushButton#dockUpdate {
    color: #acf0f7; background: #113950;
    border: 1px solid #41829a; border-radius: 2px;
    padding: 5px 7px; font: 700 10px 'Segoe UI';
}
QPushButton#dockUpdate:hover { color: white; background: #27627b; }

QFrame#dockBar {
    background: #071c2c;
    border-top: 1px solid #39738c;
    border-bottom: 1px solid #123549;
}
QLabel#dockQuickTitle {
    color: #74b4ce;
    font: 700 9px 'Consolas';
    letter-spacing: 1px;
}
QPushButton#dockShortcut, QToolButton#dockMore {
    color: #b6e3f3;
    background: rgba(24, 62, 83, 150);
    border: 1px solid #366b86;
    border-radius: 3px;
    padding: 5px 8px;
    font: 700 10px 'Segoe UI';
}
QPushButton#dockShortcut:hover, QToolButton#dockMore:hover {
    color: #fff;
    background: #235b75;
    border-color: #88d7e9;
}
QMenu#dockToolsMenu {
    background: #0a2437;
    color: #e2f8ff;
    border: 1px solid #4a8aa5;
    padding: 5px;
}
QMenu#dockToolsMenu::item {
    padding: 9px 28px 9px 13px;
}
QMenu#dockToolsMenu::item:selected {
    color: white;
    background: #246b87;
}
QLabel#dockLogo {
    color: #defbff;
    font: 900 24px 'zero 5', 'Segoe UI';
    padding: 0 7px 0 4px;
}
QLabel#dockOperator {
    color: #96cddd;
    font: 600 9px 'Consolas';
    padding-left: 7px;
}
QPushButton#dockbutton {
    color: #9ebfd4;
    background: transparent;
    border: 1px solid transparent;
    border-bottom: 2px solid transparent;
    border-radius: 2px;
    padding: 4px 4px;
    font: 700 11px 'Segoe UI';
}
QPushButton#dockbutton:hover {
    color: #e5fcff;
    background: #16445c;
    border-color: #327f9c;
}
QPushButton#dockbutton:checked {
    color: #ecfeff;
    background: #21536d;
    border-color: #4d94af;
    border-bottom: 3px solid #a8f4ff;
}
QPushButton#dockLock {
    color: #a8e2f3;
    background: #11334a;
    border: 1px solid #417993;
    border-radius: 2px;
    padding: 3px 9px;
    font: 700 10px 'Segoe UI';
}
QPushButton#dockLock:hover { color: white; background: #28617c; }

QFrame#pane, QFrame#authPanel {
    background-color: #102638;
    border: 1px solid #2a556d;
    border-radius: 9px;
}
QPushButton {
    font: 700 12px 'Segoe UI';
    border-radius: 5px;
    padding: 7px 13px;
}
QPushButton#primary {
    color: #031b2a;
    background: #93dff2;
    border: 1px solid #b5f4ff;
}
QPushButton#primary:hover { background: #c2f1ff; }
QPushButton#primary:pressed { background: #65b4d0; }
QPushButton#quiet, QPushButton#action {
    color: #aadaed;
    background: #113047;
    border: 1px solid #34617a;
}
QPushButton#quiet:hover, QPushButton#action:hover {
    color: #f2fcff; background: #1d455d;
}
QPushButton#navbutton {
    text-align: left;
    padding-left: 14px;
    background: transparent;
    border: 1px solid transparent;
    color: #94b2c6;
}
QPushButton#navbutton:hover { color: white; background: #17364b; }
QPushButton#navbutton:checked {
    color: #d9f7ff;
    background: #1b465c;
    border-left: 3px solid #9be7ff;
}
QProgressBar { background: #102a40; border: 1px solid #4786a4; border-radius: 2px; }
QProgressBar::chunk { background: #99dced; }
QPlainTextEdit#log {
    background: #071522; color: #b7ebf5; border: 1px solid #2a556d;
    border-radius: 6px; padding: 16px; font: 12px 'Consolas';
}
QComboBox {
    color: #def4ff; background: #0c2537; border: 1px solid #3d6e89;
    border-radius: 5px; padding: 8px 13px; font: 13px 'Segoe UI';
}
QComboBox QAbstractItemView {
    color: #def4ff; background: #0c2537; selection-background-color: #306583;
}
QLineEdit#accountField, QLineEdit, QListWidget#reminderList {
    color: #ecf9ff; background: #071927; border: 1px solid #3b6e85;
    border-radius: 5px; padding: 7px 12px; font: 14px 'Segoe UI';
}
QLineEdit:focus { border: 1px solid #91ddf7; }
QLabel#authMessage { color: #edc58e; font: 12px 'Segoe UI'; }
QCheckBox { color: #d5ebf3; font: 14px 'Segoe UI'; spacing: 10px; }
QCheckBox::indicator { width: 19px; height: 19px; }
QCheckBox::indicator:unchecked { background: #091b2c; border: 1px solid #5e8799; }
QCheckBox::indicator:checked { background: #91d6ed; border: 1px solid #b9ebff; }

/* Delicate in-world monitor projection. No dashboard or generic app card. */
QWidget#authArea, QWidget#authFormPage, QStackedWidget#authForms {
    background: transparent;
    border: none;
}
QLabel#authSubline {
    color: rgba(222,252,255,230);
    font: 600 11px 'Consolas';
    letter-spacing: .8px;
}
QLabel#authPageTitle {
    color: #e3faff;
    font: 500 17px 'Segoe UI';
}
QLabel#authOperator {
    color: #f0ffff;
    font: 600 26px 'Segoe UI';
}
QLabel#authHint {
    color: #c6edf7;
    font: 12px 'Segoe UI';
}
QWidget#authArea QLineEdit {
    color: #eefeff;
    background: rgba(5,40,64,98);
    border: 1px solid rgba(205,248,254,193);
    border-radius: 20px;
    padding: 5px 13px;
    font: 13px 'Segoe UI';
    selection-background-color: #2588af;
}
QWidget#authArea QLineEdit:focus {
    color: white;
    background: rgba(14,69,91,168);
    border: 1px solid #e2ffff;
}
QWidget#authArea QPushButton#authArrow {
    color: #d7ffff;
    background: transparent;
    border: none;
    padding: 0;
}
QWidget#authArea QPushButton#authArrow:hover {
    background: rgba(126,224,247,33);
}
QWidget#authArea QPushButton#authAction {
    color: #d5fcff;
    background: rgba(5,54,79,120);
    border: 1px solid rgba(204,247,255,167);
    border-radius: 18px;
    padding: 5px 12px;
    font: 600 12px 'Segoe UI';
}
QWidget#authArea QPushButton#authAction:hover {
    background: rgba(89,209,234,165);
    color: #04263a;
}
QWidget#authArea QPushButton#authLink {
    color: rgba(208,248,254,219);
    background: transparent;
    border: none;
    border-radius: 0;
    text-align: left;
    padding: 4px 1px;
    font: 600 10px 'Consolas';
}
QWidget#authArea QPushButton#authLink:hover {
    color: white;
    text-decoration: underline;
}
QWidget#authArea QCheckBox {
    color: #e0faff;
    font: 11px 'Segoe UI';
}
QWidget#authArea QCheckBox::indicator {
    width: 15px;
    height: 15px;
    background: rgba(4,37,60,138);
    border: 1px solid rgba(208,246,251,180);
}
QWidget#authArea QCheckBox::indicator:checked {
    background: #9de7f4;
}
QWidget#authArea QLabel#authMessage {
    color: #e4fbff;
    font: 11px 'Segoe UI';
}
"""


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        from hdd.ui.dialog_theme import install_builtin_dialog_theme
        install_builtin_dialog_theme(QApplication.instance())
        self.setWindowTitle(f"H.D.D. System  //  {__version__}")
        self.resize(1180, 730)
        self.setMinimumSize(880, 610)
        self.settings = QSettings("HDD-Project", "HDD-System")
        self.accounts = AccountStore()
        self.quick_unlock = QuickUnlockStore(self.accounts)
        self.current_account = None
        self._login_transition = None
        self._automatic_boot_running = False
        self._automatic_boot_update = ""
        self.stack = QStackedWidget()
        self.boot = CinematicBoot(self.settings)
        self.access = AccountAccessPage(self.accounts, self.settings, self.quick_unlock)
        self.dashboard = DashboardPage(self.settings, self.accounts, self.quick_unlock)
        self.stack.addWidget(self.boot)
        self.stack.addWidget(self.access)
        self.stack.addWidget(self.dashboard)
        self.setCentralWidget(self.stack)
        # The event filter starts after the main pages have been constructed.
        # Independent MCI playback never interrupts winsound cinematic cues.
        self.ui_sounds = HDDUISounds(QApplication.instance(),self.settings,self)
        self.language_bridge=HDDLanguageBridge(QApplication.instance(),self.settings)
        selector=self.dashboard.interface_language_selector
        from PySide6.QtCore import QSignalBlocker
        with QSignalBlocker(selector):
            idx=selector.findData(self.language_bridge.lang)
            if idx>=0:selector.setCurrentIndex(idx)
        selector.currentIndexChanged.connect(
            lambda _index:self.language_bridge.select(str(selector.currentData())))
        def update_language_combo(code):
            with QSignalBlocker(selector):
                index=selector.findData(code)
                if index>=0:selector.setCurrentIndex(index)
        self.language_bridge.changed.connect(update_language_combo)
        # This page owns localized English/PT/ES strings; update its content
        # immediately on changes from HDD settings OR Fairy locale polling.
        self.language_bridge.changed.connect(self.dashboard.fairy_manager.set_language)
        self.dashboard.fairy_manager.set_language(self.language_bridge.lang)
        self.language_bridge.changed.connect(self.dashboard.retranslate_logs)
        self.language_bridge.changed.connect(self.dashboard._set_startup_language)
        self.language_bridge.translate_all()
        QTimer.singleShot(0,self._initialize_windows_startup)
        self.setStyleSheet(STYLE)
        self.boot.finished.connect(self._boot_finished)
        self.access.authenticated.connect(self.enter_dashboard)
        # Explicit lock is never silently bypassed by startup auto-login.
        self.dashboard.locked.connect(lambda: self.show_access(allow_auto=False))
        self.dashboard.restart_requested.connect(lambda: self.start_boot(manual=True))
        update_id = boot_policy.latest_update_id()
        show, self._boot_reason, playlist = boot_policy.boot_plan(
            self.settings, update_id
        )
        if show:
            self.start_boot(manual=False, update_id=update_id, playlist=playlist)
        else:
            # "No animation" is a deliberate, completed custom first/update
            # choice: consume that event now instead of treating it as pending
            # and accidentally showing it on every subsequent launch.
            if boot_policy.current_mode(self.settings)=="custom" and self._boot_reason in ("first","update"):
                boot_policy.record_completion(self.settings,update_id)
            self.show_access(allow_auto=True)

    def _initialize_windows_startup(self):
        try:
            windows_autostart.sync_existing_preferences(self.settings)
            self.dashboard.windows_startup_error.setText("")
        except (OSError,RuntimeError) as exc:
            # Startup registration is a convenience, not a reason to prevent
            # login or interrupt the H.D.D. boot sequence.
            self.dashboard.windows_startup_error.setText(
                "Windows startup registration: "+str(exc))
        self.dashboard.refresh_startup_controls()

    def show(self):
        # Cinematic and login remain immersive. Dashboard uses the full desktop
        # work area but retains the native Windows title bar and min/max/close.
        if self.stack.currentWidget() in (self.boot, self.access):
            self.showFullScreen()
        else:
            self.showMaximized()

    def start_boot(self,manual=True,update_id="",playlist=None):
        # Replaying manually never marks first-run or update milestones.
        # Users can preview either playlist by changing BOOT SEQUENCE style.
        self._automatic_boot_running = not manual
        self._automatic_boot_update = update_id if not manual else ""
        style = playlist or boot_policy.current_style(self.settings)
        self.stack.setCurrentWidget(self.boot)
        self.boot.begin(style=style)
        if self.isVisible() and not self.isFullScreen():
            self.showFullScreen()

    def _boot_finished(self):
        if self._automatic_boot_running and self.boot._natural_completion:
            # Commit ONLY on natural completion, not Escape/partial/closed boot.
            boot_policy.record_completion(self.settings,self._automatic_boot_update)
        self._automatic_boot_running=False
        self._automatic_boot_update=""
        self.show_access(allow_auto=True)

    def show_access(self,allow_auto=False):
        if allow_auto:
            identifier=str(self.settings.value("auto_login_account_id","")).strip()
            if identifier:
                account=self.accounts.get_account(identifier)
                if account is not None:
                    # Opt-in local convenience only, NOT authentication.
                    # Stop the cinematic sequence even when identification is skipped.
                    self.boot.stop()
                    self.enter_dashboard(account,auto=True)
                    return
                # A temporarily unavailable account must not erase the
                # operator's opt-in choice. Fall back to regular login only.
                # Deactivation is reserved for an explicit settings action.
        # Apply a short settling scan on the NEW login. Never snapshot or
        # hold the outgoing loading screen (that looked like a frozen frame).
        cinematic_exit = (
            self.stack.currentWidget() is self.boot
            and self.boot._natural_completion
            and self.settings.value("boot_glitch", True, type=bool)
        )
        self.boot.stop()
        self.current_account = None
        self.dashboard.set_account(None)
        self.access.set_scanlines(self.settings.value("scanlines", True, type=bool))
        self.access.refresh()
        self.stack.setCurrentWidget(self.access)
        # Identification is now a full-monitor screen, like the boot.
        if self.isVisible() and not self.isFullScreen():
            self.showFullScreen()
        if cinematic_exit:
            self._login_transition = LoginGlitchOverlay(self.stack)

    def enter_dashboard(self, account,auto=False):
        verified = self.accounts.get_account(account.id)
        if verified is None or verified != account:
            return
        self.current_account = verified
        self.dashboard.set_account(verified)
        self.stack.setCurrentWidget(self.dashboard)
        # Switch out of immersive login to MAXIMIZED WINDOWED mode.
        # showMaximized preserves Windows title-bar controls and taskbar.
        if self.isVisible():
            if self.isFullScreen():
                self.showNormal()
            self.showMaximized()
        self.dashboard.add_log("Sessão local iniciada automaticamente." if auto
                               else "Sessão local autenticada.")
        QTimer.singleShot(1800,self.dashboard.auto_check_updates_once)
        QTimer.singleShot(3300,self.dashboard.fairy_manager.auto_check_updates_once)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key.Key_Escape and self.stack.currentWidget() is self.boot:
            self.boot.skip()
            return
        super().keyPressEvent(event)
