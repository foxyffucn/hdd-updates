"""H.D.D. i18n hardened UI strings.

Reviewed full-message translations for status, boot, logs and long captions.
No string replacement in filenames, accounts, free-form text, command output
or other private content. The default factory display locale is en-US.
"""
from __future__ import annotations
import re
LANGUAGES=("en-US","pt-BR","es-ES")

# Exact original Portuguese -> (English, Spanish).
EN_ES={
"Eventos desta execução. Não é um console de comandos.":(
 "Events from this session. This is not a command console.",
 "Eventos de esta sesión. No es una consola de comandos."),
"Compacta: logo Helios → glitch → H.D.D. Loading, sem sincronização numérica e sem códigos falsos. Os efeitos visuais permanecem os mesmos.":(
 "Compact: Helios logo → glitch → H.D.D. Loading, without numeric synchronization or simulated code. Visual effects remain unchanged.",
 "Compacta: logo Helios → glitch → H.D.D. Loading, sin sincronización numérica ni código simulado. Los efectos visuales no cambian."),
"Nenhum dispositivo está sincronizando ainda. A lista será atualizada automaticamente quando a integração estiver pronta.":(
 "No devices are syncing yet. This list will refresh automatically when integration is ready.",
 "Todavía no hay dispositivos sincronizando. La lista se actualizará al preparar la integración."),
"HELIOS  //  MODULE LINK  /  ARQUIVOS • TERMINAL • CÓDIGO • PROTOCOLOS • BACKUPS":(
 "HELIOS // MODULE LINK / FILES • TERMINAL • CODE • PROTOCOLS • BACKUPS",
 "HELIOS // ENLACE DE MÓDULO / ARCHIVOS • TERMINAL • CÓDIGO • PROTOCOLOS • COPIAS"),
"H.D.D. // SIMULAÇÃO DE INTEGRAÇÃO":(
 "H.D.D. // INTEGRATION SIMULATION","H.D.D. // SIMULACIÓN DE INTEGRACIÓN"),
"Aguarde a verificação/download em andamento.":(
 "Wait for the current update check/download to finish.",
 "Espera a que termine la comprobación/descarga en curso."),
"Aguarde a verificação/download em andamento terminar.":(
 "Wait until the ongoing update check/download finishes.",
 "Espera a que termine la comprobación/descarga en curso."),
"Registros copiados para a área de transferência.":(
 "Logs copied to the clipboard.","Registros copiados al portapapeles."),
"Interface carregada.":("Interface loaded.","Interfaz cargada."),
"Diagnóstico do ambiente atualizado.":("Environment diagnostics refreshed.","Diagnóstico del entorno actualizado."),
"Sessão local iniciada automaticamente.":(
 "Local session signed in automatically.","Sesión local iniciada automáticamente."),
"Sessão local iniciada por autenticação.":(
 "Local session signed in through authentication.",
 "Sesión local iniciada mediante autenticación."),
"Entrada automática local desativada pelo operador.":(
 "Local automatic sign-in disabled by the operator.",
 "Inicio automático local desactivado por el operador."),
"Entrada automática local ativada e salva para próximas inicializações.":(
 "Local automatic sign-in enabled for future launches.",
 "Inicio automático local activado para los próximos inicios."),
"Configuração indisponível":("Configuration unavailable","Configuración no disponible"),
"Fairy // Instalação":("Fairy // Installation","Fairy // Instalación"),
"Linhas de varredura ativadas.":(
 "Scanlines enabled.","Líneas de barrido activadas."),
"Linhas de varredura desativadas.":(
 "Scanlines disabled.","Líneas de barrido desactivadas."),
"● ATIVO  //  O H.D.D. entrará na conta {account} automaticamente nas próximas inicializações.":(
 "● ACTIVE // H.D.D. will sign into account {account} automatically on future launches.",
 "● ACTIVO // H.D.D. iniciará sesión en la cuenta {account} automáticamente en próximos inicios."),
"Registros identificados como Fairy neste PC: {count}. Nenhuma sincronização remota está ativa.":(
 "Fairy records detected on this PC: {count}. Remote synchronization is not active.",
 "Registros de Fairy detectados en este PC: {count}. La sincronización remota no está activa."),
"Falha ao ler diagnósticos: {error}":(
 "Failed to read diagnostics: {error}",
 "No se pudo leer el diagnóstico: {error}"),
"Boot personalizado: {event} → {style}.":(
 "Custom boot: {event} → {style}.","Arranque personalizado: {event} → {style}."),
"Frequência da sequência cinematográfica: {mode}.":(
 "Cinematic sequence frequency: {mode}.",
 "Frecuencia de la secuencia cinematográfica: {mode}."),
"Estilo da sequência cinematográfica: {mode}.":(
 "Cinematic sequence style: {mode}.",
 "Estilo de la secuencia cinematográfica: {mode}."),
"Falha ao salvar a preferência no Windows.":(
 "Failed to save the preference in Windows.",
 "No se pudo guardar la preferencia en Windows."),
"● ATIVO":("● ACTIVE","● ACTIVO"),
}
# Matches only complete formatted status messages, and preserves interpolation
# values literally. Value fields must be bounded and safe; no arbitrary guessing.
_PATTERNS=[
 (re.compile(r"^Registros identificados como Fairy neste PC: (?P<count>\d+)\. Nenhuma sincronização remota está ativa\.$"),
  "Registros identificados como Fairy neste PC: {count}. Nenhuma sincronização remota está ativa."),
 (re.compile(r"^● ATIVO\s*//\s*O H\.D\.D\. entrará na conta (?P<account>[^\r\n]{1,80}) automaticamente nas próximas inicializações\.$"),
  "● ATIVO  //  O H.D.D. entrará na conta {account} automaticamente nas próximas inicializações."),
 (re.compile(r"^Falha ao ler diagnósticos: (?P<error>[^\r\n]{1,180})$"),
  "Falha ao ler diagnósticos: {error}"),
 (re.compile(r"^Boot personalizado: (?P<event>[^\r\n]{1,70}) → (?P<style>[^\r\n]{1,100})\.$"),
  "Boot personalizado: {event} → {style}."),
 (re.compile(r"^Frequência da sequência cinematográfica: (?P<mode>[^\r\n]{1,100})\.$"),
  "Frequência da sequência cinematográfica: {mode}."),
 (re.compile(r"^Estilo da sequência cinematográfica: (?P<mode>[^\r\n]{1,100})\.$"),
  "Estilo da sequência cinematográfica: {mode}."),
]
def localize(value,locale):
    if locale not in ("en-US","es-ES") or not isinstance(value,str):
        return None
    target=0 if locale=="en-US" else 1
    match=EN_ES.get(value)
    if match:return match[target]
    for expression,pattern in _PATTERNS:
        m=expression.fullmatch(value)
        if m:
            return EN_ES[pattern][target].format_map(m.groupdict())
    return None
