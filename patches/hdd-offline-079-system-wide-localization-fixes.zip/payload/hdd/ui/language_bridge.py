"""H.D.D. <-> Fairy *interface-only* language bridge.

Both programs use the Fairy install's existing userdata/ui_language.json.
Never changes Fairy's microphone, STT, default voice or reply language.
"""
from __future__ import annotations
import json,os
from pathlib import Path
from PySide6.QtCore import QObject,QSettings,QTimer,Signal,QSignalBlocker,QEvent
from PySide6.QtWidgets import (QApplication,QAbstractButton,QComboBox,QLabel,QGroupBox,QMenu,
    QTabWidget,QLineEdit,QMessageBox,QTableWidget,QTreeWidget,QListWidget,
    QPlainTextEdit,QTextEdit,QTableWidgetItem,QToolTip,QDialog)
from PySide6.QtCore import Qt

from hdd.ui.locale_catalog import CATALOG,translate_catalog
from hdd.ui.locale_extensions import EXTRA,translate_dynamic,translate_step_label,translate_protocol_row
from functools import lru_cache

_ACTIVE_LOCALE="en-US"
@lru_cache(maxsize=1024)
def _localized_paint(lang,value):
    if lang=="pt-BR":return value
    match=CATALOG.get(value)
    if match:return match[0 if lang=="en-US" else 1]
    extended=translate_dynamic(value,lang)
    if extended is not None:return extended
    mapped=UI_TEXT.get(value)
    if mapped:return mapped[0 if lang=="en-US" else 1]
    return translate_catalog(value,lang)

def painted_ui_text(value):
    return _localized_paint(_ACTIVE_LOCALE,value)

def translate_before_first_paint(dialog):
    """Initialize visible text in the selected HDD locale BEFORE showing.

    Native factory locale is en-US. Calls remain synchronous: never wait
    for the 1250 ms poll timer or a queued singleShot after opening a page.
    The original source labels are retained by the existing language bridge
    so manual EN/PT/ES switching works as before.
    """
    app=QApplication.instance()
    bridge=getattr(app,"_hdd_language_bridge",None) if app else None
    if bridge is not None:
        bridge.translate_all()
    return dialog

LANGUAGES={"en-US":"English","pt-BR":"Português (Brasil)","es-ES":"Español"}

# pt-BR text -> English, Spanish. Unlisted technical labels are left untouched.
UI_TEXT={
"INÍCIO":("HOME","INICIO"),"DIAGNÓSTICO":("DIAGNOSTICS","DIAGNÓSTICO"),
"REGISTROS":("LOGS","REGISTROS"),"AJUSTES":("SETTINGS","AJUSTES"),
"OPERADOR":("OPERATOR","OPERADOR"),"ATUALIZAR":("UPDATE","ACTUALIZAR"),
"BLOQUEAR":("LOCK","BLOQUEAR"),"SEM SESSÃO":("NO SESSION","SIN SESIÓN"),
"ACESSOS  //":("SHORTCUTS  //","ACCESOS  //"),
"DOWNLOADS":("DOWNLOADS","DESCARGAS"),"ARQUIVOS":("FILES","ARCHIVOS"),
"TERMINAL":("TERMINAL","TERMINAL"),"REDE":("NETWORK","RED"),
"DISPOSITIVOS":("DEVICES","DISPOSITIVOS"),"MAIS  ▾":("MORE  ▾","MÁS  ▾"),
"CENTRAL DE TAREFAS":("TASK CENTER","CENTRAL DE TAREAS"),
"CENTRAL DE INTEGRAÇÕES":("INTEGRATIONS HUB","CENTRAL DE INTEGRACIONES"),
"NÚCLEO DE INTELIGÊNCIA":("INTELLIGENCE CORE","NÚCLEO DE INTELIGENCIA"),
"PROTOCOLOS":("PROTOCOLS","PROTOCOLOS"),"CÓDIGO":("CODE","CÓDIGO"),
"RECUPERAÇÃO / BACKUPS":("RECOVERY / BACKUPS","RECUPERACIÓN / COPIAS"),
"MONITOR":("MONITOR","MONITOR"),"ARMAZENAMENTO":("STORAGE","ALMACENAMIENTO"),
"APLICATIVOS":("APPLICATIONS","APLICACIONES"),
"DIAGNÓSTICO E REPAROS":("DIAGNOSTICS AND REPAIR","DIAGNÓSTICO Y REPARACIONES"),
"CENTRAL DE ATUALIZAÇÕES":("UPDATE CENTER","CENTRAL DE ACTUALIZACIONES"),
"VISÃO GERAL":("OVERVIEW","VISTA GENERAL"),
"DIAGNÓSTICO LOCAL":("LOCAL DIAGNOSTICS","DIAGNÓSTICO LOCAL"),
"REGISTROS DA SESSÃO":("SESSION LOGS","REGISTROS DE SESIÓN"),
"PREFERÊNCIAS DE INTERFACE":("INTERFACE PREFERENCES","PREFERENCIAS DE INTERFAZ"),
"Estas preferências são salvas localmente no Windows.":(
 "These preferences are saved locally in Windows.",
 "Estas preferencias se guardan localmente en Windows."),
"Estas preferências são salvas localmente no Windows.":(
 "These preferences are saved locally in Windows.",
 "Estas preferencias se guardan localmente en Windows."),
"ATUALIZAR INFORMAÇÕES":("REFRESH INFORMATION","ACTUALIZAR INFORMACIÓN"),
"COPIAR REGISTROS":("COPY LOGS","COPIAR REGISTROS"),
"LIMPAR TELA":("CLEAR SCREEN","LIMPIAR PANTALLA"),
"PRONTO":("READY","LISTO"),"VOLTAR":("BACK","VOLVER"),
"FECHAR":("CLOSE","CERRAR"),"SALVAR":("SAVE","GUARDAR"),
"CANCELAR":("CANCEL","CANCELAR"),"ABRIR":("OPEN","ABRIR"),
"PAUSAR":("PAUSE","PAUSAR"),"CONTINUAR":("RESUME","CONTINUAR"),
"COMEÇAR":("START","INICIAR"),"INSTALAR":("INSTALL","INSTALAR"),
"REMOVER":("REMOVE","ELIMINAR"),"EXCLUIR":("DELETE","ELIMINAR"),
"CONFIGURAR IDIOMA":("CONFIGURE LANGUAGE","CONFIGURAR IDIOMA"),
"CONFIGURAR PROVEDORES":("CONFIGURE PROVIDERS","CONFIGURAR PROVEEDORES"),
"REBOOT + INICIAR FAIRY":("REBOOT + START FAIRY","REINICIO + INICIAR FAIRY"),
"ESCOLHER PASTA":("CHOOSE FOLDER","ELEGIR CARPETA"),
"INSTALAR FAIRY DE FÁBRICA":("INSTALL FACTORY FAIRY","INSTALAR FAIRY DE FÁBRICA"),
"INTERROMPER":("STOP","DETENER"),
"VOLTAR AO NÚCLEO":("BACK TO CORE","VOLVER AL NÚCLEO"),
"INSTALAR UNIDADE  /  REAL":("INSTALL MODULE  /  REAL","INSTALAR MÓDULO  /  REAL"),
"TESTAR INTEGRAÇÃO  /  SIMULAÇÃO":("TEST INTEGRATION  /  SIMULATION","PROBAR INTEGRACIÓN  /  SIMULACIÓN"),
"DETALHES DO PROTOCOLO":("PROTOCOL DETAILS","DETALLES DEL PROTOCOLO"),
"OCULTAR DETALHES":("HIDE DETAILS","OCULTAR DETALLES"),
"UNIDADE NÃO INTEGRADA":("MODULE NOT INTEGRATED","MÓDULO NO INTEGRADO"),
"MÓDULO EXTERNO  //  CLASSIFICADO":("EXTERNAL MODULE  //  CLASSIFIED","MÓDULO EXTERNO  //  CLASIFICADO"),
"IDENTIDADE / ENCRIPTADA":("IDENTITY / ENCRYPTED","IDENTIDAD / CIFRADA"),
"DESIGNAÇÃO":("DESIGNATION","DESIGNACIÓN"),
"INSTALAÇÃO":("INSTALLATION","INSTALACIÓN"),
"VÍNCULO H.D.D.":("H.D.D. LINK","ENLACE H.D.D."),
"AUTORIZAÇÃO":("AUTHORIZATION","AUTORIZACIÓN"),
"DADOS PROTEGIDOS":("PROTECTED DATA","DATOS PROTEGIDOS"),
"NÃO INICIADA":("NOT STARTED","NO INICIADA"),
"AUSENTE":("ABSENT","AUSENTE"),
"AGUARDANDO OPERADOR":("AWAITING OPERATOR","ESPERANDO OPERADOR"),
"PREPARAÇÃO":("PREPARATION","PREPARACIÓN"),
"CONFIGURAÇÃO":("CONFIGURATION","CONFIGURACIÓN"),
"REINICIALIZAÇÃO":("REINITIALIZATION","REINICIALIZACIÓN"),
"ATIVAÇÃO":("ACTIVATION","ACTIVACIÓN"),
"PENDENTE":("PENDING","PENDIENTE"),
"BLOQUEADA":("LOCKED","BLOQUEADA"),
"FAIRY INSTALADA":("FAIRY INSTALLED","FAIRY INSTALADA"),
"PRÉVIA CONCLUÍDA / NÃO INSTALADA":("PREVIEW COMPLETE / NOT INSTALLED","VISTA PREVIA COMPLETA / NO INSTALADA"),
"PROTOCOLO DE INTEGRAÇÃO":("INTEGRATION PROTOCOL","PROTOCOLO DE INTEGRACIÓN"),
"ESTABELECENDO PROTOCOLO":("ESTABLISHING PROTOCOL","ESTABLECIENDO PROTOCOLO"),
"INSTALAÇÃO SIMULADA CONCLUÍDA":("SIMULATED INSTALLATION COMPLETE","INSTALACIÓN SIMULADA COMPLETA"),
"REINICIALIZAÇÃO CINEMATOGRÁFICA EM PREPARAÇÃO":("PREPARING CINEMATIC REBOOT","PREPARANDO REINICIO CINEMATOGRÁFICO"),
"RECOMEÇAR TESTE":("RESTART TEST","REINICIAR PRUEBA"),
"INTERROMPER / VOLTAR":("STOP / BACK","DETENER / VOLVER"),
"SISTEMA PRONTO PARA SIMULAÇÃO":("SYSTEM READY FOR SIMULATION","SISTEMA LISTO PARA SIMULACIÓN"),
"HELIO RESEARCH":("HELIOS RESEARCH","HELIOS RESEARCH"),
"INGLÊS":("ENGLISH","INGLÉS"),
"PORTUGUÊS":("PORTUGUESE","PORTUGUÉS"),
"ESPANHOL":("SPANISH","ESPAÑOL"),
"Sons de interface (cliques e menus da Fairy)":(
 "Interface sounds (Fairy clicks and menus)","Sonidos de interfaz (clics y menús de Fairy)"),
"PACOTE DE FÁBRICA VERIFICADO // PRONTO PARA INSTALAR":(
 "FACTORY PACKAGE VERIFIED // READY TO INSTALL",
 "PAQUETE DE FÁBRICA VERIFICADO // LISTO PARA INSTALAR"),
"PACOTE INSTALADO // CONFIGURAÇÃO E ATIVAÇÃO DISPONÍVEIS":(
 "PACKAGE INSTALLED // CONFIGURATION AND ACTIVATION AVAILABLE",
 "PAQUETE INSTALADO // CONFIGURACIÓN Y ACTIVACIÓN DISPONIBLES"),
"INSTALAÇÃO PARCIAL // RETOMADA DISPONÍVEL":(
 "PARTIAL INSTALLATION // RESUME AVAILABLE",
 "INSTALACIÓN PARCIAL // REANUDAR DISPONIBLE"),
"PACOTE FAIRY INSTALADO / ATIVAÇÃO DISPONÍVEL":(
 "FAIRY PACKAGE INSTALLED / ACTIVATION AVAILABLE",
 "FAIRY INSTALADA / ACTIVACIÓN DISPONIBLE"),
"Já configurei o idioma e os provedores de IA; autorizar primeira inicialização.":(
 "I have configured the language and AI providers; authorize first startup.",
 "Configuré el idioma y los proveedores de IA; autorizar primer inicio."),
"A cutscene inédita de revelação da Fairy ainda não foi produzida.":(
 "Fairy's new reveal cutscene has not been produced yet.",
 "La nueva escena de revelación de Fairy aún no se ha producido."),
}
# Main settings, first-run, and overview copy.
UI_TEXT.update({
"SISTEMA  /  CONFIGURAÇÕES":("SYSTEM  /  SETTINGS","SISTEMA  /  AJUSTES"),
"SISTEMA / CONFIGURAÇÕES":("SYSTEM / SETTINGS","SISTEMA / CONFIGURACIÓN"),
"Idioma da interface / Interface language":("Interface language","Idioma de interfaz"),
"Ativar linhas de varredura nos gráficos":("Enable scanlines in graphics","Activar líneas de barrido en gráficos"),
"Bloom real (destaques luminosos com desfoque)":("Real bloom (soft luminous highlights)","Bloom real (brillos luminosos difuminados)"),
"BOOT SEQUENCE  /  CONFIGURAÇÃO POR EVENTO":("BOOT SEQUENCE  /  EVENT CONFIGURATION","BOOT SEQUENCE  /  CONFIGURACIÓN POR EVENTO"),
"ESCOLHA A ANIMAÇÃO DE CADA EVENTO":("CHOOSE AN ANIMATION FOR EACH EVENT","ELIGE UNA ANIMACIÓN PARA CADA EVENTO"),
"Primeira execução":("First run","Primer inicio"),
"PRIMEIRA EXECUÇÃO":("FIRST RUN","PRIMER INICIO"),
"AO ABRIR NORMALMENTE":("ON NORMAL STARTUP","AL INICIAR NORMALMENTE"),
"APÓS INSTALAR ATUALIZAÇÃO":("AFTER INSTALLING UPDATE","TRAS INSTALAR ACTUALIZACIÓN"),
"Ao abrir normalmente":("On normal startup","Al iniciar normalmente"),
"Após instalar atualização":("After an update","Tras una actualización"),
"Cinematográfica completa":("Full cinematic","Cinemática completa"),
"Compacta — logo Helios + H.D.D. Loading":("Compact — Helios logo + H.D.D. Loading","Compacta — logo Helios + H.D.D. Loading"),
"Completa acelerada":("Fast full cinematic","Cinemática completa rápida"),
"Compacta acelerada":("Fast compact","Compacta rápida"),
"Intermediária — Helios + números + Loading":("Intermediate — Helios + numbers + Loading","Intermedia — Helios + números + Loading"),
"Intermediária acelerada":("Fast intermediate","Intermedia rápida"),
"Sem animação":("No animation","Sin animación"),
"Sempre mostrar animação":("Always show animation","Mostrar animación siempre"),
"Nunca mostrar animação":("Never show animation","Nunca mostrar animación"),
"Primeira vez + após atualizações":("First run + after updates","Primer inicio + tras actualizaciones"),
"Somente a primeira vez":("First run only","Solo primer inicio"),
"Somente após atualizações":("After updates only","Solo tras actualizaciones"),
"Híbrido: compacto sempre + completo na estreia/atualizações":("Hybrid: compact always + full on first run/updates","Híbrido: compacto siempre + completo al inicio/actualizar"),
"Híbrido: compacto sempre + completo só na estreia":("Hybrid: compact always + full on first run","Híbrido: compacto siempre + completo en estreno"),
"Híbrido: compacto sempre + completo nas atualizações":("Hybrid: compact always + full on updates","Híbrido: compacto siempre + completo en actualizaciones"),
"Personalizado — definir uma animação para cada evento":("Custom — choose animation for each event","Personalizado — elegir animación por evento"),
"BOOT SEQUENCE  /  MODELOS PRONTOS (OPCIONAL)":("BOOT SEQUENCE  /  PRESETS (OPTIONAL)","BOOT SEQUENCE  /  PREAJUSTES (OPCIONAL)"),
"BOOT SEQUENCE  /  ESTILO PADRÃO E REPRODUÇÃO MANUAL":("BOOT SEQUENCE  /  DEFAULT STYLE & MANUAL PLAYBACK","BOOT SEQUENCE  /  ESTILO PREDETERMINADO Y REPRODUCCIÓN MANUAL"),
"Velocidade das animações":("Animation speed","Velocidad de animaciones"),
"Lenta":("Slow","Lenta"),"Normal":("Normal","Normal"),"Rápida":("Fast","Rápida"),
"Sons de inicialização (quando houver arquivos WAV)":("Startup sounds (when WAV files exist)","Sonidos de inicio (cuando existan archivos WAV)"),
"Exibir mensagens técnicas do carregamento":("Show technical loading messages","Mostrar mensajes técnicos de carga"),
"ACESSO RÁPIDO  /  OPERADOR LOCAL":("QUICK ACCESS  /  LOCAL OPERATOR","ACCESO RÁPIDO  /  OPERADOR LOCAL"),
"Entrar automaticamente no H.D.D. sem senha ou PIN":("Sign in to H.D.D. automatically without password or PIN","Entrar automáticamente al H.D.D. sin contraseña ni PIN"),
"REPRODUZIR INICIALIZAÇÃO":("REPLAY STARTUP","REPRODUCIR INICIO"),
"CONTA / MEMÓRIA DA FAIRY":("FAIRY ACCOUNT / MEMORY","CUENTA / MEMORIA DE FAIRY"),
"CONEXÕES E SINCRONIZAÇÃO":("CONNECTIONS AND SYNC","CONEXIONES Y SINCRONIZACIÓN"),
"MEMÓRIAS E ATIVIDADES REGISTRADAS PELA FAIRY":("FAIRY MEMORIES AND REGISTERED ACTIVITIES","MEMORIAS Y ACTIVIDADES REGISTRADAS POR FAIRY"),
"ROTINAS E LEMBRETES DA FAIRY":("FAIRY ROUTINES AND REMINDERS","RUTINAS Y RECORDATORIOS DE FAIRY"),
"FAIRY NO PC       //  AINDA NÃO CONECTADA":("FAIRY ON PC       //  NOT CONNECTED","FAIRY EN PC       //  NO CONECTADA"),
"NUVEM            //  NÃO CONFIGURADA":("CLOUD            //  NOT CONFIGURED","NUBE            //  NO CONFIGURADA"),
"OUTROS DISPOSITIVOS   //  NÃO VINCULADOS":("OTHER DEVICES   //  NOT LINKED","OTROS DISPOSITIVOS   //  NO VINCULADOS"),
"○ DESATIVADO  //  A identificação continuará obrigatória.":("○ DISABLED  //  Authentication remains required.","○ DESACTIVADO  //  Seguirá siendo necesaria la autenticación."),
"● CONFIGURADO PARA OUTRA CONTA  //  Não alterado.":("● SET FOR ANOTHER ACCOUNT  //  Unchanged.","● CONFIGURADO PARA OTRA CUENTA  //  Sin cambios."),
"PLATAFORMA":("PLATFORM","PLATAFORMA"),
"VERSÃO DO PYTHON":("PYTHON VERSION","VERSIÓN DE PYTHON"),
"ARMAZENAMENTO DA UNIDADE":("DISK STORAGE","ALMACENAMIENTO DEL DISCO"),
"RECURSOS INSTALADOS":("INSTALLED RESOURCES","RECURSOS INSTALADOS"),
"●  NÚCLEO LOCAL ATIVO":("●  LOCAL CORE ACTIVE","●  NÚCLEO LOCAL ACTIVO"),
"Os modelos prontos preenchem as três opções acima. Editar uma delas ativa o modo personalizado automaticamente.":(
 "Presets populate the three choices above. Editing any of them switches to Custom automatically.",
 "Los preajustes rellenan las tres opciones anteriores. Editar una activa automáticamente el modo personalizado."),
"Mude qualquer opção acima para ativar automaticamente sua combinação personalizada. Você também pode usar um modelo pronto abaixo, sem perder suas escolhas anteriores.":(
 "Change any option above to activate your custom combination. You may also choose a preset below without losing your earlier selections.",
 "Cambia cualquier opción anterior para activar tu combinación personalizada. También puedes elegir un preajuste sin perder lo anterior."),
})
# Extend the existing 3-language bridge for Patch 062 onboarding labels.
# Portuguese is the canonical source; the bridge applies EN/ES on display.
UI_TEXT.update({
"CONFIGURAR FISH AUDIO / VOZ  //  OBRIGATÓRIO":(
 "CONFIGURE FISH AUDIO / VOICE  //  REQUIRED",
 "CONFIGURAR FISH AUDIO / VOZ  //  OBLIGATORIO"),
"CONFIGURAÇÃO AVANÇADA // SISTEMAS OPCIONAIS":(
 "ADVANCED SETUP // OPTIONAL SYSTEMS",
 "CONFIGURACIÓN AVANZADA // SISTEMAS OPCIONALES"),
"HELIOS  //  CONFIGURAÇÃO PENDENTE":(
 "HELIOS  //  CONFIGURATION PENDING",
 "HELIOS  //  CONFIGURACIÓN PENDIENTE"),
"HELIOS  //  UNIDADE EXTERNA PRONTA":(
 "HELIOS  //  EXTERNAL LINK READY",
 "HELIOS  //  UNIDAD EXTERNA LISTA"),
"HELIOS  //  UNIDADE NÃO INSTALADA":(
 "HELIOS  //  UNIT NOT INSTALLED",
 "HELIOS  //  UNIDAD NO INSTALADA"),
"HELIOS  //  CONFIGURAÇÃO DE IDIOMA OBRIGATÓRIA":(
 "HELIOS  //  LANGUAGE CONFIGURATION REQUIRED",
 "HELIOS  //  CONFIGURACIÓN DE IDIOMA OBLIGATORIA"),
"HELIOS  //  APIS GEMINI + GROQ OBRIGATÓRIAS":(
 "HELIOS  //  GEMINI + GROQ APIS REQUIRED",
 "HELIOS  //  SE REQUIEREN LAS API DE GEMINI + GROQ"),
"HELIOS  //  API FISH AUDIO + VOZ OBRIGATÓRIAS":(
 "HELIOS  //  FISH AUDIO API + VOICE REQUIRED",
 "HELIOS  //  API FISH AUDIO Y VOZ OBLIGATORIAS"),
"HELIOS  //  UNIDADE INDISPONÍVEL":(
 "HELIOS  //  UNIT UNAVAILABLE",
 "HELIOS  //  UNIDAD NO DISPONIBLE"),
"PACOTE INSTALADO // UNIDADE EXTERNA DETECTADA":(
 "PACKAGE INSTALLED // EXTERNAL UNIT DETECTED",
 "PAQUETE INSTALADO // UNIDAD EXTERNA DETECTADA"),
})

# Canonical PT keys used by the External Intelligence / Fairy setup screens.
# All updates still go through the *existing* application language bridge.
UI_TEXT.update({
 "PROTOCOLO DE INTEGRAÇÃO  /  FASES PLANEJADAS":(
   "INTEGRATION PROTOCOL  /  PLANNED PHASES",
   "PROTOCOLO DE INTEGRACIÓN  /  FASES PLANIFICADAS"),
 "H.D.D. // INTEGRAÇÃO DE UNIDADE EXTERNA":(
   "H.D.D. // EXTERNAL MODULE INTEGRATION",
   "H.D.D. // INTEGRACIÓN DE MÓDULO EXTERNO"),
 "H.D.D. // NÚCLEO DE INTELIGÊNCIA":(
   "H.D.D. // INTELLIGENCE CORE",
   "H.D.D. // NÚCLEO DE INTELIGENCIA"),
 "HELIOS  //  INSTALAÇÃO CONCLUÍDA":(
   "HELIOS  //  INSTALLATION COMPLETE",
   "HELIOS  //  INSTALACIÓN COMPLETADA"),
 "INSTALANDO... // NÃO ENCERRAR O H.D.D.":(
   "INSTALLING... // DO NOT CLOSE H.D.D.",
   "INSTALANDO... // NO CIERRES H.D.D."),
 "PACOTE INSTALADO // UNIDADE EXTERNA DETECTADA":(
   "PACKAGE INSTALLED // EXTERNAL UNIT DETECTED",
   "PAQUETE INSTALADO // UNIDAD EXTERNA DETECTADA"),
 "HELIOS  //  UNIDADE EXTERNA PRONTA":(
   "HELIOS  //  EXTERNAL UNIT READY",
   "HELIOS  //  UNIDAD EXTERNA LISTA"),
 "CONCLUÍDA":("COMPLETE","COMPLETADA"),
 "PREPARADO":("PREPARED","PREPARADO"),
 "OPERADOR":("OPERATOR","OPERADOR"),
})

def set_localized_text(widget,canonical):
    """Set a *dynamic* UI text immediately in the active language.

    Preserve the untranslated baseline used by translate_all(), including
    when status is refreshed every 1.6 seconds between locale polls.
    """
    raw=str(canonical)
    localized=painted_ui_text(raw)
    widget.setProperty("_hdd_original",raw)
    widget.setProperty("_hdd_last_localized",localized)
    if widget.text()!=localized:
        widget.setText(localized)

def set_localized_window_title(widget,canonical):
    raw=str(canonical)
    localized=painted_ui_text(raw)
    widget.setProperty("_hdd_i18n_title",raw)
    widget.setProperty("_hdd_prev_title",localized)
    if widget.windowTitle()!=localized:
        widget.setWindowTitle(localized)

UI_TEXT.update({
    "ATUALIZAÇÕES AUTOMÁTICAS // FONTE OFICIAL HTTPS":(
        "AUTOMATIC UPDATES // OFFICIAL HTTPS SOURCE",
        "ACTUALIZACIONES AUTOMÁTICAS // FUENTE HTTPS OFICIAL"),
    "SALVAR FONTE":("SAVE SOURCE","GUARDAR FUENTE"),
    "VERIFICAR AGORA":("CHECK NOW","COMPROBAR AHORA"),
    "BAIXAR PATCH DISPONÍVEL":("DOWNLOAD AVAILABLE PATCH","DESCARGAR PARCHE DISPONIBLE"),
    "VERIFICAR ATUALIZAÇÕES AO INICIAR":("CHECK FOR UPDATES AT STARTUP","BUSCAR ACTUALIZACIONES AL INICIAR"),
})
REPLACEMENTS={
"pt-BR":{},
"en-US":{
 "Nenhuma unidade vinculada ao núcleo local.":"No module linked to the local core.",
 "Nenhuma operação será executada sem sua escolha.":"No operation runs without your choice.",
 "O H.D.D. está operando em modo independente.":"H.D.D. is running independently.",
 "Selecione um arquivo ou pasta...":"Select a file or folder...",
 "Abrir ":"Open ","Escolha ":"Choose ","Pronto.":"Ready.",
},
"es-ES":{
 "Nenhuma unidade vinculada ao núcleo local.":"Ningún módulo vinculado al núcleo local.",
 "Nenhuma operação será executada sem sua escolha.":"No se hará nada sin tu elección.",
 "O H.D.D. está operando em modo independente.":"H.D.D. funciona de forma independiente.",
 "Selecione um arquivo ou pasta...":"Selecciona un archivo o carpeta...",
 "Abrir ":"Abrir ","Escolha ":"Elige ","Pronto.":"Listo.",
}
}


def fairy_language_path(settings):
    from hdd.ui.fairy_install_backend import installed_state, default_target
    target=Path(str(settings.value("fairy_install_target",str(default_target()))))
    # Only trust the exact installation target selected in H.D.D.
    if not installed_state(target):
        return None
    return target/"userdata"/"ui_language.json"


class HDDLanguageBridge(QObject):
    changed=Signal(str)
    def __init__(self,app,settings):
        super().__init__(app)
        self.app=app
        self.settings=settings
        self.lang=str(settings.value("interface_language","en-US") or "en-US")
        if self.lang not in LANGUAGES:self.lang="en-US"
        self._source_stamp=None
        self._source_path=None
        self._load_from_fairy()
        self.timer=QTimer(self)
        self.timer.setInterval(1250)
        self.timer.timeout.connect(self._poll)
        self.timer.start()
        self.app.installEventFilter(self)
        # Used by late-created windows to translate before their first show.
        self.app._hdd_language_bridge=self
        self._poll()

    def _load_from_fairy(self):
        source=fairy_language_path(self.settings)
        self._source_path=source
        if source is None:return
        if not source.exists():
            self._write(source,self.lang)
            return
        try:
            obj=json.loads(source.read_text(encoding="utf-8"))
            code=obj.get("language")
            if code in LANGUAGES:
                self.lang=code
                self.settings.setValue("interface_language",code)
            self._source_stamp=source.stat().st_mtime_ns
        except (OSError,ValueError,TypeError,AttributeError):pass

    @staticmethod
    def _write(file,lang):
        file.parent.mkdir(parents=True,exist_ok=True)
        tmp=file.with_suffix(".json.hddtmp")
        tmp.write_text(json.dumps({"version":1,"language":lang},indent=2),encoding="utf-8")
        os.replace(tmp,file)

    def select(self,lang):
        if lang not in LANGUAGES:return
        if self.lang!=lang:
            self.lang=lang
            self.settings.setValue("interface_language",lang)
            self.changed.emit(lang)
        source=fairy_language_path(self.settings)
        if source is not None:
            self._write(source,lang)
            self._source_path=source
            self._source_stamp=source.stat().st_mtime_ns
        self.translate_all()

    def _poll(self):
        path=fairy_language_path(self.settings)
        if path!=self._source_path:
            self._source_stamp=None
            self._source_path=path
        if path is not None and path.exists():
            try:
                stamp=path.stat().st_mtime_ns
                if stamp!=self._source_stamp:
                    self._source_stamp=stamp
                    data=json.loads(path.read_text(encoding="utf-8"))
                    language=data.get("language")
                    if language in LANGUAGES and language!=self.lang:
                        self.lang=language
                        self.settings.setValue("interface_language",language)
                        self.changed.emit(language)
            except (OSError,ValueError,TypeError,AttributeError):pass
        self.translate_all()

    def _translated(self,text,lang):
        if lang=="pt-BR" or not text:
            return text
        # The comprehensive, reviewed catalogue covers all main H.D.D.
        # modules (not just the initial dashboard).
        direct=CATALOG.get(text)
        if direct:return direct[0 if lang=="en-US" else 1]
        extended=translate_dynamic(text,lang)
        if extended is not None:return extended
        exact=UI_TEXT.get(text)
        if exact:return exact[0 if lang=="en-US" else 1]
        new=translate_catalog(text,lang)
        for src,dst in REPLACEMENTS.get(lang,{}).items():
            if src in new:
                new=new.replace(src,dst)
        return new

    def eventFilter(self,watched,event):
        # Qt Show is delivered BEFORE the first paint. Translate synchronously
        # to avoid a flash of source Portuguese in freshly created dialogs.
        # Updating after show via a QTimer was too late for the first frame.
        if event.type()==QEvent.Type.Show and isinstance(watched,QDialog):
            if not getattr(self,"_prepainting",False):
                self._prepainting=True
                try:
                    self.translate_all()
                finally:
                    self._prepainting=False
        elif event.type()==QEvent.Type.Show and isinstance(
                watched,(QTabWidget,QTableWidget,QTreeWidget,QListWidget)):
            # Keep this queued path for late population of view item models,
            # which may only exist after Show has completed.
            QTimer.singleShot(0,self.translate_all)
        return False

    def _field(self,widget,key,read,write):
        try:
            current=read()
            baseline=widget.property("_hdd_i18n_"+key)
            previous=widget.property("_hdd_prev_"+key)
            if baseline is None or (current!=previous and current!=baseline):
                baseline=current
                widget.setProperty("_hdd_i18n_"+key,baseline)
            converted=self._translated(baseline,self.lang)
            if converted!=current:write(converted)
            widget.setProperty("_hdd_prev_"+key,converted)
        except (RuntimeError,AttributeError):
            return

    def _item(self,item,kind='other'):
        if item is None:return
        text=item.text()
        role=9995
        baseline=item.data(role)
        prior=item.data(role+1)
        if baseline is None or (text!=prior and text!=baseline):
            baseline=text
            item.setData(role,baseline)
        # Translate only known short table labels, never file names or
        # arbitrary item data. Store original text so switching back works.
        # Recognize generated UI even when switching BACK to pt-BR.
        dyn=(translate_dynamic(baseline,"en-US") if kind=="diagnostic" else None)
        step=(translate_protocol_row(baseline,"en-US") if kind=="protocol" else None)
        if (baseline not in CATALOG and baseline not in UI_TEXT
            and dyn is None and step is None):
            return
        localized_step=(translate_protocol_row(baseline,self.lang)
                        if kind=="protocol" else None)
        expected=localized_step if localized_step is not None else self._translated(baseline,self.lang)
        if expected!=text:item.setText(expected)
        item.setData(role+1,expected)

    def translate_all(self):
        global _ACTIVE_LOCALE
        _ACTIVE_LOCALE=self.lang
        for widget in self.app.allWidgets():
            # Translate even inactive dashboard pages so switching tabs never
            # flashes their original Portuguese labels before the next poll.
            if isinstance(widget,(QLabel,QAbstractButton,QGroupBox)):
                current=widget.text() if hasattr(widget,"text") else widget.title()
                previous=widget.property("_hdd_last_localized")
                baseline=widget.property("_hdd_original")
                if baseline is None or (current!=previous and current!=baseline):
                    baseline=current
                    widget.setProperty("_hdd_original",baseline)
                localized=self._translated(baseline,self.lang)
                if localized!=current:
                    if hasattr(widget,"setText"):widget.setText(localized)
                    else:widget.setTitle(localized)
                widget.setProperty("_hdd_last_localized",localized)
            elif isinstance(widget,QComboBox):
                for i in range(widget.count()):
                    name=widget.itemText(i)
                    prop=f"_hdd_combo_original_{i}"
                    previous=f"_hdd_combo_translated_{i}"
                    baseline=widget.property(prop)
                    if baseline is None or (name!=widget.property(previous) and name!=baseline):
                        baseline=name
                        widget.setProperty(prop,baseline)
                    localized=self._translated(baseline,self.lang)
                    if name!=localized:widget.setItemText(i,localized)
                    widget.setProperty(previous,localized)
            if isinstance(widget,QLineEdit):
                placeholder=widget.placeholderText()
                baseline=widget.property("_hdd_placeholder_original")
                if baseline is None:baseline=placeholder;widget.setProperty("_hdd_placeholder_original",baseline)
                replacement=self._translated(baseline,self.lang)
                if placeholder!=replacement:widget.setPlaceholderText(replacement)
            # Titles, hover tips, page-tab captions and table headings were
            # ignored by the previous bridge and could remain in Portuguese.
            if widget.windowTitle():
                self._field(widget,"title",widget.windowTitle,widget.setWindowTitle)
            if widget.toolTip():
                self._field(widget,"tooltip",widget.toolTip,widget.setToolTip)
            if widget.statusTip():
                self._field(widget,"status_tip",widget.statusTip,widget.setStatusTip)
            if isinstance(widget,(QPlainTextEdit,QTextEdit,QLineEdit)):
                if hasattr(widget,"placeholderText"):
                    self._field(widget,"placeholder",widget.placeholderText,widget.setPlaceholderText)
            if isinstance(widget,QTabWidget):
                for n in range(widget.count()):
                    text=widget.tabText(n)
                    key=f"tab_{n}"
                    orig=widget.property("_hdd_i18n_"+key)
                    prev=widget.property("_hdd_prev_"+key)
                    if orig is None or (text!=prev and text!=orig):
                        orig=text
                        widget.setProperty("_hdd_i18n_"+key,orig)
                    dst=self._translated(orig,self.lang)
                    if dst!=text:widget.setTabText(n,dst)
                    widget.setProperty("_hdd_prev_"+key,dst)
            if isinstance(widget,QTableWidget):
                for n in range(widget.columnCount()):
                    self._item(widget.horizontalHeaderItem(n))
                for n in range(widget.rowCount()):
                    self._item(widget.verticalHeaderItem(n))
                # Dynamic table statuses are translated only if exact catalog
                # keys; filenames and values remain unchanged.
                for r in range(min(widget.rowCount(),250)):
                    for c in range(min(widget.columnCount(),12)):
                        self._item(widget.item(r,c),
                                   "diagnostic" if widget.objectName()=="hddDiagnosticsResults" else "other")
            if isinstance(widget,QTreeWidget):
                for i in range(widget.columnCount()):
                    self._item(widget.headerItem() if i==0 else None)
            if isinstance(widget,QListWidget):
                for i in range(min(300,widget.count())):
                    self._item(widget.item(i),"protocol")
            if isinstance(widget,QMessageBox):
                self._field(widget,"msgtext",widget.text,widget.setText)
                if widget.informativeText():
                    self._field(widget,"msginfo",widget.informativeText,widget.setInformativeText)
                if widget.detailedText():
                    self._field(widget,"msgdetails",widget.detailedText,widget.setDetailedText)
                buttons={
                    QMessageBox.StandardButton.Yes:("Yes","Sim","Sí"),
                    QMessageBox.StandardButton.No:("No","Não","No"),
                    QMessageBox.StandardButton.Ok:("OK","OK","Aceptar"),
                    QMessageBox.StandardButton.Cancel:("Cancel","Cancelar","Cancelar"),
                    QMessageBox.StandardButton.Save:("Save","Salvar","Guardar"),
                }
                index={"en-US":0,"pt-BR":1,"es-ES":2}.get(self.lang,0)
                for code,labels in buttons.items():
                    button=widget.button(code)
                    if button is not None and button.text()!=labels[index]:
                        button.setText(labels[index])
            for action in widget.actions():
                text=action.text()
                orig=action.property("_hdd_original")
                prev=action.property("_hdd_last_localized")
                if orig is None or (text!=prev and text!=orig):
                    orig=text;action.setProperty("_hdd_original",orig)
                target=self._translated(orig,self.lang)
                if target!=text:action.setText(target)
                action.setProperty("_hdd_last_localized",target)
