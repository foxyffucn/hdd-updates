"""H.D.D. Patch 012 — explicit, local operation protocols.

Only user-selected catalog items, H.D.D. modules and timed waits are permitted.
No hidden code execution, shell commands, administrative changes or file deletion.
The runner uses Qt timers so the map stays interactive between steps.
"""
from __future__ import annotations
from hdd.ui.locale_extensions import translate_step_label
from hdd.ui.language_bridge import painted_ui_text
from PySide6.QtCore import QSettings

import json
from pathlib import Path
import uuid
from datetime import datetime

from PySide6.QtCore import QIODevice, QSaveFile, Qt, QTimer, QProcess, QProcessEnvironment
from PySide6.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QInputDialog, QPushButton, QFileDialog, QSplitter, QTabWidget,
    QVBoxLayout, QWidget,
)

from hdd.ui.operations_hub import CatalogStore, catalog_path, open_target
from hdd.ui.protocol_actions import (
    chrome_profiles, parse_script, script_text, verify_action, run_action
)

PROTOCOL_LIMIT = 60
STEP_LIMIT = 20
LOG_LIMIT = 150
MODULES = {
    "terminal": "Terminal CMD / PowerShell",
    "files": "Explorador de Arquivos",
    "monitor": "Monitor do Sistema",
    "storage": "Analisador de Armazenamento",
    "recovery": "Recuperação de Arquivos",
    "apps": "Central de Aplicativos",
    "diagnostics": "Diagnóstico e Reparos",
    "code": "Code Workshop",
    "network": "Rede e Conexões",
    "downloads": "Central de Downloads",
    "remote": "Dispositivos Autorizados",
}


def _text(value,limit=75):
    return " ".join(str(value).split())[:limit]


def _steps_valid(steps):
    if not isinstance(steps,list) or len(steps)>STEP_LIMIT:
        raise ValueError("Um protocolo aceita no máximo 20 etapas.")
    for step in steps:
        if not isinstance(step,dict):
            raise ValueError("Etapa inválida.")
        kind=step.get("kind")
        if kind == "catalog":
            if not isinstance(step.get("id"),str) or not step["id"]:
                raise ValueError("Item do catálogo sem ID.")
        elif kind == "module":
            if step.get("key") not in MODULES:
                raise ValueError("Módulo não autorizado.")
        elif kind == "wait":
            if type(step.get("seconds")) is not int or not 1<=step["seconds"]<=30:
                raise ValueError("Espera deve ter entre 1 e 30 segundos.")
        elif kind == "folder":
            if not isinstance(step.get("path"),str) or not 1<=len(step["path"])<=1800:
                raise ValueError("Pasta do protocolo inválida.")
        elif kind in ("chrome_profile","chrome_profile_restore"):
            import re
            if not isinstance(step.get("profile"),str) or not re.fullmatch(
                    r"(Default|Profile [1-9][0-9]*)", step["profile"]):
                raise ValueError("Perfil Chrome do protocolo inválido.")
        else:
            raise ValueError("Ação não autorizada: "+str(kind))


class ProtocolStore:
    def __init__(self,path=None):
        self.path=path or catalog_path().with_name("operation_protocols.json")
        self.protocols=[]
        self.history=[]
        self.load()

    def load(self):
        if not self.path.exists():
            return
        if self.path.stat().st_size>1024*1024:
            raise ValueError("Arquivo de protocolos excessivamente grande.")
        data=json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data,dict) or data.get("version")!=1:
            raise ValueError("Arquivo de protocolos incompatível.")
        for entry in data.get("protocols",[])[:PROTOCOL_LIMIT]:
            try:
                if not isinstance(entry,dict):
                    continue
                steps=entry.get("steps",[])
                _steps_valid(steps)
                self.protocols.append({
                    "id":_text(entry.get("id",""),70),
                    "name":_text(entry.get("name",""),90),
                    "steps":steps,
                })
            except (ValueError,TypeError):
                continue
        self.history=[e for e in data.get("history",[])[:LOG_LIMIT] if isinstance(e,dict)]

    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        data=json.dumps(dict(version=1,protocols=self.protocols,
                             history=self.history[:LOG_LIMIT]),
                        indent=2,ensure_ascii=False).encode("utf-8")
        if len(data)>1024*1024:
            raise ValueError("O catálogo de protocolos está acima do limite.")
        f=QSaveFile(str(self.path))
        if not f.open(QIODevice.OpenModeFlag.WriteOnly):
            raise OSError("Não foi possível salvar os protocolos.")
        try:
            if f.write(data)!=len(data) or not f.commit():
                raise OSError("Falha ao gravar protocolos.")
        except BaseException:
            f.cancelWriting()
            raise

    def create(self,name,steps):
        name=_text(name,90)
        if not name or not steps:
            raise ValueError("Informe um nome e pelo menos uma ação.")
        _steps_valid(steps)
        if len(self.protocols)>=PROTOCOL_LIMIT:
            raise ValueError("Limite de protocolos alcançado.")
        item=dict(id=uuid.uuid4().hex,name=name,steps=[x.copy() for x in steps])
        self.protocols.append(item)
        try:
            self.save()
        except BaseException:
            self.protocols.remove(item)
            raise
        return item

    def by_id(self,identifier):
        return next((e for e in self.protocols if e["id"]==identifier),None)

    def record(self,protocol,message,result):
        entry=dict(date=datetime.now().isoformat(timespec="seconds"),
                   protocol=_text(protocol,90),result=result,message=_text(message,220))
        self.history.insert(0,entry)
        self.history=self.history[:LOG_LIMIT]
        self.save()


def label_step(step,catalog):
    if step["kind"]=="catalog":
        item=catalog.item_by_id(step["id"])
        return "ABRIR  //  "+(item["name"]+" — "+item["target"] if item else "ITEM REMOVIDO")
    if step["kind"]=="module":
        return "MÓDULO  //  "+MODULES[step["key"]]
    if step["kind"]=="folder":
        return "ABRIR PASTA  //  "+step["path"]
    if step["kind"] in ("chrome_profile","chrome_profile_restore"):
        name=next((label for ident,label in chrome_profiles() if ident==step["profile"]),step["profile"])
        prefix="CHROME + RESTAURAR" if step["kind"]=="chrome_profile_restore" else "CHROME"
        return prefix+"  //  "+name+" ["+step["profile"]+"]"
    return "AGUARDAR  //  "+str(step["seconds"])+" s"


def localized_step(step,catalog):
    source=label_step(step,catalog)
    locale=str(QSettings("HDD-Project","HDD-System").value("interface_language","en-US"))
    return translate_step_label(source,locale)


class ProtocolEditor(QDialog):
    def __init__(self,catalog,parent=None,initial=None):
        super().__init__(parent)
        self.catalog=catalog
        self.setWindowTitle("H.D.D. // EDITAR PROTOCOLO")
        self.setMinimumSize(570,520)
        self.resize(720,590)
        self.steps=[step.copy() for step in initial["steps"]] if initial else []
        self.result_data=None
        root=QVBoxLayout(self)
        root.addWidget(QLabel("PROTOCOLO  //  IDENTIFICAÇÃO"))
        self.name=QLineEdit(initial["name"] if initial else "")
        self.name.setPlaceholderText("Nome da operação")
        root.addWidget(self.name)
        root.addWidget(QLabel("ETAPAS  //  ORDEM DE EXECUÇÃO"))
        self.list=QListWidget()
        root.addWidget(self.list,1)
        add=QHBoxLayout()
        for label,fn in (("ADICIONAR ITEM",self.add_catalog),
                         ("ADICIONAR MÓDULO",self.add_module),
                         ("AGUARDAR",self.add_wait)):
            btn=QPushButton(label)
            btn.clicked.connect(fn)
            add.addWidget(btn)
        root.addLayout(add)
        advanced=QHBoxLayout()
        for label,fn in (("ABRIR PASTA",self.add_folder),
                         ("PERFIL CHROME",self.add_chrome_profile),
                         ("CHROME + RESTAURAR",self.add_restore_profile),
                         ("EDITAR SCRIPT",self.edit_script)):
            btn=QPushButton(label)
            btn.clicked.connect(fn)
            advanced.addWidget(btn)
        root.addLayout(advanced)
        edit=QHBoxLayout()
        for label,fn in (("SUBIR",lambda:self.move_step(-1)),
                         ("DESCER",lambda:self.move_step(1)),
                         ("REMOVER ETAPA",self.remove_step)):
            btn=QPushButton(label)
            btn.clicked.connect(fn)
            edit.addWidget(btn)
        root.addLayout(edit)
        controls=QHBoxLayout()
        done=QPushButton("SALVAR PROTOCOLO")
        done.clicked.connect(self.finish)
        controls.addWidget(done)
        cancel=QPushButton("CANCELAR")
        cancel.clicked.connect(self.reject)
        controls.addWidget(cancel)
        root.addLayout(controls)
        self.refresh()

    def refresh(self):
        chosen=self.list.currentRow()
        self.list.clear()
        for i,step in enumerate(self.steps):
            source=f"{i+1:02d}   {label_step(step,self.catalog)}"
            shown=f"{i+1:02d}   {localized_step(step,self.catalog)}"
            item=QListWidgetItem(shown)
            item.setData(9995,source)
            item.setData(9996,shown)
            self.list.addItem(item)
        if self.steps:
            self.list.setCurrentRow(max(0,min(chosen,len(self.steps)-1)))

    def append(self,step):
        if len(self.steps)>=STEP_LIMIT:
            QMessageBox.information(self,"Limite","Cada protocolo suporta até 20 etapas.")
            return
        self.steps.append(step)
        self.refresh()
        self.list.setCurrentRow(len(self.steps)-1)

    def add_catalog(self):
        options=[e["name"]+"  //  "+e["group"]+"  //  "+e["target"]
                 for e in self.catalog.items]
        if not options:
            QMessageBox.information(self,"Catálogo vazio",
                "Cadastre aplicativos ou pastas primeiro no setor APLICATIVOS.")
            return
        option,ok=QInputDialog.getItem(self,"Item cadastrado",
                                       "Escolha uma ação:",options,0,False)
        if ok:
            self.append(dict(kind="catalog",
                id=self.catalog.items[options.index(option)]["id"]))

    def add_module(self):
        labels=list(MODULES.values())
        option,ok=QInputDialog.getItem(self,"Módulo H.D.D.",
                                       "Abrir qual ferramenta?",labels,0,False)
        if ok:
            key=list(MODULES.keys())[labels.index(option)]
            self.append(dict(kind="module",key=key))

    def add_wait(self):
        seconds,ok=QInputDialog.getInt(self,"Espera entre operações",
                                        "Segundos (1 a 30):",2,1,30,1)
        if ok:
            self.append(dict(kind="wait",seconds=seconds))

    def add_folder(self):
        folder=QFileDialog.getExistingDirectory(
            self,"Escolha uma pasta para abrir durante o protocolo",str(Path.home()))
        if folder:
            self.append(dict(kind="folder",path=folder))

    def add_chrome_profile(self):
        self.choose_profile("chrome_profile")

    def add_restore_profile(self):
        self.choose_profile("chrome_profile_restore")

    def choose_profile(self, kind):
        profiles=chrome_profiles()
        if not profiles:
            QMessageBox.information(self,"Chrome",
                "Nenhum perfil do Google Chrome encontrado neste computador.")
            return
        options=[f"{name}  //  {identifier}" for identifier,name in profiles]
        chosen,ok=QInputDialog.getItem(self,"Abrir perfil do Chrome",
            "Escolha o perfil que deseja iniciar:",options,0,False)
        if ok:
            identifier=profiles[options.index(chosen)][0]
            self.append(dict(kind=kind,profile=identifier))

    def edit_script(self):
        help_text=(
            "# Ações permitidas (uma por linha):\n"
            "# PASTA \"C:\\Users\\...\"\n"
            "# CHROME \"Profile 1\"\n"
            "# CHROME_RESTAURAR \"Profile 4\"\n"
            "# ESPERAR 2\n"
            "# MODULO terminal\n"
            "# Apenas estes comandos. Nenhum código externo é executado.\n"
        )
        text = script_text(self.steps) if self.steps else help_text
        script,ok=QInputDialog.getMultiLineText(self,
            "H.D.D. // Editor de Script Seguro",
            "Escreva ações do protocolo. Isto substitui a lista de etapas:",text)
        if ok:
            try:
                parsed=parse_script(script,self.catalog)
                _steps_valid(parsed)
                if not parsed:
                    raise ValueError("Inclua pelo menos uma ação.")
                self.steps=parsed
                self.refresh()
            except Exception as exc:
                QMessageBox.warning(self,"Script inválido",str(exc))

    def move_step(self,direction):
        row=self.list.currentRow()
        to=row+direction
        if 0<=row<len(self.steps) and 0<=to<len(self.steps):
            self.steps[row],self.steps[to]=self.steps[to],self.steps[row]
            self.refresh()
            self.list.setCurrentRow(to)

    def remove_step(self):
        row=self.list.currentRow()
        if 0<=row<len(self.steps):
            self.steps.pop(row)
            self.refresh()

    def finish(self):
        try:
            _steps_valid(self.steps)
            if not self.steps or not self.name.text().strip():
                raise ValueError("Informe um nome e pelo menos uma ação.")
            self.result_data=(_text(self.name.text(),90),
                              [x.copy() for x in self.steps])
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self,"Protocolo incompleto",str(exc))


# Patch 014 replaces the tiny modal text editor with two synchronized,
# user-friendly editing modes. The underlying ProtocolStore is unchanged.
from hdd.ui.protocol_editor_modes import VisualAdvancedProtocolEditor as ProtocolEditor


class ProtocolCenterDialog(QDialog):
    def __init__(self,parent=None,open_module=None,store=None,catalog=None):
        super().__init__(parent)
        self.setWindowTitle("H.D.D. // PROTOCOLOS DE OPERAÇÃO")
        self.setObjectName("hddProtocolCenter")
        self.resize(1060,720)
        self.setMinimumSize(780,540)
        self.store=store or ProtocolStore()
        self.catalog=catalog or CatalogStore()
        self.open_module=open_module
        self._run_steps=None
        self._run_protocol=None
        self._run_cursor=0
        self._run_timer=QTimer(self)
        self._recovery_proc=None
        self._restore_watchdog=QTimer(self)
        self._restore_watchdog.setSingleShot(True)
        self._restore_watchdog.timeout.connect(self._restore_timed_out)
        self._run_timer.setSingleShot(True)
        self._run_timer.timeout.connect(self.next_step)
        self.setStyleSheet("""
          QDialog#hddProtocolCenter{background:#071a2b;}
          QLabel{color:#dff8ff;}
          QLabel#head{font:700 27px 'zero 5','Segoe UI';}
          QLabel#small{font:600 11px Consolas;color:#8ecae0;}
          QListWidget{background:#0a2336;border:1px solid #367089;
            color:#dff9ff;font:12px Consolas;}
          QPushButton{background:#17425b;color:#e1fbff;border:1px solid #478099;
            border-radius:3px;padding:9px;font:600 11px 'Segoe UI';}
          QPushButton:hover{background:#246580;}
          QPushButton:disabled{background:#123043;color:#7895a2;}
          QTabWidget::pane{border:1px solid #32627f;}
          QTabBar::tab{background:#13394e;color:#b3d6e4;padding:9px 18px;}
          QTabBar::tab:selected{background:#286984;color:white;}
        """)
        root=QVBoxLayout(self)
        heading=QLabel("PROTOCOLOS DE OPERAÇÃO")
        heading.setObjectName("head")
        root.addWidget(heading)
        caption=QLabel("HELIOS  //  WORKFLOW PROTOCOLS  /  EXECUÇÃO LOCAL COM CONFIRMAÇÃO")
        caption.setObjectName("small")
        root.addWidget(caption)
        self.tabs=QTabWidget()
        root.addWidget(self.tabs,1)
        protocols=QWidget()
        layout=QHBoxLayout(protocols)
        left=QVBoxLayout()
        left.addWidget(QLabel("PROTOCOLOS SALVOS"))
        self.list=QListWidget()
        self.list.currentItemChanged.connect(self.refresh_details)
        left.addWidget(self.list,1)
        buttons=QHBoxLayout()
        for label,fn in (("NOVO",self.create),("EDITAR",self.edit),
                         ("EXCLUIR",self.delete)):
            button=QPushButton(label)
            button.clicked.connect(fn)
            buttons.addWidget(button)
        left.addLayout(buttons)
        layout.addLayout(left,2)
        right=QVBoxLayout()
        right.addWidget(QLabel("ETAPAS DO PROTOCOLO  //  PRÉVIA"))
        self.details=QListWidget()
        right.addWidget(self.details,1)
        self.start=QPushButton("EXECUTAR PROTOCOLO")
        self.start.clicked.connect(self.start_run)
        right.addWidget(self.start)
        self.cancel=QPushButton("CANCELAR EXECUÇÃO")
        self.cancel.clicked.connect(self.cancel_run)
        self.cancel.setEnabled(False)
        right.addWidget(self.cancel)
        layout.addLayout(right,3)
        self.tabs.addTab(protocols,"PROTOCOLOS")
        history=QWidget()
        history_layout=QVBoxLayout(history)
        history_layout.addWidget(QLabel("HISTÓRICO DE EXECUÇÃO  //  ÚLTIMOS 150 EVENTOS"))
        self.history_list=QListWidget()
        history_layout.addWidget(self.history_list)
        self.tabs.addTab(history,"HISTÓRICO")
        foot=QHBoxLayout()
        self.status=QLabel("Crie um protocolo ou selecione um salvo.")
        self.status.setWordWrap(True)
        self.status.setObjectName("small")
        foot.addWidget(self.status,1)
        close=QPushButton("VOLTAR")
        close.clicked.connect(self.close)
        foot.addWidget(close)
        root.addLayout(foot)
        self.refresh()

    def refresh(self):
        selected=self.selected()
        keep=selected["id"] if selected else None
        self.list.clear()
        for entry in self.store.protocols:
            row=QListWidgetItem(f"{entry['name']}  //  {len(entry['steps'])} etapas")
            row.setData(Qt.ItemDataRole.UserRole,entry["id"])
            self.list.addItem(row)
            if entry["id"]==keep:
                self.list.setCurrentItem(row)
        if self.list.currentItem() is None and self.list.count():
            self.list.setCurrentRow(0)
        self.refresh_details()
        self.history_list.clear()
        for item in self.store.history:
            self.history_list.addItem(
                item.get("date","")+" | "+item.get("result","")+" | "
                +item.get("protocol","")+" — "+item.get("message",""))
        self.start.setEnabled(self._run_steps is None)

    def selected(self):
        entry=self.list.currentItem()
        if not entry:
            return None
        return self.store.by_id(entry.data(Qt.ItemDataRole.UserRole))

    def refresh_details(self,*_):
        self.details.clear()
        entry=self.selected()
        if entry:
            for i,step in enumerate(entry["steps"],1):
                source=f"{i:02d}   {label_step(step,self.catalog)}"
                shown=f"{i:02d}   {localized_step(step,self.catalog)}"
                item=QListWidgetItem(shown)
                item.setData(9995,source)
                item.setData(9996,shown)
                self.details.addItem(item)

    def create_for_folder(self,folder):
        """Propose, but never silently save or execute, a protocol for this folder."""
        if self._run_steps is not None:
            raise RuntimeError("Aguarde a execução atual terminar.")
        from hdd.ui.protocol_actions import verify_action
        path=Path(folder).expanduser().resolve(strict=True)
        if not path.is_dir() or path.is_symlink():
            raise ValueError("Selecione uma pasta válida para o protocolo.")
        step=dict(kind="folder",path=str(path))
        verify_action(step)
        example=dict(name="Abrir "+path.name,steps=[step])
        editor=ProtocolEditor(self.catalog,self,initial=example)
        if editor.exec()==QDialog.DialogCode.Accepted and editor.result_data:
            created=self.store.create(*editor.result_data)
            self.refresh()
            self.status.setText("Protocolo preparado: "+created["name"]+
                                " (ainda não executado)")
            return created
        return None

    def create(self):
        if self._run_steps is not None:
            return
        editor=ProtocolEditor(self.catalog,self)
        if editor.exec()==QDialog.DialogCode.Accepted and editor.result_data:
            try:
                entry=self.store.create(*editor.result_data)
                self.refresh()
                self.status.setText("Protocolo criado: "+entry["name"])
            except Exception as exc:
                QMessageBox.warning(self,"Falha ao salvar",str(exc))

    def edit(self):
        entry=self.selected()
        if not entry or self._run_steps is not None:
            return
        editor=ProtocolEditor(self.catalog,self,entry)
        if editor.exec()==QDialog.DialogCode.Accepted and editor.result_data:
            before=(entry["name"],entry["steps"])
            entry["name"],entry["steps"]=editor.result_data
            try:
                self.store.save()
                self.refresh()
            except Exception as exc:
                entry["name"],entry["steps"]=before
                QMessageBox.warning(self,"Falha ao salvar",str(exc))

    def delete(self):
        entry=self.selected()
        if not entry or self._run_steps is not None:
            return
        if QMessageBox.question(self,"Remover protocolo",
                "Remover protocolo '"+entry["name"]+"'? Aplicativos e projetos serão preservados.",
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:
            return
        self.store.protocols.remove(entry)
        try:
            self.store.save()
            self.refresh()
        except Exception as exc:
            self.store.protocols.append(entry)
            QMessageBox.warning(self,"Falha ao salvar",str(exc))

    def start_run(self):
        entry=self.selected()
        if not entry or self._run_steps is not None:
            return
        steps=[x.copy() for x in entry["steps"]]
        try:
            _steps_valid(steps)
            actions=[]
            for step in steps:
                if step["kind"]=="catalog":
                    item=self.catalog.item_by_id(step["id"])
                    if item is None:
                        raise ValueError("O protocolo contém um item do catálogo que foi removido.")
                    from hdd.ui.operations_hub import _validate_target
                    _validate_target(item["kind"],item["target"])
                elif step["kind"] in ("folder","chrome_profile","chrome_profile_restore"):
                    verify_action(step)
                actions.append(label_step(step,self.catalog))
        except Exception as exc:
            QMessageBox.warning(self,"Protocolo indisponível",str(exc))
            return
        if not actions:
            return
        preview="\n".join(f"{i:02d}  {line}" for i,line in enumerate(actions,1))
        if QMessageBox.question(self,"Confirmar execução",
                "Executar protocolo '"+entry["name"]+"'?\n\n"
                +preview[:3500]+"\n\nNenhum comando é executado sem autorização.",
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:
            return
        self._run_protocol=entry["name"]
        self._run_steps=steps
        self._run_cursor=0
        self.cancel.setEnabled(True)
        self.start.setEnabled(False)
        self.status.setText("Protocolo em execução...")
        self._run_timer.start(0)

    def next_step(self):
        if self._run_steps is None:
            return
        if self._run_cursor>=len(self._run_steps):
            self.finish_run("CONCLUÍDO","Todas as etapas terminaram.")
            return
        step=self._run_steps[self._run_cursor]
        self._run_cursor+=1
        self.status.setText(
            f"EXECUTANDO ETAPA {self._run_cursor}/{len(self._run_steps)}  //  "
            + label_step(step,self.catalog))
        try:
            if step["kind"]=="catalog":
                item=self.catalog.item_by_id(step["id"])
                if item is None:
                    raise ValueError("Item cadastrado não encontrado.")
                open_target(item)
                # OS application launches return before their windows are ready.
                delay=1750
            elif step["kind"]=="module":
                if self.open_module is None:
                    raise ValueError("A interface do módulo não está conectada.")
                self.open_module(step["key"])
                delay=950
            elif step["kind"] in ("folder","chrome_profile"):
                run_action(step)
                # Keep launch order deterministic, especially directly after
                # Windows boots when Explorer/Chrome initialize slowly.
                delay=2300 if step["kind"]=="folder" else 2500
            elif step["kind"]=="chrome_profile_restore":
                run_action(step)
                self.status.setText(
                    f"ETAPA {self._run_cursor}/{len(self._run_steps)}  //  "
                    f"Chrome {step['profile']}: aguardando aviso Restaurar...")
                self._start_restore_watcher()
                return
            else:
                delay=step["seconds"]*1000
            self.status.setText(
                f"Etapa {self._run_cursor}/{len(self._run_steps)}: "
                +label_step(step,self.catalog))
            self._run_timer.start(delay)
        except Exception as exc:
            self.finish_run("FALHA",f"Etapa {self._run_cursor}: {exc}")

    def _start_restore_watcher(self):
        if self._recovery_proc is not None:
            raise RuntimeError("Já existe uma recuperação em andamento.")
        from hdd.ui.protocol_actions import chrome_path, chrome_restore_encoded
        binary=chrome_path()
        if binary is None:
            raise FileNotFoundError("Chrome não encontrado.")
        proc=QProcess(self)
        self._recovery_proc=proc
        proc.setProgram("powershell.exe")
        proc.setArguments([
            "-NoProfile","-NonInteractive","-STA",
            "-EncodedCommand",chrome_restore_encoded()
        ])
        process_env=QProcessEnvironment.systemEnvironment()
        process_env.insert("HDD_EXPECTED_CHROME_EXE",str(binary))
        process_env.remove("HDD_DRY_RUN")
        proc.setProcessEnvironment(process_env)
        proc.setProcessChannelMode(QProcess.ProcessChannelMode.MergedChannels)
        proc.finished.connect(self._restore_process_finished)
        proc.errorOccurred.connect(self._restore_process_error)
        proc.start()
        # Chrome automation must not block this protocol indefinitely,
        # even if a Windows accessibility provider becomes unresponsive.
        self._restore_watchdog.start(73000)

    def _restore_timed_out(self):
        if self._run_steps is None or self._recovery_proc is None:
            return
        proc=self._recovery_proc
        self._recovery_proc=None
        proc.kill()
        proc.deleteLater()
        self.finish_run("ATENÇÃO",
            f"Etapa {self._run_cursor}: Chrome não concluiu a detecção do "
            "aviso no prazo. Restaure as guias manualmente.")

    def _restore_process_error(self, error):
        if self._run_steps is not None and self._recovery_proc is not None:
            proc=self._recovery_proc
            self._recovery_proc=None
            self._restore_watchdog.stop()
            proc.kill()
            proc.deleteLater()
            self.finish_run("ATENÇÃO",
                f"Etapa {self._run_cursor}: não foi possível iniciar a "
                "automação do Chrome.")

    def _restore_process_finished(self, exit_code, exit_status):
        proc=self._recovery_proc
        if proc is None:
            return
        self._restore_watchdog.stop()
        raw=bytes(proc.readAllStandardOutput()).decode("utf-8",errors="replace")
        self._recovery_proc=None
        proc.deleteLater()
        if self._run_steps is None:
            return
        codes={
            "RESTORED": "RESTORED",
            "NO_RESTORE_PROMPT": "NO_RESTORE_PROMPT",
            "MULTIPLE_RESTORE_PROMPTS": "MULTIPLE_RESTORE_PROMPTS",
            "CHROME_NOT_VISIBLE": "CHROME_NOT_VISIBLE",
            "INVOKE_UNCONFIRMED": "INVOKE_UNCONFIRMED",
            "INVOKE_FAILED": "INVOKE_FAILED",
            "AUTOMATION_UNAVAILABLE": "AUTOMATION_UNAVAILABLE",
            "CHROME_PATH_MISSING": "CHROME_PATH_MISSING",
        }
        # Match entire PowerShell output lines, never substrings.
        lines=[line.strip() for line in raw.splitlines() if line.strip()]
        code=next((text for text in reversed(lines) if text in codes),None)
        step=self._run_steps[self._run_cursor-1]
        profile=step.get("profile","perfil desconhecido")
        if exit_code==0 and code=="RESTORED":
            self.status.setText(
                f"ETAPA {self._run_cursor}/{len(self._run_steps)}  //  "
                f"Chrome {profile}: aviso Restaurar confirmado.")
            # Let the browser finish dismissing its crash bubble before
            # the next action can open another Chrome profile.
            self._run_timer.start(1600)
            return
        reasons={
            "NO_RESTORE_PROMPT":
                "O Chrome abriu, mas não foi encontrado o aviso Restaurar. "
                "Talvez a sessão já esteja aberta ou o aviso não tenha aparecido.",
            "CHROME_NOT_VISIBLE":
                "Nenhuma janela Chrome válida ficou visível durante a espera.",
            "MULTIPLE_RESTORE_PROMPTS":
                "Foram encontrados vários avisos de restauração. "
                "O H.D.D. não escolheu um perfil aleatoriamente.",
            "INVOKE_UNCONFIRMED":
                "O botão Restaurar foi acionado, mas o Chrome não confirmou "
                "que o aviso foi fechado.",
            "INVOKE_FAILED":
                "O Windows não permitiu acionar o botão Restaurar.",
            "AUTOMATION_UNAVAILABLE":
                "A interface de acessibilidade do Windows está indisponível.",
            "CHROME_PATH_MISSING":
                "O caminho do Chrome não foi recebido pelo detector.",
        }
        explanation=reasons.get(code,
            "O detector do Chrome terminou com um resultado inesperado. "
            f"Código do processo: {exit_code}.")
        self.finish_run("ATENÇÃO",
            f"Etapa {self._run_cursor} ({profile}): {explanation} "
            "Verifique as guias manualmente; nenhuma outra etapa foi iniciada.")

    def cancel_run(self):
        self._restore_watchdog.stop()
        if self._recovery_proc is not None:
            proc=self._recovery_proc
            self._recovery_proc=None
            proc.kill()
            proc.deleteLater()
        if self._run_steps is not None:
            self.finish_run("CANCELADO","Interrompido pelo operador.")

    def finish_run(self,result,message):
        self._run_timer.stop()
        self._restore_watchdog.stop()
        name=self._run_protocol or "Desconhecido"
        self._run_steps=None
        self._run_protocol=None
        self.cancel.setEnabled(False)
        self.start.setEnabled(True)
        self.status.setText(result+"  //  "+message)
        try:
            self.store.record(name,message,result)
        except Exception as exc:
            self.status.setText(result+"; falha ao registrar histórico: "+str(exc))
        self.refresh()

    def closeEvent(self,event):
        if self._run_steps is not None:
            if QMessageBox.question(self,"Cancelar protocolo",
                    "Há uma operação em andamento. Cancelar próximas etapas e fechar?\n"
                    "Programas já abertos continuarão em execução.",
                    QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                    QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:
                event.ignore()
                return
            self.cancel_run()
        super().closeEvent(event)
