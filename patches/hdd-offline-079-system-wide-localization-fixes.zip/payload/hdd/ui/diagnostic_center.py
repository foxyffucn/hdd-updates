"""H.D.D. Patch 014 — read-only Windows/H.D.D. diagnostic checks.

Diagnostic recommendations are informational; never changes Windows settings
or repairs files automatically. Buttons open official local Windows utilities.
"""
from __future__ import annotations

import ctypes
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import shutil
import subprocess

from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QHeaderView, QMessageBox
)

from hdd.paths import project_root
from hdd.ui.language_bridge import painted_ui_text,set_localized_text


def _gib(value):
    return f"{value/1073741824:.1f} GiB"


def _startup_count():
    if os.name!="nt":
        return None
    try:
        import winreg
        paths=[(winreg.HKEY_CURRENT_USER,r"Software\Microsoft\Windows\CurrentVersion\Run"),
               (winreg.HKEY_LOCAL_MACHINE,r"Software\Microsoft\Windows\CurrentVersion\Run")]
        total=0
        for hive,key in paths:
            try:
                with winreg.OpenKey(hive,key,0,winreg.KEY_READ) as reg:
                    total+=winreg.QueryInfoKey(reg)[1]
            except OSError:
                pass
        return total
    except OSError:
        return None


def _recent_system_errors():
    if os.name!="nt":
        return None
    try:
        # Bounded sampling, not an exhaustive count of every system event.
        cmd=["wevtutil.exe","qe","System",
             "/q:*[System[(Level=1 or Level=2) and TimeCreated[timediff(@SystemTime) <= 86400000]]]",
             "/c:30","/f:xml"]
        result=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                              timeout=8,check=False,
                              creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        if result.returncode:
            return None
        return len(re.findall(rb"<Event\b",result.stdout))
    except (OSError,subprocess.TimeoutExpired):
        return None


def _hdd_integrity(root):
    """Compare with latest installed patch records, without touching user data."""
    registry=root/"_patches"
    latest={}
    for marker in sorted(registry.glob("*.json")):
        try:
            contents=json.loads(marker.read_text(encoding="utf-8"))
            checks=contents.get("after_sha256",{})
            if isinstance(checks,dict) and contents.get("patch"):
                for rel,value in checks.items():
                    if (isinstance(rel,str) and isinstance(value,str) and
                        len(value)==64 and not Path(rel).is_absolute()
                        and ".." not in Path(rel).parts):
                        latest[rel]=value
        except (OSError,ValueError,TypeError):
            continue
    discrepancies=[]
    for rel,digest in latest.items():
        path=root/rel
        try:
            if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=digest:
                discrepancies.append(rel)
        except OSError:
            discrepancies.append(rel)
    return len(latest),discrepancies


def analyze_machine(root=None):
    """Quick read-only health checks; no admin rights required."""
    root=Path(root or project_root())
    results=[]
    def add(title,status,detail,advice):
        results.append((title,status,detail,advice))

    try:
        drive=Path(os.environ.get("SystemDrive","C:")+"\\") if os.name=="nt" else root
        storage=shutil.disk_usage(drive)
        free_percentage=storage.free/storage.total*100 if storage.total else 0
        state="ATENÇÃO" if free_percentage<10 else "OK"
        add("Espaço livre no sistema",state,
            f"{_gib(storage.free)} livres de {_gib(storage.total)} ({free_percentage:.1f}%)",
            "Use ARMAZENAMENTO para localizar arquivos grandes; revise antes de excluir.")
    except (OSError,ValueError) as exc:
        add("Espaço livre no sistema","INDISPONÍVEL",str(exc)[:110],
            "Verifique a unidade no Explorador.")

    if os.name=="nt":
        try:
            class MemoryInfo(ctypes.Structure):
                _fields_=[("dwLength",ctypes.c_ulong),("dwMemoryLoad",ctypes.c_ulong),
                          ("ullTotalPhys",ctypes.c_ulonglong),
                          ("ullAvailPhys",ctypes.c_ulonglong),
                          ("ullTotalPageFile",ctypes.c_ulonglong),
                          ("ullAvailPageFile",ctypes.c_ulonglong),
                          ("ullTotalVirtual",ctypes.c_ulonglong),
                          ("ullAvailVirtual",ctypes.c_ulonglong),
                          ("ullAvailExtendedVirtual",ctypes.c_ulonglong)]
            memory=MemoryInfo();memory.dwLength=ctypes.sizeof(memory)
            if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(memory)):
                pct=memory.dwMemoryLoad
                add("Memória RAM","ATENÇÃO" if pct>=90 else "OK",
                    f"{pct}% em uso • {_gib(memory.ullAvailPhys)} disponíveis",
                    "Abra MONITOR para identificar processos com maior consumo.")
        except (AttributeError,OSError):
            add("Memória RAM","INDISPONÍVEL","Leitura não suportada","Use o Monitor do Sistema.")
        try:
            uptime=ctypes.windll.kernel32.GetTickCount64
            uptime.restype=ctypes.c_ulonglong
            hours=uptime()//3600000
            add("Tempo de atividade do Windows","INFO",f"{hours//24} dias e {hours%24} horas",
                "Se houver lentidão persistente, um reinício normal pode ajudar.")
        except (OSError,AttributeError):
            pass

    n=_startup_count()
    if n is not None:
        add("Inicialização de aplicativos","INFO",f"{n} entradas nas chaves Run do Windows",
            "Consulte o Gerenciador de Tarefas → Inicializar para revisar.")

    n=_recent_system_errors()
    if n is not None:
        add("Eventos de erro no Windows","INFO",
            f"{n} eventos críticos/erros encontrados na amostra (últimas 24 h, máx. 30)",
            "Abra o Visualizador de Eventos para analisar detalhes e causas.")
    else:
        add("Eventos de erro no Windows","INDISPONÍVEL",
            "Log inacessível ou indisponível para esta conta.",
            "Use o Visualizador de Eventos para consultar os registros.")

    try:
        total,discrepancies=_hdd_integrity(root)
        if total:
            state="INFO" if discrepancies else "OK"
            detail=(f"{total} arquivos comparados; {len(discrepancies)} alteração(ões) local(is)"
                    +(" — "+", ".join(discrepancies[:2]) if discrepancies else ""))
            add("Integridade de patches H.D.D.",state,detail,
                "Alterações locais podem ser legítimas. Faça backup e revise antes de restaurar qualquer arquivo.")
        else:
            add("Integridade de patches H.D.D.","INFO",
                "Nenhum registro de hash para comparar.",
                "Consulte a Central de Atualizações.")
    except (OSError,ValueError) as exc:
        add("Integridade de patches H.D.D.","INDISPONÍVEL",str(exc)[:100],
            "Verifique os registros de atualização.")
    return results


class DiagnosticWorker(QThread):
    done=Signal(object)
    def __init__(self,parent=None):
        super().__init__(parent)
    def run(self):
        self.done.emit(analyze_machine())


class DiagnosticCenterDialog(QDialog):
    TOOLS=(
        ("GERENCIADOR DE TAREFAS","taskmgr.exe"),
        ("EVENTOS DO WINDOWS","eventvwr.msc"),
        ("GERENCIAR DISCOS","diskmgmt.msc"),
        ("RECURSOS DO SISTEMA","resmon.exe"),
    )
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle("H.D.D. // DIAGNÓSTICO E REPAROS")
        self.setObjectName("hddDiagnosticCenter")
        self.resize(1050,690)
        self.setMinimumSize(800,550)
        self.worker=None
        self._closing=False
        self.setStyleSheet("""
          QDialog#hddDiagnosticCenter{background:#071a2a;}
          QLabel{color:#dcf8ff;}
          QLabel#diagHead{font:700 27px 'zero 5','Segoe UI';}
          QLabel#diagSub{font:600 11px Consolas;color:#95d0e5;}
          QTableWidget{background:#071e30;color:#d7f6ff;gridline-color:#245269;
                       alternate-background-color:#112b40;
                       selection-color:#ffffff;
                       border:1px solid #39748d;font:12px Consolas;
                       selection-background-color:#285e79;}
          QTableWidget::item:selected{background:#285e79;color:#ffffff;}
          QHeaderView::section{background:#133a51;color:#dbf8ff;
                       border:1px solid #316179;padding:8px;}
          QPushButton{background:#153b54;color:#d9f6ff;border:1px solid #3e809b;
                       border-radius:3px;padding:9px;font:600 11px 'Segoe UI';}
          QPushButton:hover{background:#236581;}
        """)
        layout=QVBoxLayout(self)
        layout.setContentsMargins(18,17,18,17)
        title=QLabel("DIAGNÓSTICO E REPAROS")
        title.setObjectName("diagHead")
        layout.addWidget(title)
        desc=QLabel("HELIOS // SYSTEM CHECK  /  ANÁLISE LOCAL SOMENTE LEITURA")
        desc.setObjectName("diagSub")
        layout.addWidget(desc)
        self.table=QTableWidget(0,4)
        self.table.setObjectName("hddDiagnosticsResults")
        self.table.setHorizontalHeaderLabels(
            ["ÁREA","STATUS","RESULTADO","ORIENTAÇÃO"])
        self.table.setWordWrap(True)
        self.table.verticalHeader().hide()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        for i in (0,1):
            self.table.horizontalHeader().setSectionResizeMode(i,QHeaderView.ResizeMode.ResizeToContents)
        for i in (2,3):
            self.table.horizontalHeader().setSectionResizeMode(i,QHeaderView.ResizeMode.Stretch)
        layout.addWidget(self.table,1)
        self.status=QLabel("Aguardando diagnósticos...")
        self.status.setObjectName("diagSub")
        layout.addWidget(self.status)
        options=QHBoxLayout()
        self.refresh=QPushButton("ANALISAR NOVAMENTE")
        self.refresh.clicked.connect(self.start_diagnostics)
        options.addWidget(self.refresh)
        for label,exe in self.TOOLS:
            action=QPushButton(label)
            action.clicked.connect(lambda _checked=False,target=exe:self.open_tool(target))
            options.addWidget(action)
        close=QPushButton("VOLTAR")
        close.clicked.connect(self.close)
        options.addWidget(close)
        layout.addLayout(options)
        self.start_diagnostics()

    def start_diagnostics(self):
        if self.worker is not None or self._closing:
            return
        self.refresh.setEnabled(False)
        set_localized_text(self.status,"Analisando o Windows e o H.D.D. — aguarde...")
        worker=DiagnosticWorker(self)
        self.worker=worker
        worker.done.connect(self.receive)
        worker.finished.connect(lambda w=worker:self.finished_reading(w))
        worker.start()

    def receive(self,rows):
        if self._closing:
            return
        self.table.setRowCount(len(rows))
        for row,record in enumerate(rows):
            for col,value in enumerate(record):
                # Values are fixed diagnostic UI messages or numeric readings,
                # never arbitrary user file names. Keep original paths intact.
                original=str(value)
                localized=painted_ui_text(original)
                item=QTableWidgetItem(localized)
                # Model items require their canonical Portuguese source for
                # later EN/PT/ES switching. Never localize user's file paths.
                item.setData(9995,original)
                item.setData(9996,localized)
                from PySide6.QtGui import QColor
                item.setBackground(QColor("#071e30" if row%2==0 else "#112b40"))
                if col==1:
                    item.setForeground(QColor("#f6bd7e" if value=="ATENÇÃO"
                                              else "#8ce7bc" if value=="OK"
                                              else "#b3d5e8"))
                self.table.setItem(row,col,item)
            self.table.resizeRowToContents(row)
        set_localized_text(self.status,
            f"{len(rows)} verificações concluídas. Nenhum arquivo ou serviço foi alterado.")

    def finished_reading(self,worker):
        if self.worker is worker:
            self.worker=None
        worker.deleteLater()
        if self._closing:
            self._closing=False
            QTimer.singleShot(0,self.reject)
        else:
            self.refresh.setEnabled(True)

    def open_tool(self,exe):
        if exe not in dict((target,label) for label,target in self.TOOLS):
            return
        if QMessageBox.question(self,"Abrir ferramenta do Windows",
                "Abrir a ferramenta oficial do Windows?\n\n"+exe,
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:
            return
        try:
            os.startfile(exe)
        except OSError as exc:
            QMessageBox.warning(self,"Ferramenta indisponível",str(exc))

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():
            self._closing=True
            self.hide()
            event.ignore()
            return
        super().closeEvent(event)
