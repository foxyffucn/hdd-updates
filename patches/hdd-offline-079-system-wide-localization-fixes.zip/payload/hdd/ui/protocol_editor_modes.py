"""H.D.D. Patch 014 — reversible Visual / Advanced protocol editing.

Both modes share the same allowlisted DSL and a single step list. No Python,
PowerShell, JavaScript eval, unrestricted process execution, or unsafe file ops.
"""
from __future__ import annotations
from hdd.ui.locale_extensions import translate_step_label
from PySide6.QtCore import QSettings

from pathlib import Path
import re

from PySide6.QtCore import Qt, QSignalBlocker, QTimer, QRegularExpression
from PySide6.QtGui import QColor, QFont, QTextCharFormat, QSyntaxHighlighter
from PySide6.QtWidgets import (
    QComboBox, QDialog, QFileDialog, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QPushButton, QPlainTextEdit,
    QSpinBox, QStackedWidget, QTabWidget, QVBoxLayout, QWidget
)

from hdd.ui.protocol_actions import (
    chrome_profiles, parse_script, script_text, verify_action
)


class ProtocolHighlighter(QSyntaxHighlighter):
    """Highlight only the supported commands and comments."""
    def __init__(self, document):
        super().__init__(document)
        self.command = QTextCharFormat()
        self.command.setForeground(QColor("#87eaff"))
        self.command.setFontWeight(QFont.Weight.Bold)
        self.comment = QTextCharFormat()
        self.comment.setForeground(QColor("#658ca4"))
        self.value = QTextCharFormat()
        self.value.setForeground(QColor("#b6efbd"))
        self.pattern = QRegularExpression(
            r"^\s*(PASTA|CHROME|CHROME_RESTAURAR|ESPERAR|AGUARDAR|MODULO|CATALOGO)\b",
            QRegularExpression.PatternOption.CaseInsensitiveOption
        )
        self.quoted = QRegularExpression(r'"[^"]*"')

    def highlightBlock(self, text):
        if text.lstrip().startswith("#"):
            self.setFormat(0,len(text),self.comment)
            return
        match=self.pattern.match(text)
        if match.hasMatch():
            self.setFormat(match.capturedStart(1),match.capturedLength(1),self.command)
        it=self.quoted.globalMatch(text)
        while it.hasNext():
            item=it.next()
            self.setFormat(item.capturedStart(),item.capturedLength(),self.value)


class VisualAdvancedProtocolEditor(QDialog):
    TYPES=(
        ("Abrir pasta","folder",0),
        ("Abrir perfil Chrome","chrome_profile",1),
        ("Chrome + Restaurar","chrome_profile_restore",1),
        ("Abrir item do catálogo","catalog",2),
        ("Abrir módulo H.D.D.","module",3),
        ("Aguardar segundos","wait",4),
    )

    def __init__(self,catalog,parent=None,initial=None):
        super().__init__(parent)
        self.catalog=catalog
        self.steps=[dict(x) for x in initial["steps"]] if initial else []
        self.result_data=None
        self._building=False
        self._last_mode=0
        self.setWindowTitle("H.D.D. // EDITOR DE PROTOCOLOS")
        self.setMinimumSize(765,650)
        self.resize(980,770)
        self.setObjectName("hddProtocolEditor014")
        self.setStyleSheet("""
          QDialog#hddProtocolEditor014{background:#061929;}
          QLabel{color:#d2f1fa;}
          QLabel#subtitle{color:#7cbfd7;font:600 11px Consolas;}
          QTabWidget::pane{border:1px solid #336b85;}
          QTabBar::tab{background:#103349;color:#a4d7e5;padding:12px 18px;
                       font:600 12px Consolas;}
          QTabBar::tab:selected{background:#276886;color:#f3feff;}
          QListWidget,QPlainTextEdit{background:#081e30;color:#e2faff;
                       border:1px solid #37738e;font:12px Consolas;
                       selection-background-color:#23627e;padding:6px;}
          QLineEdit,QComboBox,QSpinBox{background:#0c3047;color:#e3faff;
                       border:1px solid #397991;padding:8px;font:12px Consolas;}
          QPushButton{background:#173e55;color:#ddfaff;
                       border:1px solid #4b879f;border-radius:4px;
                       padding:9px 11px;font:600 11px 'Segoe UI';}
          QPushButton:hover{background:#286983;}
        """)
        root=QVBoxLayout(self)
        root.setContentsMargins(18,17,18,14)
        heading=QLabel("HELIOS  //  PROTOCOL DESIGNER  /  PATCH 014")
        heading.setObjectName("subtitle")
        root.addWidget(heading)
        root.addWidget(QLabel("NOME DO PROTOCOLO"))
        self.name=QLineEdit(initial["name"] if initial else "")
        self.name.setPlaceholderText("Ex.: Iniciar dia, Preparar Blender, Abrir workspace")
        root.addWidget(self.name)
        self.modes=QTabWidget()
        root.addWidget(self.modes,1)
        self._make_visual()
        self._make_advanced()
        self.modes.currentChanged.connect(self.switch_mode)
        self.info=QLabel("MODO VISUAL  //  Organize as ações, depois salve.")
        self.info.setObjectName("subtitle")
        self.info.setWordWrap(True)
        root.addWidget(self.info)
        actions=QHBoxLayout()
        self.verify=QPushButton("VERIFICAR PROTOCOLO")
        self.verify.clicked.connect(self.check_current)
        actions.addWidget(self.verify)
        actions.addStretch()
        save=QPushButton("SALVAR PROTOCOLO")
        save.clicked.connect(self.finish)
        actions.addWidget(save)
        back=QPushButton("CANCELAR")
        back.clicked.connect(self.reject)
        actions.addWidget(back)
        root.addLayout(actions)
        self._render_visual()

    def _make_visual(self):
        page=QWidget()
        box=QVBoxLayout(page)
        msg=QLabel("ARRASTE AS ETAPAS PARA REORDENAR  //  ESCOLHA A AÇÃO ABAIXO")
        msg.setObjectName("subtitle")
        box.addWidget(msg)
        self.visual_steps=QListWidget()
        self.visual_steps.setDragDropMode(QListWidget.DragDropMode.InternalMove)
        self.visual_steps.setDefaultDropAction(Qt.DropAction.MoveAction)
        # Qt may still be completing the drag when rowsMoved fires; defer the
        # refresh to the next event-loop turn to avoid modifying that model
        # mid-move (which can freeze or crash certain Windows Qt builds).
        self.visual_steps.model().rowsMoved.connect(
            lambda *_: QTimer.singleShot(0, self._sync_visual_order))
        box.addWidget(self.visual_steps,1)
        pick=QHBoxLayout()
        self.action_type=QComboBox()
        for name,kind,idx in self.TYPES:
            self.action_type.addItem(name,(kind,idx))
        self.action_type.currentIndexChanged.connect(self._change_type)
        pick.addWidget(self.action_type,1)
        self.params=QStackedWidget()
        # Folder page
        folder=QWidget()
        fl=QHBoxLayout(folder);fl.setContentsMargins(0,0,0,0)
        self.path=QLineEdit()
        self.path.setPlaceholderText("Pasta absoluta...")
        fl.addWidget(self.path,1)
        browse=QPushButton("PROCURAR")
        browse.clicked.connect(self._browse_folder)
        fl.addWidget(browse)
        self.params.addWidget(folder)
        # Chrome
        self.profiles=QComboBox()
        self.params.addWidget(self.profiles)
        # Catalog
        self.catalogs=QComboBox()
        self.params.addWidget(self.catalogs)
        # Modules
        self.modules=QComboBox()
        self.params.addWidget(self.modules)
        # Wait
        self.seconds=QSpinBox()
        self.seconds.setRange(1,30)
        self.seconds.setValue(2)
        self.seconds.setSuffix(" segundos")
        self.params.addWidget(self.seconds)
        pick.addWidget(self.params,2)
        box.addLayout(pick)
        buttons=QHBoxLayout()
        for title,fn in (
            ("ADICIONAR ETAPA",self.add_step),
            ("DUPLICAR",self.duplicate),
            ("SUBIR",lambda:self.move_step(-1)),
            ("DESCER",lambda:self.move_step(1)),
            ("REMOVER",self.remove_step)
        ):
            control=QPushButton(title);control.clicked.connect(fn)
            buttons.addWidget(control)
        box.addLayout(buttons)
        self.modes.addTab(page,"MODO VISUAL")
        self._change_type(0)

    def _make_advanced(self):
        page=QWidget()
        layout=QVBoxLayout(page)
        layout.addWidget(QLabel(
            "SCRIPT H.D.D.  //  UMA AÇÃO POR LINHA  •  SEM EXECUÇÃO DE CÓDIGO EXTERNO"
        ))
        self.script=QPlainTextEdit()
        self.script.setPlaceholderText(
            '# Exemplo:\nPASTA "C:\\Users\\User\\Documents"\n'
            'CHROME_RESTAURAR "Profile 1"\nESPERAR 2\nMODULO terminal'
        )
        self.script.setTabStopDistance(32)
        self.highlighter=ProtocolHighlighter(self.script.document())
        self.script.textChanged.connect(self._script_edited)
        layout.addWidget(self.script,1)
        self.validation=QLabel("Os scripts são convertidos em etapas visuais ao salvar.")
        self.validation.setObjectName("subtitle")
        self.validation.setWordWrap(True)
        layout.addWidget(self.validation)
        row=QHBoxLayout()
        guide=QPushButton("COMANDOS DISPONÍVEIS")
        guide.clicked.connect(self.show_help)
        row.addWidget(guide)
        check=QPushButton("VALIDAR SCRIPT")
        check.clicked.connect(self.validate_script)
        row.addWidget(check)
        row.addStretch()
        layout.addLayout(row)
        self.modes.addTab(page,"MODO AVANÇADO")
        self._validation_timer=QTimer(self)
        self._validation_timer.setSingleShot(True)
        self._validation_timer.timeout.connect(self.validate_script)

    def _change_type(self,_idx):
        data=self.action_type.currentData()
        if data:
            self.params.setCurrentIndex(data[1])
            if data[1]==1:
                self.profiles.clear()
                for ident,name in chrome_profiles():
                    self.profiles.addItem(name+"  //  "+ident,ident)
            if data[1]==2:
                self.catalogs.clear()
                for item in self.catalog.items:
                    self.catalogs.addItem(item["name"]+"  //  "+item["group"],item["id"])
            if data[1]==3:
                self.modules.clear()
                from hdd.ui.protocol_center import MODULES
                for key,label in MODULES.items():
                    self.modules.addItem(label,key)

    def _browse_folder(self):
        folder=QFileDialog.getExistingDirectory(self,"Selecione uma pasta",str(Path.home()))
        if folder:self.path.setText(folder)

    def _current_step(self):
        kind=self.action_type.currentData()[0]
        if kind=="folder":
            step=dict(kind=kind,path=self.path.text().strip())
            verify_action(step)
            return step
        if kind in ("chrome_profile","chrome_profile_restore"):
            ident=self.profiles.currentData()
            if not ident: raise ValueError("Nenhum perfil Chrome está disponível.")
            step=dict(kind=kind,profile=ident)
            verify_action(step)
            return step
        if kind=="catalog":
            item=self.catalogs.currentData()
            if not item: raise ValueError("Cadastre um aplicativo ou pasta primeiro.")
            return dict(kind=kind,id=item)
        if kind=="module":
            module=self.modules.currentData()
            if not module:raise ValueError("Selecione um módulo.")
            return dict(kind=kind,key=module)
        return dict(kind="wait",seconds=self.seconds.value())

    def _render_visual(self):
        from hdd.ui.protocol_center import label_step
        selected=self.visual_steps.currentRow()
        self._building=True
        self.visual_steps.clear()
        for idx,step in enumerate(self.steps,1):
            source=f"{idx:02d}   {label_step(step,self.catalog)}"
            localized=f"{idx:02d}   {translate_step_label(label_step(step,self.catalog),str(QSettings("HDD-Project","HDD-System").value("interface_language","en-US")))}"
            item=QListWidgetItem(localized)
            item.setData(9995,source)
            item.setData(9996,localized)
            item.setData(Qt.ItemDataRole.UserRole,dict(step))
            self.visual_steps.addItem(item)
        if self.steps:
            self.visual_steps.setCurrentRow(max(0,min(selected,len(self.steps)-1)))
        self._building=False

    def _sync_visual_order(self,*_):
        if self._building:return
        self.steps=[dict(self.visual_steps.item(i).data(Qt.ItemDataRole.UserRole))
                    for i in range(self.visual_steps.count())]
        self._render_visual()

    def add_step(self):
        try:
            from hdd.ui.protocol_center import _steps_valid
            new=self._current_step()
            steps=self.steps+[new]
            _steps_valid(steps)
            self.steps=steps
            self._render_visual()
            self.visual_steps.setCurrentRow(len(self.steps)-1)
            self.info.setText("Etapa adicionada ao Modo Visual.")
        except Exception as exc:
            QMessageBox.warning(self,"Etapa inválida",str(exc))

    def remove_step(self):
        idx=self.visual_steps.currentRow()
        if 0<=idx<len(self.steps):
            self.steps.pop(idx)
            self._render_visual()

    def duplicate(self):
        idx=self.visual_steps.currentRow()
        if 0<=idx<len(self.steps):
            if len(self.steps)>=20:
                QMessageBox.warning(self,"Limite","Máximo de 20 etapas.")
                return
            self.steps.insert(idx+1,dict(self.steps[idx]))
            self._render_visual()
            self.visual_steps.setCurrentRow(idx+1)

    def move_step(self,delta):
        idx=self.visual_steps.currentRow()
        nxt=idx+delta
        if 0<=idx<len(self.steps) and 0<=nxt<len(self.steps):
            self.steps[idx],self.steps[nxt]=self.steps[nxt],self.steps[idx]
            self._render_visual()
            self.visual_steps.setCurrentRow(nxt)

    def _script_edited(self):
        self._validation_timer.start(350)

    def validate_script(self):
        if self.modes.currentIndex()!=1:
            return True
        try:
            from hdd.ui.protocol_center import _steps_valid
            steps=parse_script(self.script.toPlainText(),self.catalog)
            _steps_valid(steps)
            if not steps:raise ValueError("Inclua pelo menos uma ação.")
            self.validation.setText(f"✓  SCRIPT VÁLIDO  //  {len(steps)} ETAPAS")
            self.validation.setStyleSheet("color:#91e7c3")
            return True
        except Exception as exc:
            self.validation.setText("ERRO  //  "+str(exc))
            self.validation.setStyleSheet("color:#ffb8a9")
            return False

    def switch_mode(self,index):
        if index==self._last_mode:
            return
        if index==1:
            self.script.setPlainText(script_text(self.steps))
            self.info.setText("MODO AVANÇADO  //  Edite os comandos; mudanças são validadas.")
            self._last_mode=1
            return
        try:
            from hdd.ui.protocol_center import _steps_valid
            updated=parse_script(self.script.toPlainText(),self.catalog)
            _steps_valid(updated)
            if not updated:raise ValueError("Inclua pelo menos uma ação.")
            self.steps=updated
            self._render_visual()
            self.info.setText("MODO VISUAL  //  Script sincronizado com as etapas.")
            self._last_mode=0
        except Exception as exc:
            with QSignalBlocker(self.modes):
                self.modes.setCurrentIndex(1)
            QMessageBox.warning(self,"Script não pode ser convertido",
                                str(exc)+"\n\nCorrija o script antes de voltar ao modo visual.")

    def check_current(self):
        try:
            from hdd.ui.protocol_center import _steps_valid
            entries=parse_script(self.script.toPlainText(),self.catalog) if self.modes.currentIndex()==1 else self.steps
            _steps_valid(entries)
            if not entries or not self.name.text().strip():
                raise ValueError("Informe um nome e pelo menos uma ação.")
            QMessageBox.information(self,"Protocolo verificado",
                                    f"{len(entries)} etapas válidas. Nenhuma foi executada.")
        except Exception as exc:
            QMessageBox.warning(self,"Revisar protocolo",str(exc))

    def show_help(self):
        QMessageBox.information(self,"Comandos do H.D.D.",
            'PASTA "C:\\Users\\...\\Pasta"\n'
            'CHROME "Profile 1"\n'
            'CHROME_RESTAURAR "Profile 4"\n'
            'ESPERAR 2  (1 a 30)\n'
            'MODULO terminal\n'
            'CATALOGO <ID do item>\n\n'
            "Não executa comandos arbitrários Python, PowerShell ou CMD.")

    def finish(self):
        try:
            from hdd.ui.protocol_center import _steps_valid, _text
            chosen=parse_script(self.script.toPlainText(),self.catalog) if self.modes.currentIndex()==1 else self.steps
            _steps_valid(chosen)
            if not chosen or not self.name.text().strip():
                raise ValueError("Informe o nome e pelo menos uma etapa.")
            self.result_data=(_text(self.name.text(),90),[dict(x) for x in chosen])
            self.accept()
        except Exception as exc:
            QMessageBox.warning(self,"Não foi possível salvar",str(exc))
