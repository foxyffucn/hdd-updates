"""H.D.D. Patch 010 — practical local storage analysis and assisted cleanup.

An opt-in, cancellable filesystem inventory. No automatic deletion, no symlink/
junction traversal, no network access, and duplicate hashes are verified in a
separate explicitly requested step. No added third-party dependencies.
"""
from __future__ import annotations
from hdd.ui.language_bridge import set_localized_text

from collections import defaultdict
import hashlib
import os
from pathlib import Path
import shutil
import stat
import threading
import time

from PySide6.QtCore import Qt, QThread, Signal, QTimer, QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QFileDialog, QFrame, QGridLayout, QHeaderView,
    QHBoxLayout, QLabel, QLineEdit, QMessageBox, QProgressBar, QPushButton,
    QTabWidget, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

MAX_SCAN_FILES = 160_000
MAX_DISPLAY = 350
MIN_DUP_BYTES = 128 * 1024
MAX_DUP_CANDIDATES = 2500
MAX_DUP_FILE_BYTES = 1024 * 1024 * 1024
MAX_DUP_READ_BYTES = 12 * 1024 * 1024 * 1024
MAX_DUP_GROUPS = 120


def human_bytes(n):
    n = float(max(0, n))
    for suffix in ("B", "KiB", "MiB", "GiB", "TiB"):
        if n < 1024.0 or suffix == "TiB":
            return f"{n:.1f} {suffix}" if suffix != "B" else f"{int(n)} B"
        n /= 1024.0


def _reparse(st):
    return bool(getattr(st, "st_file_attributes", 0) &
                getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400))


def _emit_progress(emit, message, stamp):
    now = time.monotonic()
    if now - stamp[0] >= 0.32:
        emit(message)
        stamp[0] = now


def scan_directory(root, stop=None, progress=None):
    """Inventory only, no file-content reads. Not an exact on-disk allocation."""
    root = Path(root).expanduser().resolve(strict=True)
    if not root.is_dir() or root.is_symlink():
        raise ValueError("Selecione uma pasta normal e acessível.")
    stop = stop or threading.Event()
    emit = progress or (lambda message: None)
    top_folders = defaultdict(lambda: [0, 0])
    top_files = []
    temporary = []
    candidates = defaultdict(list)
    file_count = 0
    folder_count = 0
    errors = 0
    bytes_total = 0
    truncated = False
    stack = [root]
    timestamp = [0.]
    while stack:
        if stop.is_set():
            break
        folder = stack.pop()
        try:
            entries = os.scandir(folder)
        except OSError:
            errors += 1
            continue
        with entries:
            for entry in entries:
                if stop.is_set():
                    break
                if file_count >= MAX_SCAN_FILES:
                    truncated = True
                    stack.clear()
                    break
                try:
                    # DirEntry.stat on some Windows/Python builds reports
                    # st_dev/st_ino as zero; os.stat supplies stable file IDs
                    # needed to verify hashes and exclude actual hardlinks.
                    st = os.stat(entry.path, follow_symlinks=False)
                    if stat.S_ISLNK(st.st_mode) or _reparse(st):
                        continue
                    entry_path = Path(entry.path)
                    if stat.S_ISDIR(st.st_mode):
                        folder_count += 1
                        stack.append(entry_path)
                        continue
                    if not stat.S_ISREG(st.st_mode):
                        continue
                    size = max(0, int(st.st_size))
                    signature = (str(entry_path), size, int(st.st_mtime_ns),
                                 int(st.st_dev), int(st.st_ino))
                    file_count += 1
                    bytes_total += size
                    relative = entry_path.relative_to(root)
                    segment = relative.parts[0] if len(relative.parts) > 1 else "(arquivos nesta pasta)"
                    top_folders[segment][0] += size
                    top_folders[segment][1] += 1
                    top_files.append(signature)
                    if entry_path.suffix.lower() in (".tmp", ".temp"):
                        temporary.append(signature)
                    if size >= MIN_DUP_BYTES and size <= MAX_DUP_FILE_BYTES:
                        candidates[size].append(signature)
                    _emit_progress(emit, f"Analisando {file_count:,} arquivos / {folder_count:,} pastas...", timestamp)
                except (OSError, ValueError):
                    errors += 1
    top_files.sort(key=lambda item: item[1], reverse=True)
    temporary.sort(key=lambda item: item[1], reverse=True)
    folders = sorted(top_folders.items(), key=lambda it: it[1][0], reverse=True)
    dupe_candidates = {size: entries for size, entries in candidates.items() if len(entries) > 1}
    return {
        "root": str(root), "bytes": bytes_total, "files": file_count,
        "folders": folder_count, "errors": errors,
        "cancelled": stop.is_set(), "truncated": truncated,
        "folder_rows": [(name, values[0], values[1]) for name, values in folders[:MAX_DISPLAY]],
        "big_rows": top_files[:MAX_DISPLAY],
        "temp_rows": temporary[:MAX_DISPLAY],
        "dupe_candidates": dupe_candidates,
    }


def _hash_file(signature, stop, prefix_only=False):
    path, size, mtime, device, inode = signature
    with open(path, "rb") as file:
        st = os.fstat(file.fileno())
        if (_reparse(st) or not stat.S_ISREG(st.st_mode) or
            st.st_size != size or st.st_mtime_ns != mtime or
            st.st_dev != device or st.st_ino != inode):
            return None
        digest = hashlib.sha256()
        remainder = min(size, 128 * 1024) if prefix_only else size
        while remainder > 0:
            if stop.is_set():
                return None
            block = file.read(min(256 * 1024, remainder))
            if not block:
                return None
            digest.update(block)
            remainder -= len(block)
        return digest.hexdigest()


def find_duplicates(inventory, stop=None, progress=None):
    """Verify same-size files with sample + full SHA-256, never compare by name."""
    stop = stop or threading.Event()
    emit = progress or (lambda message: None)
    source = inventory["dupe_candidates"]
    by_size = sorted(source.items(), key=lambda item: item[0], reverse=True)
    checked = 0
    total_read = 0
    skipped = 0
    groups = []
    stamp = [0.]
    seen_ids = set()
    for size, signatures in by_size:
        if stop.is_set() or checked >= MAX_DUP_CANDIDATES or total_read >= MAX_DUP_READ_BYTES:
            break
        partial = defaultdict(list)
        for signature in signatures:
            if stop.is_set() or checked >= MAX_DUP_CANDIDATES:
                break
            unique = (signature[3], signature[4])
            # Some Windows/virtual filesystems report zero inode for every
            # regular file. Only deduplicate known, nonzero file identities.
            if signature[4] and unique in seen_ids:
                continue  # hardlinks are not reclaimable duplicates
            if signature[4]:
                seen_ids.add(unique)
            checked += 1
            try:
                head = _hash_file(signature, stop, True)
                if head:
                    partial[head].append(signature)
            except OSError:
                skipped += 1
            _emit_progress(emit, f"Conferindo duplicados: {checked:,} candidatos...", stamp)
        for potential in partial.values():
            if stop.is_set():
                break
            if len(potential) < 2:
                continue
            full = defaultdict(list)
            for signature in potential:
                if total_read + signature[1] > MAX_DUP_READ_BYTES:
                    skipped += 1
                    continue
                try:
                    checksum = _hash_file(signature, stop)
                except OSError:
                    skipped += 1
                    continue
                if checksum:
                    total_read += signature[1]
                    full[checksum].append(signature)
            for same in full.values():
                if len(same) > 1:
                    groups.append((size, same))
    groups.sort(key=lambda item: item[0] * (len(item[1])-1), reverse=True)
    return {"groups": groups[:MAX_DUP_GROUPS],
            "checked": checked, "read": total_read,
            "cancelled": stop.is_set(), "skipped": skipped,
            "limited": checked >= MAX_DUP_CANDIDATES or total_read >= MAX_DUP_READ_BYTES}


class AnalysisThread(QThread):
    data_ready = Signal(str, object)
    progress = Signal(str)
    def __init__(self, mode, root=None, inventory=None, parent=None):
        super().__init__(parent)
        self.mode = mode
        self.root = root
        self.inventory = inventory
        self.stop_flag = threading.Event()

    def cancel(self):
        self.stop_flag.set()

    def run(self):
        try:
            if self.mode == "scan":
                result = scan_directory(self.root, self.stop_flag, self.progress.emit)
            else:
                result = find_duplicates(self.inventory, self.stop_flag, self.progress.emit)
            self.data_ready.emit(self.mode, result)
        except Exception as e:
            self.data_ready.emit("error", str(e))


class StorageAnalyzerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("hddStorage")
        self.setWindowTitle("H.D.D. // ANÁLISE DE ARMAZENAMENTO")
        self.resize(1100, 750)
        self.setMinimumSize(810, 610)
        self.current_root = Path.home()
        self.inventory = None
        self.thread = None
        self._closing = False
        self._duplicates = []
        self.setStyleSheet("""
            QDialog#hddStorage {background:#071a2a;}
            QLabel {color:#daf4ff; background:transparent;}
            QLabel#storageTitle {font: 700 27px 'zero 5', 'Segoe UI';}
            QLabel#storageSmall {font: 600 11px Consolas; color:#8ac8db;}
            QFrame#storageCard {background:#0e2a3e; border:1px solid #34677f; border-radius:4px;}
            QTableWidget {background:#071e30; alternate-background-color:#113047;
                color:#dbf6fc; gridline-color:#234962; border:1px solid #3b6f87;
                font: 11px Consolas; selection-background-color:#27627c;}
            QHeaderView::section {background:#13354d; color:#b7eafb;
                border:1px solid #29536b; padding:7px;}
            QPushButton {background:#17445d; color:#daf5fc; border:1px solid #46839d;
                border-radius:3px; padding:9px; font:600 11px 'Segoe UI';}
            QPushButton:hover {background:#255e79;}
            QPushButton:disabled {color:#7596a7; background:#133043; border-color:#26495b;}
            QLineEdit {background:#061b2c; color:#f3fdff; border:1px solid #396d85;
                padding:9px; font:11px Consolas;}
            QTabWidget::pane {border:1px solid #356985;}
            QTabBar::tab {background:#0e3247; color:#9fcee0; padding:10px 18px;}
            QTabBar::tab:selected {background:#25617c; color:white;}
            QProgressBar {border:1px solid #34657f; background:#061929; height:12px;}
            QProgressBar::chunk {background:#8de6f8;}
        """)
        main = QVBoxLayout(self)
        main.setContentsMargins(18, 16, 18, 16)
        main.setSpacing(10)
        title = QLabel("ANÁLISE DE ARMAZENAMENTO")
        title.setObjectName("storageTitle")
        main.addWidget(title)
        desc=QLabel("HELIOS // DISK OPERATIONS  /  INVENTÁRIO LOCAL — NENHUMA LIMPEZA AUTOMÁTICA")
        desc.setObjectName("storageSmall")
        main.addWidget(desc)
        loc=QHBoxLayout()
        self.location=QLineEdit(str(self.current_root))
        self.location.setReadOnly(True)
        loc.addWidget(self.location,1)
        choose=QPushButton("ESCOLHER PASTA")
        choose.clicked.connect(self.choose_folder)
        loc.addWidget(choose)
        self.scan_button=QPushButton("ANALISAR")
        self.scan_button.clicked.connect(self.begin_scan)
        loc.addWidget(self.scan_button)
        self.cancel_button=QPushButton("CANCELAR")
        self.cancel_button.clicked.connect(self.cancel_scan)
        self.cancel_button.setEnabled(False)
        loc.addWidget(self.cancel_button)
        main.addLayout(loc)
        cards=QGridLayout()
        self.stats={}
        for idx, (key, label) in enumerate((
            ("drive","UNIDADE LOCAL"), ("folder","TAMANHO ANALISADO"),
            ("count","ITENS ANALISADOS"), ("duplicates","DUPLICADOS VERIFICADOS")
        )):
            frame=QFrame();frame.setObjectName("storageCard")
            stack=QVBoxLayout(frame)
            caption=QLabel(label);caption.setObjectName("storageSmall");stack.addWidget(caption)
            value=QLabel("—")
            value.setStyleSheet("font:700 19px Consolas; color:#ecfbff;")
            value.setWordWrap(True)
            stack.addWidget(value)
            self.stats[key]=value
            cards.addWidget(frame,idx//2,idx%2)
        main.addLayout(cards)
        self.tabs=QTabWidget()
        self.tables={}
        columns=(
            ("folder",["PASTA", "TAMANHO", "ARQUIVOS"]),
            ("big",["ARQUIVO GRANDE", "TAMANHO", "MODIFICADO"]),
            ("dup",["ARQUIVO DUPLICADO", "TAMANHO", "GRUPO"]),
            ("temp",["POSSÍVEL TEMPORÁRIO", "TAMANHO", "MODIFICADO"]),
        )
        for key,headings in columns:
            table=QTableWidget(0,len(headings))
            table.setHorizontalHeaderLabels(headings)
            table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
            table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
            table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
            table.setAlternatingRowColors(True)
            table.verticalHeader().hide()
            table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
            for n in range(1,len(headings)):
                table.horizontalHeader().setSectionResizeMode(n,QHeaderView.ResizeMode.ResizeToContents)
            self.tabs.addTab(table,{"folder":"PASTAS","big":"ARQUIVOS GRANDES",
                                    "dup":"DUPLICADOS","temp":"TEMPORÁRIOS"}[key])
            self.tables[key]=table
        main.addWidget(self.tabs,1)
        lower=QHBoxLayout()
        self.duplicate_button=QPushButton("VERIFICAR DUPLICADOS")
        self.duplicate_button.setEnabled(False)
        self.duplicate_button.clicked.connect(self.begin_duplicates)
        lower.addWidget(self.duplicate_button)
        self.open_button=QPushButton("ABRIR LOCAL DO ITEM")
        self.open_button.clicked.connect(self.open_selected)
        lower.addWidget(self.open_button)
        self.recycle_button=QPushButton("ENVIAR ARQUIVO À LIXEIRA")
        self.recycle_button.clicked.connect(self.recycle_selected)
        lower.addWidget(self.recycle_button)
        back=QPushButton("VOLTAR")
        back.clicked.connect(self.close)
        lower.addWidget(back)
        main.addLayout(lower)
        self.progressbar=QProgressBar()
        self.progressbar.setTextVisible(False)
        self.progressbar.setRange(0,1)
        self.progressbar.setValue(0)
        main.addWidget(self.progressbar)
        self.status=QLabel("Selecione uma pasta e clique em ANALISAR. Leitura limitada a 160 mil arquivos.")
        self.status.setObjectName("storageSmall")
        self.status.setWordWrap(True)
        main.addWidget(self.status)
        self._update_drive()

    def _update_drive(self):
        try:
            d=shutil.disk_usage(self.current_root)
            self.stats["drive"].setText(
                f"{human_bytes(d.used)} / {human_bytes(d.total)}"
            )
        except OSError:
            self.stats["drive"].setText("Unidade indisponível")

    def choose_folder(self):
        if self.thread is not None:
            return
        folder=QFileDialog.getExistingDirectory(self,"Escolher pasta para analisar",str(self.current_root))
        if folder:
            self.current_root=Path(folder)
            self.location.setText(str(self.current_root))
            self.inventory=None
            self._clear_tables()
            self.duplicate_button.setEnabled(False)
            self._update_drive()

    def _clear_tables(self):
        for table in self.tables.values():
            table.setRowCount(0)
        self.stats["folder"].setText("—")
        self.stats["count"].setText("—")
        self.stats["duplicates"].setText("—")
        self._duplicates=[]

    def _start_worker(self, mode):
        if self.thread is not None or self._closing:
            return
        self.scan_button.setEnabled(False)
        self.duplicate_button.setEnabled(False)
        self.cancel_button.setEnabled(True)
        self.progressbar.setRange(0,0)
        worker=AnalysisThread(mode,str(self.current_root),self.inventory,self)
        self.thread=worker
        worker.progress.connect(self.status.setText)
        worker.data_ready.connect(self._result)
        worker.finished.connect(lambda w=worker: self._thread_done(w))
        worker.start()

    def begin_scan(self):
        if self.thread is not None:
            return
        self.inventory=None
        self._clear_tables()
        set_localized_text(self.status,"Análise iniciada. Arquivos não serão alterados.")
        self._start_worker("scan")

    def begin_duplicates(self):
        if self.inventory is None or self.thread is not None:
            return
        set_localized_text(self.status,"Comparando arquivos do mesmo tamanho por SHA-256. Aguarde...")
        self._start_worker("duplicates")

    def cancel_scan(self):
        if self.thread is not None:
            self.thread.cancel()
            set_localized_text(self.status,"Interrompendo análise, aguarde...")

    def _result(self, mode, payload):
        if self._closing:
            return
        if mode == "error":
            set_localized_text(self.status,"Erro na análise: " + str(payload)[:400])
        elif mode == "scan":
            self.inventory=payload
            self._render_scan(payload)
        else:
            self._render_duplicates(payload)

    def _thread_done(self, worker):
        if self.thread is worker:
            self.thread=None
        worker.deleteLater()
        if self._closing:
            self._closing=False
            QTimer.singleShot(0,self.reject)
            return
        self.scan_button.setEnabled(True)
        self.duplicate_button.setEnabled(self.inventory is not None)
        self.cancel_button.setEnabled(False)
        self.progressbar.setRange(0,1)
        self.progressbar.setValue(1)

    def _render_scan(self, data):
        self.stats["folder"].setText(human_bytes(data["bytes"]))
        self.stats["count"].setText(f'{data["files"]:,} arquivos / {data["folders"]:,} pastas')
        for name, size, count in data["folder_rows"]:
            full=self.current_root/name if name!="(arquivos nesta pasta)" else self.current_root
            self._add("folder", (name,human_bytes(size),str(count)),str(full))
        for key,field in (("big","big_rows"),("temp","temp_rows")):
            for entry in data[field]:
                path,size,mtime,device,inode=entry
                date=time.strftime("%d/%m/%Y %H:%M",time.localtime(mtime / 1e9))
                self._add(key,(path,human_bytes(size),date),entry)
        notice=("Análise interrompida." if data["cancelled"] else
                "Limite de 160 mil arquivos atingido: resultado parcial." if data["truncated"] else
                "Análise concluída.")
        set_localized_text(self.status,
            f'{notice} {data["files"]:,} arquivos; {data["errors"]:,} itens inacessíveis. '
            "Tamanhos são aproximados; duplicados requerem verificação separada."
        )
        self.tabs.setCurrentIndex(0)

    def _render_duplicates(self, data):
        self.tables["dup"].setRowCount(0)
        self._duplicates=data["groups"]
        redundant=0
        for i,(size,entries) in enumerate(data["groups"]):
            redundant+=size*(len(entries)-1)
            for entry in entries:
                self._add("dup",(entry[0],human_bytes(size),f"GRUPO {i+1}"),entry)
        self.stats["duplicates"].setText(
            f'{len(data["groups"])} grupo(s) / até {human_bytes(redundant)}'
        )
        set_localized_text(self.status,
            f'Comparados {data["checked"]:,} candidatos por conteúdo. '
            f'Leitura: {human_bytes(data["read"])}. '
            + ("Análise parcial/cancelada. " if data["limited"] or data["cancelled"] else "")
            + "Revise antes de apagar: nomes iguais não garantem que sejam descartáveis."
        )
        self.tabs.setCurrentIndex(2)

    def _add(self,key,columns,data):
        table=self.tables[key]
        row=table.rowCount()
        if row >= MAX_DISPLAY:
            return
        table.insertRow(row)
        for i,value in enumerate(columns):
            cell=QTableWidgetItem(str(value))
            cell.setFlags(cell.flags() & ~Qt.ItemFlag.ItemIsEditable)
            if i==0:
                cell.setData(Qt.ItemDataRole.UserRole,data)
            table.setItem(row,i,cell)

    def _selected(self):
        key=("folder","big","dup","temp")[self.tabs.currentIndex()]
        table=self.tables[key]
        row=table.currentRow()
        if row<0:
            return None
        item=table.item(row,0)
        if item is None:
            return None
        return key,item.data(Qt.ItemDataRole.UserRole)

    def open_selected(self):
        selected=self._selected()
        if selected is None:
            set_localized_text(self.status,"Selecione um arquivo ou pasta na lista.")
            return
        key,info=selected
        path=Path(info if key=="folder" else info[0])
        parent=path if key=="folder" and path.is_dir() else path.parent
        if parent.is_dir():
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(parent)))
        else:
            set_localized_text(self.status,"Essa pasta não está mais disponível.")

    def recycle_selected(self):
        selected=self._selected()
        if selected is None:
            set_localized_text(self.status,"Selecione um arquivo primeiro.")
            return
        key,record=selected
        if key=="folder":
            QMessageBox.information(self,"Limpeza segura",
                                    "Pastas não são apagadas pelo analisador. Use o Explorador para revisá-las.")
            return
        if self.thread is not None:
            set_localized_text(self.status,"Aguarde o fim da análise para modificar arquivos.")
            return
        path,size,mtime,device,inode=record
        target=Path(path)
        root=self.current_root.resolve()
        try:
            real=target.resolve(strict=True)
            st=target.stat(follow_symlinks=False)
            if (not real.is_relative_to(root) or not stat.S_ISREG(st.st_mode)
                or _reparse(st) or target.is_symlink()):
                raise ValueError("O arquivo não é seguro para esta operação.")
            if ((st.st_size,st.st_mtime_ns,st.st_dev,st.st_ino)
                != (size,mtime,device,inode)):
                raise ValueError("Este arquivo mudou desde a análise. Analise novamente.")
            # Never propose deleting system executables or H.D.D. source via this UI.
            blocked=[Path(os.environ.get("WINDIR","C:\\Windows")),
                     Path(os.environ.get("ProgramFiles","C:\\Program Files")),
                     Path(os.environ.get("ProgramFiles(x86)","C:\\Program Files (x86)"))]
            from hdd.paths import project_root
            blocked.append(Path(project_root()))
            if any(real.is_relative_to(p.resolve()) for p in blocked if p.exists()):
                raise ValueError("Arquivos do sistema e do projeto H.D.D. estão protegidos.")
            if target.suffix.lower() in (".exe",".dll",".sys",".bat",".ps1",".cmd"):
                raise ValueError("Executáveis e scripts não podem ser apagados pelo analisador.")
        except (OSError,ValueError) as exc:
            QMessageBox.warning(self,"Operação protegida",str(exc))
            return
        question=("Enviar ESTE arquivo à Lixeira do Windows?\n\n"
                  f"{target}\nTamanho: {human_bytes(size)}\n\n"
                  "O H.D.D. não apagará outros arquivos da lista. "
                  "Confira se este arquivo não é importante.")
        if QMessageBox.question(self,"Confirmar limpeza assistida",question,
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.No) != QMessageBox.StandardButton.Yes:
            return
        try:
            from hdd.ui.file_explorer import _recycle_windows
            _recycle_windows(real)
            set_localized_text(self.status,"Enviado à Lixeira. Analise novamente para atualizar a lista.")
            self.scan_button.setEnabled(True)
            self.duplicate_button.setEnabled(False)
            self.inventory=None
        except Exception as exc:
            QMessageBox.warning(self,"Não foi possível enviar à Lixeira",str(exc))

    def closeEvent(self,event):
        if self.thread is not None and self.thread.isRunning():
            if not self._closing:
                self._closing=True
                self.thread.cancel()
            self.hide()
            event.ignore()
            return
        super().closeEvent(event)
