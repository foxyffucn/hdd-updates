"""H.D.D. Patch 008 — local Windows performance monitor (read-only).

No extra dependencies, external services or process termination operations.
Fast metrics are native Windows APIs. A separate Qt thread gathers tasklist
and optional NVIDIA telemetry so the GUI does not freeze.
"""
from __future__ import annotations
from hdd.ui.language_bridge import set_localized_text

from collections import deque
import csv
import ctypes
from ctypes import wintypes
import io
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

from PySide6.QtCore import Qt, QPointF, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPainterPath, QPen, QLinearGradient, QFont
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QGridLayout, QHBoxLayout, QHeaderView,
    QLabel, QLineEdit, QPushButton, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget, QFrame,
)

WINDOWS = os.name == "nt"
CREATE_NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

if WINDOWS:
    class FILETIME(ctypes.Structure):
        _fields_ = [("low", wintypes.DWORD), ("high", wintypes.DWORD)]

    class MEMORYSTATUSEX(ctypes.Structure):
        _fields_ = [
            ("dwLength", wintypes.DWORD),
            ("dwMemoryLoad", wintypes.DWORD),
            ("ullTotalPhys", ctypes.c_ulonglong),
            ("ullAvailPhys", ctypes.c_ulonglong),
            ("ullTotalPageFile", ctypes.c_ulonglong),
            ("ullAvailPageFile", ctypes.c_ulonglong),
            ("ullTotalVirtual", ctypes.c_ulonglong),
            ("ullAvailVirtual", ctypes.c_ulonglong),
            ("ullAvailExtendedVirtual", ctypes.c_ulonglong),
        ]


def _filetime(value):
    return (int(value.high) << 32) | int(value.low)


def bytes_gib(value):
    return f"{value / 1073741824:.1f} GiB"


class WindowsSample:
    def __init__(self):
        self._last_times = None

    def sample(self):
        result = {"cpu": None, "ram": None, "ram_used": None, "ram_total": None,
                  "disk": None, "disk_used": None, "disk_total": None}
        if WINDOWS:
            idle, kernel, user = FILETIME(), FILETIME(), FILETIME()
            k32 = ctypes.windll.kernel32
            k32.GetSystemTimes.argtypes = (
                ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME), ctypes.POINTER(FILETIME))
            k32.GetSystemTimes.restype = wintypes.BOOL
            if k32.GetSystemTimes(ctypes.byref(idle), ctypes.byref(kernel), ctypes.byref(user)):
                now = (_filetime(idle), _filetime(kernel), _filetime(user))
                if self._last_times:
                    di = now[0] - self._last_times[0]
                    dk = now[1] - self._last_times[1]
                    du = now[2] - self._last_times[2]
                    total = dk + du
                    if total > 0:
                        result["cpu"] = max(0., min(100., 100. * (1. - di / total)))
                self._last_times = now
            info = MEMORYSTATUSEX()
            info.dwLength = ctypes.sizeof(MEMORYSTATUSEX)
            k32.GlobalMemoryStatusEx.argtypes = [ctypes.POINTER(MEMORYSTATUSEX)]
            k32.GlobalMemoryStatusEx.restype = wintypes.BOOL
            if k32.GlobalMemoryStatusEx(ctypes.byref(info)) and info.ullTotalPhys:
                used = info.ullTotalPhys - info.ullAvailPhys
                result.update(ram=used * 100. / info.ullTotalPhys,
                              ram_used=used, ram_total=info.ullTotalPhys)
        try:
            drive = os.environ.get("SystemDrive", "C:") + "\\" if WINDOWS else "/"
            total, used, free = shutil.disk_usage(drive)
            if total:
                result.update(disk=used * 100. / total,
                              disk_used=used, disk_total=total)
        except (OSError, ValueError):
            pass
        return result


class Sparkline(QWidget):
    """A lightweight antialiased history graph, range 0–100%."""
    def __init__(self, hue="#7ce2f4", parent=None):
        super().__init__(parent)
        self.values = deque(maxlen=75)
        self.hue = QColor(hue)
        self.setMinimumHeight(76)

    def add_value(self, value):
        if value is not None:
            self.values.append(float(max(0, min(100, value))))
            self.update()

    def paintEvent(self, event):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        if w <= 8 or h <= 8:
            return
        p.fillRect(self.rect(), QColor("#071a2b"))
        p.setPen(QPen(QColor(66, 120, 148, 70), 1))
        for fraction in (.25, .5, .75):
            y = int((h - 9) * fraction)
            p.drawLine(0, y, w, y)
        if len(self.values) < 2:
            return
        vals = list(self.values)
        path = QPainterPath()
        x0 = 7.
        x_span = max(1., w - 15.)
        y_span = max(1., h - 18.)
        def point(i, v):
            return QPointF(x0 + x_span * i / max(1, len(vals)-1),
                           7. + y_span * (1.- v/100.))
        path.moveTo(point(0, vals[0]))
        for i,v in enumerate(vals[1:], 1):
            path.lineTo(point(i,v))
        under = QPainterPath(path)
        under.lineTo(point(len(vals)-1, 0))
        under.lineTo(point(0, 0))
        under.closeSubpath()
        gradient = QLinearGradient(0, 0, 0, h)
        top = QColor(self.hue)
        top.setAlpha(70)
        bottom = QColor(self.hue)
        bottom.setAlpha(4)
        gradient.setColorAt(0, top)
        gradient.setColorAt(1, bottom)
        p.fillPath(under, gradient)
        p.setPen(QPen(self.hue, 2))
        p.drawPath(path)


def _command(args, timeout=5):
    return subprocess.run(args, capture_output=True, timeout=timeout, check=False,
                          creationflags=CREATE_NO_WINDOW).stdout


class ProcessWorker(QThread):
    data_ready = Signal(object)
    def run(self):
        output = {"processes": [], "gpu": None, "gpu_name": "Sensor não disponível"}
        if WINDOWS:
            try:
                raw = _command(["tasklist.exe", "/FO", "CSV", "/NH"], timeout=7)
                text = raw.decode("mbcs", errors="replace")
                for row in csv.reader(io.StringIO(text)):
                    if len(row) < 5:
                        continue
                    try:
                        pid = int(row[1])
                    except ValueError:
                        continue
                    numbers = re.sub(r"[^0-9]", "", row[4])
                    memory_mb = int(numbers) / 1024.0 if numbers else 0.
                    output["processes"].append((row[0], pid, memory_mb, row[2]))
                output["processes"].sort(key=lambda x: x[2], reverse=True)
            except (OSError, subprocess.TimeoutExpired):
                pass
            try:
                nv = shutil.which("nvidia-smi")
                if not nv:
                    path=Path(os.environ.get("ProgramFiles", "C:\\Program Files")) / "NVIDIA Corporation" / "NVSMI" / "nvidia-smi.exe"
                    if path.is_file():
                        nv=str(path)
                if nv:
                    raw = _command([nv, "--query-gpu=name,utilization.gpu,memory.used,memory.total,temperature.gpu",
                                    "--format=csv,noheader,nounits"], timeout=4)
                    line = raw.decode("utf-8", errors="replace").splitlines()
                    if line:
                        parts=[x.strip() for x in line[0].split(",")]
                        if len(parts) >= 5:
                            output["gpu_name"]=parts[0]
                            output["gpu"]=float(parts[1])
                            output["gpu_used"]=parts[2]
                            output["gpu_total"]=parts[3]
                            output["gpu_temp"]=parts[4]
            except (OSError, ValueError, subprocess.TimeoutExpired):
                pass
            if output["gpu"] is None:
                # Show model even when Windows/driver exposes no utilization data.
                try:
                    powershell = shutil.which("powershell.exe") or "powershell.exe"
                    raw = _command([powershell, "-NoProfile", "-NonInteractive",
                        "-Command", "(Get-CimInstance Win32_VideoController | Select-Object -ExpandProperty Name) -join '; '"], timeout=6)
                    model = raw.decode("utf-8", errors="replace").strip()
                    if model:
                        output["gpu_name"] = model[:110]
                except (OSError, subprocess.TimeoutExpired):
                    pass
        self.data_ready.emit(output)


class SystemMonitorDialog(QDialog):
    """Read-only system monitoring, refreshed without blocking the UI."""
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("H.D.D. // MONITOR DO SISTEMA")
        self.setMinimumSize(790, 630)
        self.resize(1080, 760)
        self.setObjectName("hddSystemMonitor")
        self.setStyleSheet("""
        QDialog#hddSystemMonitor {background: #061625;}
        QLabel {color: #e2f9ff; background: transparent;}
        QLabel#monitorHeading {font: 700 27px 'zero 5', 'Segoe UI';}
        QLabel#monitorSmall {font: 600 11px 'Consolas'; color: #8accdf;}
        QLabel#monitorValue {font: 700 26px 'Consolas'; color: #dbfaff;}
        QFrame#monitorPanel {background: #0d283b; border: 1px solid #2c6480; border-radius: 5px;}
        QTableWidget {background: #071d30; color: #d5f4ff; gridline-color: #254a63;
            alternate-background-color: #102b41; border: 1px solid #285976;
            font: 12px 'Consolas'; selection-background-color: #235875;}
        QHeaderView::section {background: #12374e; color: #bce9f6;
            padding: 7px; border: 1px solid #214e66; font: 600 11px 'Consolas';}
        QLineEdit {background: #071d30; color: #e8faff; border: 1px solid #3c7490;
            padding: 7px 12px; font: 12px 'Consolas';}
        QPushButton {background: #153e59; color: #d4f6ff; border: 1px solid #397b99;
            border-radius: 3px; padding: 8px 13px; font: 600 12px 'Segoe UI';}
        QPushButton:hover {background: #216487;}
        """)
        self.sampler=WindowsSample()
        self.worker=None
        self._processes=[]
        self._last_poll=0.
        self._closing=False
        self._network_window=None
        self._network_close_pending=False
        root=QVBoxLayout(self)
        root.setContentsMargins(20,17,20,15)
        root.setSpacing(10)
        header=QHBoxLayout()
        title=QLabel("MONITOR DO SISTEMA")
        title.setObjectName("monitorHeading")
        header.addWidget(title)
        header.addStretch(1)
        status=QLabel("LEITURAS LOCAIS  //  SEM CONTROLE DE PROCESSOS")
        status.setObjectName("monitorSmall")
        header.addWidget(status)
        root.addLayout(header)
        grid=QGridLayout()
        grid.setSpacing(9)
        self.values={}
        self.charts={}
        for i,(key,caption,hue) in enumerate((
            ("cpu","PROCESSADOR","#a9ecff"),
            ("ram","MEMÓRIA RAM","#75d6f1"),
            ("gpu","PLACA DE VÍDEO","#a4cbff"),
            ("disk","ARMAZENAMENTO","#89e7cc"),
        )):
            panel=QFrame()
            panel.setObjectName("monitorPanel")
            layout=QVBoxLayout(panel)
            layout.setContentsMargins(13,9,13,10)
            layout.setSpacing(5)
            label=QLabel(caption)
            label.setObjectName("monitorSmall")
            layout.addWidget(label)
            value=QLabel("Aguardando leitura..." if key!="gpu" else "Verificando sensores...")
            value.setObjectName("monitorValue")
            layout.addWidget(value)
            extra=QLabel("")
            extra.setObjectName("monitorSmall")
            extra.setWordWrap(True)
            layout.addWidget(extra)
            chart=Sparkline(hue)
            layout.addWidget(chart)
            grid.addWidget(panel, i//2, i%2)
            self.values[key]=(value,extra)
            self.charts[key]=chart
        root.addLayout(grid)
        process_label=QHBoxLayout()
        process_label.addWidget(QLabel("PROCESSOS ATIVOS  //  MAIOR USO DE MEMÓRIA"))
        process_label.addStretch()
        self.search=QLineEdit()
        self.search.setPlaceholderText("Pesquisar processo ou PID...")
        self.search.setMaximumWidth(275)
        self.search.textChanged.connect(self.show_processes)
        process_label.addWidget(self.search)
        root.addLayout(process_label)
        self.table=QTableWidget(0,4)
        self.table.setHorizontalHeaderLabels(["PROCESSO", "PID", "RAM (MB)", "SESSÃO"])
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.verticalHeader().hide()
        self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(1,QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(2,QHeaderView.ResizeMode.ResizeToContents)
        self.table.horizontalHeader().setSectionResizeMode(3,QHeaderView.ResizeMode.ResizeToContents)
        self.table.setSortingEnabled(True)
        root.addWidget(self.table,1)
        buttons=QHBoxLayout()
        self.note=QLabel("Atualização automática: 1 s (gráficos) / 5 s (processos).")
        self.note.setObjectName("monitorSmall")
        buttons.addWidget(self.note)
        buttons.addStretch()
        network=QPushButton("REDE E CONEXÕES  ↗")
        network.clicked.connect(self.open_network)
        buttons.addWidget(network)
        refresh=QPushButton("ATUALIZAR AGORA")
        refresh.clicked.connect(self.refresh_processes)
        buttons.addWidget(refresh)
        close=QPushButton("VOLTAR")
        close.clicked.connect(self.close)
        buttons.addWidget(close)
        root.addLayout(buttons)
        self.timer=QTimer(self)
        self.timer.timeout.connect(self.update_sample)
        self.timer.start(1000)
        self.update_sample()
        self.refresh_processes()

    def update_sample(self):
        record=self.sampler.sample()
        for key in ("cpu","ram","disk"):
            v=record[key]
            self.charts[key].add_value(v)
            self.values[key][0].setText("Aguardando..." if v is None and key=="cpu"
                                        else "N/D" if v is None else f"{v:.1f}%")
        set_localized_text(self.values["ram"][1],
            f"{bytes_gib(record['ram_used'])} / {bytes_gib(record['ram_total'])}"
            if record["ram_total"] is not None else "Leitura não suportada")
        set_localized_text(self.values["disk"][1],
            f"{bytes_gib(record['disk_used'])} / {bytes_gib(record['disk_total'])}  •  Unidade do sistema"
            if record["disk_total"] is not None else "Unidade não disponível")
        set_localized_text(self.values["cpu"][1],"Utilização total do processador")
        if time.monotonic() - self._last_poll >= 5.:
            self.refresh_processes()

    def refresh_processes(self):
        if self._closing:
            return
        if self.worker is not None and self.worker.isRunning():
            return
        self._last_poll=time.monotonic()
        worker=ProcessWorker(self)
        self.worker=worker
        worker.data_ready.connect(self.receive_process_data)
        worker.start()

    def receive_process_data(self, payload):
        if self._closing:
            return
        self._processes=payload["processes"]
        self.show_processes()
        gpu=payload.get("gpu")
        if gpu is None:
            self.values["gpu"][0].setText("N/D")
            set_localized_text(self.values["gpu"][1],payload["gpu_name"] + " • utilização não disponível")
        else:
            gpu=max(0.,min(100.,float(gpu)))
            self.values["gpu"][0].setText(f"{gpu:.1f}%")
            set_localized_text(self.values["gpu"][1],
                f"{payload['gpu_name']}  |  VRAM {payload['gpu_used']}/{payload['gpu_total']} MiB  |  {payload['gpu_temp']} °C")
            self.charts["gpu"].add_value(gpu)
        set_localized_text(self.note,f"Processos listados: {len(self._processes)} • Leitura local e somente leitura")

    def show_processes(self):
        term=self.search.text().casefold().strip()
        selected=[p for p in self._processes if term in p[0].casefold() or term in str(p[1])]
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(selected))
        for i,(name,pid,mem,session) in enumerate(selected):
            for col,value in enumerate((name,str(pid),f"{mem:.1f}",session)):
                item=QTableWidgetItem(value)
                item.setFlags(item.flags() & ~Qt.ItemFlag.ItemIsEditable)
                if col in (1,2):
                    item.setData(Qt.ItemDataRole.UserRole, pid if col==1 else mem)
                self.table.setItem(i,col,item)
        # Incoming process rows were already sorted numerically by RAM.
        # Keep Qt sorting disabled: reordering half-built QTableWidget rows
        # can crash on some older PySide6/Windows graphics configurations.
        self.table.setSortingEnabled(False)

    def open_network(self):
        from hdd.ui.network_center import NetworkCenterDialog
        panel=self._network_window
        if panel is not None:
            if panel.isVisible():
                panel.raise_()
                panel.activateWindow()
            return panel
        panel=NetworkCenterDialog(self)
        panel.setWindowModality(Qt.WindowModality.NonModal)
        self._network_window=panel
        panel.finished.connect(lambda _result,item=panel:self._forget_network(item))
        panel.show()
        return panel

    def _forget_network(self,panel):
        if self._network_window is panel:
            self._network_window=None
        panel.deleteLater()

    def _resume_close_after_network(self,*_):
        if self._network_close_pending:
            self._network_close_pending=False
            QTimer.singleShot(0,self.close)

    def closeEvent(self,event):
        if self._network_window is not None:
            other=self._network_window
            other.close()
            if other.isVisible() or other._closing:
                if not self._network_close_pending:
                    self._network_close_pending=True
                    other.finished.connect(self._resume_close_after_network)
                event.ignore()
                return
        self.timer.stop()
        if self.worker is not None and self.worker.isRunning():
            # Don't block Qt's main thread for up to eight seconds while
            # tasklist/CIM is being collected. Hide now and finish later.
            if not self._closing:
                self._closing=True
                self.worker.finished.connect(self._finish_deferred_close)
            self.hide()
            event.ignore()
            return
        super().closeEvent(event)

    def _finish_deferred_close(self):
        if self._closing:
            self._closing=False
            # reject() emits QDialog.finished even when hide() was used.
            # A second close() of an already hidden dialog did not do that.
            QTimer.singleShot(0,self.reject)
