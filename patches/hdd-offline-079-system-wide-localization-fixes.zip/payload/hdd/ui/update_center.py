"""Windowed Update Center inside the H.D.D. bottom-dock dashboard."""
from __future__ import annotations
from pathlib import Path
import json

from PySide6.QtCore import Qt, QTimer, QSettings, QThread, Signal
from PySide6.QtWidgets import (QApplication, QDialog, QFileDialog, QFrame,
    QHBoxLayout, QLabel, QMessageBox, QPlainTextEdit, QPushButton, QVBoxLayout,
    QLineEdit, QCheckBox)
from hdd.paths import project_root
from hdd.ui.language_bridge import painted_ui_text
from hdd.ui.remote_updates import check_feed, download_verified_patch, https_url
from hdd.updating.manager import (inspect_package, installed_patches,
                                  last_report, queue_worker)


class RemotePatchWorker(QThread):
    delivered=Signal(bool,object)
    def __init__(self,kind,feed_url,root,patch_info=None,parent=None):
        super().__init__(parent)
        self.kind=kind
        self.feed_url=feed_url
        self.root=root
        self.patch_info=patch_info
    def run(self):
        try:
            result=(check_feed(self.feed_url,self.root) if self.kind=="check"
                    else download_verified_patch(self.patch_info,self.root))
            self.delivered.emit(True,result)
        except Exception as exc:
            self.delivered.emit(False,str(exc)[:250])


class UpdateCenterDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setWindowTitle('H.D.D. // CENTRAL DE ATUALIZAÇÕES')
        self.setObjectName('hddUpdateCenter')
        self.setMinimumSize(740,630)
        self.resize(830,710)
        self.root=Path(project_root())
        self.package=None
        self.selection=None
        self.settings=QSettings("HDD-Project","HDD-System")
        self.remote_info=None
        self.remote_worker=None
        self.remote_auto=False
        self._download_after_check=False
        self._install_after_download=False
        self._install_when_worker_finishes=False
        self.setStyleSheet('''
        QDialog#hddUpdateCenter {background: #071c2c;}
        QLabel {color: #d8f4ff; background: transparent;}
        QLabel#updateHead {font: 800 27px 'zero 5', 'Segoe UI';}
        QLabel#updateSmall {color: #95d0e3; font: 600 10px 'Consolas';}
        QFrame#updatePanel {background: #0e2b40; border: 1px solid #34657c; border-radius: 5px;}
        QPlainTextEdit {color: #bddde9; background: #061827; border: 1px solid #285471;
                         font: 11px 'Consolas'; padding: 9px;}
        QPushButton {color: #d3f4fc; background: #123a54; border: 1px solid #3a7895;
                     padding: 10px; border-radius: 3px; font: 700 11px 'Segoe UI';}
        QPushButton:hover {background: #245877;}
        QPushButton:disabled {color: #6b91a1; background: #102d41;}
        QPushButton#install {background: #9adff2; color: #092535; border-color: #c5f4ff;}
        QLineEdit {color:#ecfaff;background:#0a2a40;border:1px solid #477991;
                   border-radius:3px;padding:8px;}
        QCheckBox {color:#bbebf7;background:transparent;}
        ''')
        root=QVBoxLayout(self)
        root.setContentsMargins(23,21,23,19)
        root.setSpacing(12)
        main_title=QLabel('CENTRAL DE ATUALIZAÇÕES')
        main_title.setObjectName('updateHead')
        root.addWidget(main_title)
        sub=QLabel('HELIOS   //   PATCH CONTROL   /   LOCAL')
        sub.setObjectName('updateSmall')
        root.addWidget(sub)

        frame=QFrame()
        frame.setObjectName('updatePanel')
        body=QVBoxLayout(frame)
        body.setContentsMargins(16,15,16,14)
        body.setSpacing(9)
        self.summary=QLabel('Nenhum pacote selecionado.')
        self.summary.setWordWrap(True)
        body.addWidget(self.summary)
        self.details=QPlainTextEdit()
        self.details.setReadOnly(True)
        self.details.setObjectName("hddUpdateHistory")
        self.details.setMinimumHeight(145)
        body.addWidget(self.details)
        root.addWidget(frame,1)

        actions=QHBoxLayout()
        choose=QPushButton('SELECIONAR PATCH ZIP')
        choose.clicked.connect(self.choose_file)
        actions.addWidget(choose,2)
        self.install=QPushButton('INSTALAR E REINICIAR')
        self.install.setObjectName('install')
        self.install.setEnabled(False)
        self.install.clicked.connect(self.install_patch)
        actions.addWidget(self.install,3)
        root.addLayout(actions)

        second=QHBoxLayout()
        self.undo=QPushButton('REVERTER ÚLTIMA ATUALIZAÇÃO')
        self.undo.clicked.connect(self.undo_patch)
        second.addWidget(self.undo)
        close=QPushButton('VOLTAR')
        close.clicked.connect(self.reject)
        second.addWidget(close)
        root.addLayout(second)

        remote=QFrame()
        remote.setObjectName('updatePanel')
        controls=QVBoxLayout(remote)
        controls.setContentsMargins(14,13,14,13)
        self.remote_head=QLabel('ATUALIZAÇÕES AUTOMÁTICAS // FONTE OFICIAL HTTPS')
        controls.addWidget(self.remote_head)
        self.feed_input=QLineEdit(str(self.settings.value("updates_feed_url","")))
        self.feed_input.setPlaceholderText("https://publisher.example/updates.json")
        controls.addWidget(self.feed_input)
        buttons=QHBoxLayout()
        self.feed_save=QPushButton('SALVAR FONTE')
        self.feed_save.clicked.connect(self.save_feed)
        buttons.addWidget(self.feed_save)
        self.remote_check=QPushButton('VERIFICAR AGORA')
        self.remote_check.clicked.connect(self.check_now)
        buttons.addWidget(self.remote_check)
        self.remote_download=QPushButton('BAIXAR PATCH DISPONÍVEL')
        self.remote_download.setEnabled(False)
        self.remote_download.clicked.connect(self.download_now)
        buttons.addWidget(self.remote_download)
        controls.addLayout(buttons)
        self.check_on_start=QCheckBox('VERIFICAR ATUALIZAÇÕES AO INICIAR')
        self.check_on_start.setChecked(self.settings.value("updates_auto_check",True,type=bool))
        self.check_on_start.toggled.connect(
            lambda checked:self.settings.setValue("updates_auto_check",checked))
        controls.addWidget(self.check_on_start)
        root.addWidget(remote)
        self.status=QLabel('Atualizações remotas: fonte não configurada. O HDD não baixará nada sozinho.')
        self.status.setObjectName('updateSmall')
        root.addWidget(self.status)
        self.show_history()
        bridge=getattr(QApplication.instance(),"_hdd_language_bridge",None)
        if bridge is not None:
            bridge.changed.connect(lambda _code:self.show_history())


    def save_feed(self):
        source=self.feed_input.text().strip()
        if source:
            try:https_url(source)
            except Exception as exc:
                QMessageBox.warning(self,"Atualizações",str(exc))
                return
        self.settings.setValue("updates_feed_url",source)
        self.status.setText("Fonte de atualizações salva." if source else
                            "Verificação remota desativada até configurar a fonte.")

    def check_now(self,auto=False):
        if self.remote_worker is not None and self.remote_worker.isRunning():
            self.status.setText("Aguarde a verificação/download em andamento.")
            return
        self.remote_auto=bool(auto)
        self._download_after_check=False
        self._install_after_download=False
        self._install_when_worker_finishes=False
        feed=str(self.settings.value("updates_feed_url","")).strip()
        if not feed:
            if not auto:self.status.setText("Configure a fonte HTTPS oficial antes de verificar.")
            return
        self.remote_info=None
        self.remote_download.setEnabled(False)
        self.package=None
        self.selection=None
        self.install.setEnabled(False)
        self.install.setText("INSTALAR E REINICIAR")
        self.remote_worker=RemotePatchWorker("check",feed,self.root,parent=self)
        self.remote_worker.delivered.connect(self._checked)
        worker=self.remote_worker
        worker.finished.connect(lambda w=worker:self._worker_done(w))
        self.remote_worker.start()
        self.status.setText("Verificando atualizações em fonte HTTPS...")

    def _checked(self,ok,response):
        if not ok:
            self.status.setText("Verificação remota: "+str(response))
            return
        if response is None:
            self.status.setText("Nenhum patch compatível encontrado.")
            return
        info=response
        skip=str(self.settings.value("updates_skip_patch",""))
        if self.remote_auto and skip==info["id"]:return
        self.remote_info=info
        self.remote_download.setEnabled(True)
        # The online patch has been found, but not downloaded. Let the
        # primary installation button initiate a confirmed download.
        self.install.setText("BAIXAR E INSTALAR PATCH")
        self.install.setEnabled(True)
        self.summary.setText(info["title"]+"\n"+info["notes"]+"\n"
                             +"Requer: "+info["requires"])
        self.status.setText("Patch encontrado; baixar é opcional, instalar exige confirmação.")
        if self.remote_auto:
            # Never enter a nested QMessageBox event loop from a QThread
            # delivered() callback. The check thread may finish WHILE the
            # message box is open; the old code then missed the download.
            QTimer.singleShot(0,self._offer_auto_download)

    def _offer_auto_download(self):
        info=self.remote_info
        if info is None or not self.remote_auto:
            return
        self.show()
        self.raise_()
        answer=QMessageBox.question(
            self,"Nova atualização do H.D.D.",
            f'{info["title"]}\n\n{info["notes"]}\n\nBaixar o patch agora? '
            "A instalação será confirmada separadamente.",
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)
        if answer==QMessageBox.StandardButton.Yes:
            self._request_download_after_check()

    def _request_download_after_check(self):
        if not self.remote_info:
            return
        if self.remote_worker is not None and self.remote_worker.isRunning():
            self._download_after_check=True
            self.status.setText("Finalizando verificação para iniciar o download...")
        else:
            QTimer.singleShot(0,self.download_now)

    def download_now(self):
        if not self.remote_info:return
        if self.remote_worker is not None and self.remote_worker.isRunning():
            self._download_after_check=True
            self.status.setText("Aguardando fim da verificação para baixar...")
            return
        self.remote_download.setEnabled(False)
        self.install.setEnabled(False)
        self.remote_worker=RemotePatchWorker("download",
            str(self.settings.value("updates_feed_url","")),
            self.root,dict(self.remote_info),parent=self)
        self.remote_worker.delivered.connect(self._downloaded)
        worker=self.remote_worker
        worker.finished.connect(lambda w=worker:self._worker_done(w))
        self.remote_worker.start()
        self.status.setText("Baixando e verificando SHA-256. Nada será instalado automaticamente.")

    def _downloaded(self,ok,response):
        if not ok:
            self._install_after_download=False
            self._install_when_worker_finishes=False
            self.remote_download.setEnabled(True)
            self.install.setText("BAIXAR E INSTALAR PATCH")
            self.install.setEnabled(True)
            self.status.setText("Download recusado: "+str(response))
            return
        self.package=Path(response)
        try:
            self.selection=inspect_package(self.package,self.root)
        except Exception as exc:
            self._install_after_download=False
            self._install_when_worker_finishes=False
            self.remote_download.setEnabled(True)
            self.install.setText("BAIXAR E INSTALAR PATCH")
            self.install.setEnabled(True)
            self.status.setText("Patch baixado, mas não autorizado: "+str(exc))
            return
        self.install.setText("INSTALAR E REINICIAR")
        self.install.setEnabled(True)
        self.status.setText("Patch validado. Clique INSTALAR E REINICIAR somente quando desejar.")
        if self._install_after_download:
            self._install_after_download=False
            # Ask to install ONLY after the download QThread exits. This
            # avoids quitting the GUI while a QThread still belongs to it.
            self._install_when_worker_finishes=True

    def show_history(self):
        installed=installed_patches(self.root)
        last=last_report(self.root)
        lang=str(self.settings.value("interface_language","en-US"))
        tr=lambda pt: (
            pt if lang=="pt-BR" else
            # Explicit catalog lookup is locale-aware and does not change
            # historical result messages, paths or patch identifiers.
            __import__("hdd.ui.locale_extensions",fromlist=["translate_dynamic"]).translate_dynamic(pt,lang) or pt)
        rows=[tr('ATUALIZAÇÕES INSTALADAS'), '─'*41]
        rows += [f'{p}  |  {date or "SEM DATA"}' for p,date in installed[:12]]
        rows.append('')
        rows.append(tr('ÚLTIMO RESULTADO'))
        rows.append(str(last.get('message',tr('Nenhuma atualização interna executada.'))))
        rows.append('')
        rows.append(tr('Verificação SHA-256 e versão. Pacotes sem assinatura digital: use somente fontes confiáveis.'))
        self.details.setPlainText('\n'.join(rows))
        self.undo.setEnabled(any(p.startswith('hdd-offline-') for p,_ in installed))

    def choose_file(self):
        filename,_=QFileDialog.getOpenFileName(self,'Selecionar patch H.D.D.',
                     str(Path.home()/'Downloads'),'Arquivos ZIP (*.zip)')
        if not filename:
            return
        self.package=Path(filename)
        self.install.setEnabled(False)
        self.selection=None
        try:
            info=inspect_package(self.package,self.root)
            self.selection=info
        except Exception as exc:
            self.summary.setText('Pacote não autorizado: '+str(exc))
            self.status.setText('O H.D.D. não sofreu alterações.')
            return
        self.summary.setText(f'{info.name}\n{info.description}\n'
                             f'Compatível com {info.requires}   |   {len(info.files)} arquivo(s)')
        self.status.setText('Pronto para instalar. Confirme somente patches de origem confiável.')
        self.install.setEnabled(True)

    def _start(self,action):
        question=('Deseja fechar o H.D.D. e aplicar o pacote selecionado?'
                  if action=='install' else
                  'Deseja fechar o H.D.D. e restaurar a última atualização instalada?')
        question+='\n\nOs arquivos serão alterados somente após o programa fechar.'
        if QMessageBox.question(self,'Confirmar operação',question,
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:
            return
        try:
            queue_worker(self.root,self.package if action=='install' else None,action=action)
        except Exception as exc:
            QMessageBox.critical(self,'Não foi possível iniciar',str(exc))
            return
        # The current Patch 004 worker is unchanged. Observe its final
        # atomic report from a separate, detached, trusted Python helper.
        # If the update fails, do NOT relaunch an application with uncertain files.
        try:
            from hdd.ui.relaunch import spawn_relaunch_monitor
            spawn_relaunch_monitor(self.root, action)
        except Exception as exc:
            self.status.setText('Atualização iniciada; reinício automático indisponível: ' + str(exc))
        # Do not show a blocking dialog here: the detached helper is already
        # waiting for the H.D.D. PID to exit and has a bounded timeout.
        self.accept()
        QTimer.singleShot(100,QApplication.instance().quit)

    def install_patch(self):
        if self.selection is not None:
            self._start('install')
            return
        if self.remote_info is None:
            self.status.setText("Nenhum patch validado. Verifique ou selecione um ZIP primeiro.")
            return
        answer=QMessageBox.question(
            self,"Baixar e instalar atualização",
            "O patch foi encontrado, mas ainda não foi baixado.\n\n"
            "Deseja baixar e validar o ZIP? Se for válido, o H.D.D. "
            "pedirá outra confirmação antes de instalar e reiniciar.",
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)
        if answer==QMessageBox.StandardButton.Yes:
            self._install_after_download=True
            self._request_download_after_check()

    def undo_patch(self):
        self._start('revert')

    def _worker_done(self,worker):
        was_current=self.remote_worker is worker
        if was_current:
            self.remote_worker=None
        worker.deleteLater()
        if not was_current:
            return
        if self._download_after_check:
            self._download_after_check=False
            QTimer.singleShot(0,self.download_now)
        elif self._install_when_worker_finishes:
            self._install_when_worker_finishes=False
            QTimer.singleShot(0,self.install_patch)

    def reject(self):
        # Back button uses QDialog.reject(), which may not send CloseEvent.
        if self.remote_worker is not None and self.remote_worker.isRunning():
            self.status.setText("Aguarde a verificação/download em andamento terminar.")
            return
        super().reject()

    def closeEvent(self,event):
        # Never destroy an active QThread while downloading or fetching.
        if self.remote_worker is not None and self.remote_worker.isRunning():
            self.status.setText("Aguarde a verificação/download em andamento terminar.")
            event.ignore()
            return
        super().closeEvent(event)
