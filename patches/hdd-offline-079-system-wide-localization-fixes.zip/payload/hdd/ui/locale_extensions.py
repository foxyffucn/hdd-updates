"""Explicit, bounded translations for module UI omitted by the first bridge.

Portuguese remains the *source* only for backwards compatibility with the
existing application. The actual factory DISPLAY language is English.
This table never modifies saved user files, names, paths, or commands.
"""
from __future__ import annotations
import re

# Portuguese source -> (English, Spanish); all mappings reviewed, not machine
# translation. A generic substring replace across user data is not allowed.
EXTRA={
"HELIOS // SYSTEM CHECK  /  ANÁLISE LOCAL SOMENTE LEITURA":
    ("HELIOS // SYSTEM CHECK  /  READ-ONLY LOCAL ANALYSIS","HELIOS // REVISIÓN DEL SISTEMA / ANÁLISIS LOCAL DE SOLO LECTURA"),
"HELIOS // DISK OPERATIONS  /  INVENTÁRIO LOCAL - NENHUMA LIMPEZA AUTOMÁTICA":
    ("HELIOS // DISK OPERATIONS  /  LOCAL INVENTORY - NO AUTOMATIC CLEANUP","HELIOS // OPERACIONES DE DISCO / INVENTARIO LOCAL - SIN LIMPIEZA AUTOMÁTICA"),
"HELIOS  //  WORKFLOW PROTOCOLS  /  EXECUÇÃO LOCAL COM CONFIRMAÇÃO":
    ("HELIOS  //  WORKFLOW PROTOCOLS  /  CONFIRMATION-BASED LOCAL EXECUTION","HELIOS // PROTOCOLOS / EJECUCIÓN LOCAL CON CONFIRMACIÓN"),
"ÁREA":("AREA","ÁREA"),
"RESULTADO":("RESULT","RESULTADO"),
"ORIENTAÇÃO":("GUIDANCE","RECOMENDACIÓN"),
"Espaço livre no sistema":("Free system disk space","Espacio libre del disco del sistema"),
"Memória RAM":("RAM memory","Memoria RAM"),
"Tempo de atividade do Windows":("Windows uptime","Tiempo de actividad de Windows"),
"Inicialização de aplicativos":("Application startup","Inicio de aplicaciones"),
"Eventos de erro no Windows":("Windows error events","Errores de Windows"),
"Integridade de patches H.D.D.":("H.D.D. patch integrity","Integridad de parches H.D.D."),
"ATENÇÃO":("WARNING","ADVERTENCIA"),
"INDISPONÍVEL":("UNAVAILABLE","NO DISPONIBLE"),
"Em análise":("Analyzing","Analizando"),
"Aguardando diagnósticos...":("Waiting for diagnostics...","Esperando diagnósticos..."),
"Analisando o Windows e o H.D.D. - aguarde...":
    ("Analyzing Windows and H.D.D....","Analizando Windows y H.D.D...."),
"Verifique a unidade no Explorador.":("Check the drive in File Explorer.","Comprueba la unidad en el Explorador."),
"Abra MONITOR para identificar processos com maior consumo.":
    ("Open MONITOR to identify high-memory processes.","Abre MONITOR para identificar los procesos de mayor consumo."),
"Use o Monitor do Sistema.":("Use System Monitor.","Usa el Monitor del sistema."),
"Se houver lentidão persistente, um reinício normal pode ajudar.":
    ("If slowness persists, a normal restart may help.","Si continúa la lentitud, reiniciar normalmente puede ayudar."),
"Consulte o Gerenciador de Tarefas → Inicializar para revisar.":
    ("Check Task Manager → Startup to review.","Consulta Administrador de tareas → Inicio."),
"Abra o Visualizador de Eventos para analisar detalhes e causas.":
    ("Open Event Viewer to investigate details and causes.","Abre el Visor de eventos para investigar detalles y causas."),
"Use o Visualizador de Eventos para consultar os registros.":
    ("Use Event Viewer to inspect the logs.","Usa el Visor de eventos para consultar los registros."),
"Log inacessível ou indisponível para esta conta.":
    ("Event log inaccessible for this account.","Registro de eventos inaccesible para esta cuenta."),
"Leitura não suportada":("Reading unsupported","Lectura no compatible"),
"Nenhum registro de hash para comparar.":("No saved file hashes to compare.","No hay hashes guardados para comparar."),
"Consulte a Central de Atualizações.":("See Update Center.","Consulta el Centro de actualizaciones."),
"Verifique os registros de atualização.":("Check update logs.","Consulta los registros de actualización."),
"EVENTOS DO WINDOWS":("WINDOWS EVENTS","EVENTOS DE WINDOWS"),
"GERENCIADOR DE TAREFAS":("TASK MANAGER","ADMINISTRADOR DE TAREAS"),
"GERENCIAR DISCOS":("DISK MANAGEMENT","ADMINISTRACIÓN DE DISCOS"),
"RECURSOS DO SISTEMA":("SYSTEM RESOURCES","RECURSOS DEL SISTEMA"),
"ANALISAR NOVAMENTE":("ANALYZE AGAIN","ANALIZAR DE NUEVO"),
"UNIDADE LOCAL":("LOCAL DRIVE","UNIDAD LOCAL"),
"TAMANHO ANALISADO":("SIZE ANALYZED","TAMAÑO ANALIZADO"),
"ITENS ANALISADOS":("ITEMS ANALYZED","ELEMENTOS ANALIZADOS"),
"DUPLICADOS VERIFICADOS":("DUPLICATES VERIFIED","DUPLICADOS VERIFICADOS"),
"Unidade indisponível":("Drive unavailable","Unidad no disponible"),
"PASTA":("FOLDER","CARPETA"),
"ARQUIVOS":("FILES","ARCHIVOS"),
"ARQUIVO GRANDE":("LARGE FILE","ARCHIVO GRANDE"),
"ARQUIVO DUPLICADO":("DUPLICATE FILE","ARCHIVO DUPLICADO"),
"POSSÍVEL TEMPORÁRIO":("POSSIBLE TEMP FILE","POSIBLE ARCHIVO TEMPORAL"),
"PASTAS":("FOLDERS","CARPETAS"),
"ARQUIVOS GRANDES":("LARGE FILES","ARCHIVOS GRANDES"),
"TEMPORÁRIOS":("TEMPORARY FILES","ARCHIVOS TEMPORALES"),
"MODIFICADO":("MODIFIED","MODIFICADO"),
"TAMANHO":("SIZE","TAMAÑO"),
"GRUPO":("GROUP","GRUPO"),
"ANÁLISE DE ARMAZENAMENTO":("STORAGE ANALYSIS","ANÁLISIS DE ALMACENAMIENTO"),
"SELECIONE UMA PASTA":("SELECT A FOLDER","ELIGE UNA CARPETA"),
"Análise iniciada. Arquivos não serão alterados.":
    ("Analysis started. No files will be changed.","Análisis iniciado. No se modificarán archivos."),
"Interrompendo análise, aguarde...":("Stopping analysis...","Deteniendo el análisis..."),
"Análise interrompida.":("Analysis stopped.","Análisis interrumpido."),
"Análise concluída.":("Analysis complete.","Análisis finalizado."),
"Essa pasta não está mais disponível.":("This folder is no longer available.","Esta carpeta ya no está disponible."),
"Aguarde o fim da análise para modificar arquivos.":
    ("Wait for analysis to finish before changing files.","Espera a que termine el análisis antes de modificar archivos."),
"REDE E CONEXÕES  →":("NETWORK AND CONNECTIONS  →","RED Y CONEXIONES  →"),
"PLACA DE VÍDEO":("GRAPHICS CARD","TARJETA GRÁFICA"),
"MEMÓRIA RAM":("RAM MEMORY","MEMORIA RAM"),
"PROCESSOS ATIVOS  //  MAIOR USO DE MEMÓRIA":
    ("ACTIVE PROCESSES  //  HIGHEST MEMORY USAGE","PROCESOS ACTIVOS  //  MAYOR USO DE MEMORIA"),
"Pesquisar processo ou PID...":("Search process or PID...","Buscar proceso o PID..."),
"PROCESSO":("PROCESS","PROCESO"),
"SESSÃO":("SESSION","SESIÓN"),
"Aguardando leitura...":("Waiting for reading...","Esperando datos..."),
"Verificando sensores...":("Checking sensors...","Comprobando sensores..."),
"Aguardando...":("Waiting...","Esperando..."),
"Atualização automática: 1 s (gráficos) / 5 s (processos).":
    ("Automatic refresh: 1 s (charts) / 5 s (processes).","Actualización automática: 1 s (gráficos) / 5 s (procesos)."),
"Utilização total do processador":("Total CPU usage","Uso total de CPU"),
"Sensor não disponível":("Sensor unavailable","Sensor no disponible"),
"Unidade do sistema":("System drive","Unidad del sistema"),
"utilização não disponível":("usage unavailable","uso no disponible"),
"Leitura local e somente leitura":("Local read-only monitoring","Monitoreo local de solo lectura"),
"Open pasta":("Open folder","Abrir carpeta"),
"Open perfil Chrome":("Open Chrome profile","Abrir perfil de Chrome"),
"Chrome + Restaurar":("Chrome + Restore","Chrome + Restaurar"),
"Open item do catálogo":("Open catalog item","Abrir elemento del catálogo"),
"Open módulo H.D.D.":("Open H.D.D. module","Abrir módulo H.D.D."),
"Aguardar segundos":("Wait seconds","Esperar segundos"),
"Abrir pasta":("Open folder","Abrir carpeta"),
"Abrir perfil Chrome":("Open Chrome profile","Abrir perfil de Chrome"),
"Abrir item do catálogo":("Open catalog item","Abrir elemento del catálogo"),
"Abrir módulo H.D.D.":("Open H.D.D. module","Abrir módulo H.D.D."),
"ARRASTE AS ETAPAS PARA REORDENAR  //  ESCOLHA A AÇÃO ABAIXO":
    ("DRAG STEPS TO REORDER  //  CHOOSE AN ACTION BELOW","ARRASTRA PASOS PARA REORDENAR // ELIGE UNA ACCIÓN"),
"MODO VISUAL  //  Organize as ações, depois salve.":
    ("VISUAL MODE  //  Arrange actions, then save.","MODO VISUAL // Organiza las acciones y guarda."),
"MODO AVANÇADO  //  Edite os comandos; mudanças são validadas.":
    ("ADVANCED MODE  //  Edit commands; changes are validated.","MODO AVANZADO // Edita comandos; se validarán los cambios."),
"MODO VISUAL  //  Script sincronizado com as etapas.":
    ("VISUAL MODE  //  Script synced with steps.","MODO VISUAL // Guion sincronizado con los pasos."),
"Os scripts são convertidos em etapas visuais ao salvar.":
    ("Scripts are converted to visual steps when saving.","Los guiones se convierten en pasos visuales al guardar."),
"Ex.: Iniciar dia, Preparar Blender, Abrir workspace":
    ("E.g.: Start day, Prepare Blender, Open workspace","Ej.: Iniciar día, preparar Blender, abrir espacio de trabajo"),
"PROTOCOLO  //  IDENTIFICAÇÃO":("PROTOCOL  //  IDENTIFICATION","PROTOCOLO // IDENTIFICACIÓN"),
"ETAPAS  //  ORDEM DE EXECUÇÃO":("STEPS  //  EXECUTION ORDER","PASOS // ORDEN DE EJECUCIÓN"),
"ETAPAS DO PROTOCOLO  //  PRÉVIA":("PROTOCOL STEPS  //  PREVIEW","PASOS DEL PROTOCOLO // VISTA PREVIA"),
"HELIOS  //  WORKFLOW PROTOCOLS  /  EXECUÇÃO LOCAL COM CONFIRMAÇÃO":
    ("HELIOS  //  WORKFLOW PROTOCOLS  /  CONFIRMATION-BASED LOCAL EXECUTION",
     "HELIOS  //  PROTOCOLOS  /  EJECUCIÓN LOCAL CON CONFIRMACIÓN"),
"CHROME + RESTAURAR":("CHROME + RESTORE","CHROME + RESTAURAR"),
"ABRIR PASTA":("OPEN FOLDER","ABRIR CARPETA"),
"AGUARDAR":("WAIT","ESPERAR"),
"ABRIR":("OPEN","ABRIR"),
"MÓDULO":("MODULE","MÓDULO"),
"ABRIR PASTA  //":("OPEN FOLDER  //","ABRIR CARPETA  //"),
"ABRIR  //":("OPEN  //","ABRIR  //"),
"MÓDULO  //":("MODULE  //","MÓDULO  //"),
"AGUARDAR  //":("WAIT  //","ESPERAR  //"),
"CHROME + RESTAURAR  //":("CHROME + RESTORE  //","CHROME + RESTAURAR  //"),
"ETAPA":("STEP","PASO"),
"etapas":("steps","pasos"),
"etapa":("step","paso"),
"ABRIR MÓDULO":("OPEN MODULE","ABRIR MÓDULO"),
"ADICIONAR ETAPA":("ADD STEP","AÑADIR PASO"),
"ADICIONAR MÓDULO":("ADD MODULE","AÑADIR MÓDULO"),
"VISUAL MODE":("VISUAL MODE","MODO VISUAL"),
"EXECUÇÃO LOCAL COM CONFIRMAÇÃO":("CONFIRMATION-BASED LOCAL EXECUTION","EJECUCIÓN LOCAL CON CONFIRMACIÓN"),
"Nenhum patch compatível encontrado.":("No compatible patch found.","No se encontró ningún parche compatible."),
"Patch encontrado; baixar é opcional, instalar exige confirmação.":
    ("Update found; download is optional and installation requires confirmation.",
     "Actualización encontrada; la descarga es opcional y la instalación requiere confirmación."),
"Patch validado. Clique INSTALAR E REINICIAR somente quando desejar.":
    ("Patch verified. Click INSTALL AND RESTART when ready.",
     "Parche verificado. Haz clic en INSTALAR Y REINICIAR cuando quieras."),
"BAIXAR E INSTALAR PATCH":("DOWNLOAD AND INSTALL PATCH","DESCARGAR E INSTALAR PARCHE"),
"INSTALAR E REINICIAR":("INSTALL AND RESTART","INSTALAR Y REINICIAR"),
"Baixando e verificando SHA-256. Nada será instalado automaticamente.":
    ("Downloading and verifying SHA-256. Nothing installs automatically.",
     "Descargando y verificando SHA-256. Nada se instala automáticamente."),
"Confirme somente patches de origem confiável.":("Confirm only trusted patches.","Confirma solo parches de confianza."),
}
EXTRA.update({
"OPERADOR LOCAL":("LOCAL OPERATOR","OPERADOR LOCAL"),
"ATIVO":("ACTIVE","ACTIVO"),
"Somente este usuário do Windows.":("Only this Windows user.","Solo este usuario de Windows."),
"Atualizações remotas: fonte não configurada. O HDD não baixará nada sozinho.":
    ("Remote updates: no source configured. H.D.D. never downloads without consent.",
     "Actualizaciones remotas: origen sin configurar. H.D.D. no descargará sin permiso."),
})
# Every dynamic form must match the ENTIRE string; never translate filenames,
# personal protocol names, arbitrary free text, or external commands.
PATTERNS=[
(r"^(\d+(?:\.\d+)? GiB) livres de (\d+(?:\.\d+)? GiB) \((\d+(?:\.\d+)?%)\)$",
 lambda m,l:(f"{m[1]} free of {m[2]} ({m[3]})" if l=="en-US" else f"{m[1]} libres de {m[2]} ({m[3]})")),
(r"^(\d+)% em uso [•·] (\d+(?:\.\d+)? GiB) disponíveis$",
 lambda m,l:(f"{m[1]}% in use • {m[2]} available" if l=="en-US" else f"{m[1]}% en uso • {m[2]} disponibles")),
(r"^(\d+) dias e (\d+) horas$",
 lambda m,l:(f"{m[1]} days and {m[2]} hours" if l=="en-US" else f"{m[1]} días y {m[2]} horas")),
(r"^(\d+) entradas nas chaves Run do Windows$",
 lambda m,l:(f"{m[1]} entries in Windows Run registry keys" if l=="en-US" else f"{m[1]} entradas en las claves Run de Windows")),
(r"^(\d+) eventos críticos/erros encontrados na amostra \(últimas 24 h, máx\. 30\)$",
 lambda m,l:(f"{m[1]} critical/error events in sample (last 24 h, max. 30)" if l=="en-US" else f"{m[1]} eventos críticos/de error (últimas 24 h, máx. 30)")),
(r"^(\d+) arquivos comparados; (\d+) alteração\(ões\) local\(is\)(.*)$",
 lambda m,l:((f"{m[1]} files compared; {m[2]} local changes" if l=="en-US" else f"{m[1]} archivos comparados; {m[2]} cambios locales")+m[3])),
(r"^(\d+) verificações concluídas\. Nenhum arquivo ou serviço foi alterado\.$",
 lambda m,l:(f"{m[1]} checks completed. No files or services were changed." if l=="en-US" else f"{m[1]} comprobaciones completadas. No se cambiaron archivos ni servicios.")),
(r"^Processos listados: (\d+) [•·] Leitura local e somente leitura$",
 lambda m,l:(f"Processes listed: {m[1]} • Read-only local monitoring" if l=="en-US" else f"Procesos listados: {m[1]} • Monitorización local de solo lectura")),
(r"^([^\\n]{1,30} GiB / [^\\n]{1,30} GiB) [•·] Unidade do sistema$",
 lambda m,l:(f"{m[1]} • System drive" if l=="en-US" else f"{m[1]} • Unidad del sistema")),
(r"^([^\\n]{1,150}) [•·] utilização não disponível$",
 lambda m,l:(f"{m[1]} • usage unavailable" if l=="en-US" else f"{m[1]} • uso no disponible")),
(r"^(\d+) etapas válidas\. Nenhuma foi executada\.$",
 lambda m,l:(f"{m[1]} valid steps. None executed." if l=="en-US" else f"{m[1]} pasos válidos. Ninguno ejecutado.")),
(r"^✓  SCRIPT VÁLIDO  //  (\d+) ETAPAS$",
 lambda m,l:(f"✓ VALID SCRIPT // {m[1]} STEPS" if l=="en-US" else f"✓ GUION VÁLIDO // {m[1]} PASOS")),
(r"^(\d+) grupo\(s\) / até (.+)$",
 lambda m,l:(f"{m[1]} group(s) / up to {m[2]}" if l=="en-US" else f"{m[1]} grupo(s) / hasta {m[2]}")),
]
_PATTERNS=[(re.compile(pattern),func) for pattern,func in PATTERNS]

def translate_dynamic(text,locale):
    if locale=="pt-BR" or not isinstance(text,str):
        return None
    if text in EXTRA:
        return EXTRA[text][0 if locale=="en-US" else 1]
    for regex,fn in _PATTERNS:
        found=regex.fullmatch(text)
        if found:return fn(found,locale)
    return None

STEP_PREFIX={
    "ABRIR  //  ":("OPEN  //  ","ABRIR  //  "),
    "ABRIR PASTA  //  ":("OPEN FOLDER  //  ","ABRIR CARPETA  //  "),
    "MÓDULO  //  ":("MODULE  //  ","MÓDULO  //  "),
    "CHROME + RESTAURAR  //  ":("CHROME + RESTORE  //  ","CHROME + RESTAURAR  //  "),
    "AGUARDAR  //  ":("WAIT  //  ","ESPERAR  //  "),
}
def translate_step_label(text,locale):
    if locale=="pt-BR":return text
    for prefix,translated in STEP_PREFIX.items():
        # Preserve user-supplied paths and names unmodified.
        if text.startswith(prefix):
            return translated[0 if locale=="en-US" else 1]+text[len(prefix):]
    return text


def translate_protocol_row(text,locale):
    """Translate a generated step's prefix, preserving paths and user names."""
    match=re.fullmatch(r"(\d{2}\s{3})(.*)",text)
    if not match:return None
    translated=translate_step_label(match[2],locale)
    if translated==match[2]:return None
    return match[1]+translated

# Status labels and fixed messages used by deferred operations.
EXTRA.update({
"Selecione Fish Audio, configure a chave e escolha uma voz antes do Reboot.":
 ("Select Fish Audio, configure its API key and choose a voice before reboot.",
  "Selecciona Fish Audio, configura la clave y elige una voz antes de reiniciar."),
"Verificando atualizações em fonte HTTPS...":
 ("Checking HTTPS source for updates...","Buscando actualizaciones en la fuente HTTPS..."),
"Finalizando verificação para iniciar o download...":
 ("Finishing update check before download...","Terminando la comprobación antes de descargar..."),
"Aguardando fim da verificação para baixar...":
 ("Waiting for update check to finish before downloading...",
  "Esperando a que termine la comprobación para descargar..."),
"Nenhum patch validado. Verifique ou selecione um ZIP primeiro.":
 ("No verified patch. Check for updates or select a ZIP first.",
  "No hay un parche verificado. Busca actualizaciones o selecciona un ZIP."),
"ATUALIZAÇÕES INSTALADAS":("INSTALLED UPDATES","ACTUALIZACIONES INSTALADAS"),
"ÚLTIMO RESULTADO":("LAST RESULT","ÚLTIMO RESULTADO"),
"Nenhuma atualização interna executada.":
 ("No internal update has run.","No se ha ejecutado ninguna actualización interna."),
"Verificação SHA-256 e versão. Pacotes sem assinatura digital: use somente fontes confiáveis.":
 ("SHA-256 and version verification. Unsigned packages: use only trusted sources.",
  "Verificación SHA-256 y versión. Paquetes sin firma digital: usa solo fuentes fiables."),
"REGISTROS DA SESSÃO":("SESSION LOGS","REGISTROS DE SESIÓN"),
"Eventos desta sessão. Não é um console de comandos.":
 ("Events from this session. Not a command console.",
  "Eventos de esta sesión. No es una consola de comandos."),
"Leitura do ambiente atual. Não executa varreduras externas nem acessa a Fairy.":
 ("Current environment readings. No external scanning or Fairy access.",
  "Lecturas del entorno actual. Sin análisis externos ni acceso a Fairy."),
"Somente este usuário do Windows. Ao ativar, qualquer pessoa que use esta sessão do Windows poderá acessar os dados locais do H.D.D. A senha da conta será solicitada uma vez para confirmar a escolha. O botão BLOQUEAR continua exigindo login nesta execução. Não altera o login nem o PIN do Windows.":
 ("Only this Windows user. Anyone using this Windows session can access local H.D.D. data when enabled. The account password is required once to confirm this choice. LOCK still requires login for this session. This does not change Windows sign-in or PIN.",
  "Solo este usuario de Windows. Cualquiera que utilice esta sesión podrá acceder a los datos locales del H.D.D. La contraseña se solicitará una vez para confirmar. BLOQUEAR seguirá requiriendo iniciar sesión. No cambia el acceso ni el PIN de Windows."),
"As contas locais possuem senha. A sincronização online ainda está em desenvolvimento.":
 ("Local accounts are password-protected. Online synchronization is still under development.",
  "Las cuentas locales tienen contraseña. La sincronización en línea sigue en desarrollo."),
})

EXTRA.update({
"Analisando o Windows e o H.D.D. — aguarde...":
 ("Analyzing Windows and H.D.D. — please wait...",
  "Analizando Windows y H.D.D. — espera..."),
"Análise concluída.":("Analysis complete.","Análisis finalizado."),
"Análise interrompida.":("Analysis stopped.","Análisis interrumpido."),
"Pastas não são apagadas pelo analisador. Use o Explorador para revisá-las.":
 ("Folders are not deleted by Storage Analysis. Use File Explorer to review them.",
  "El analizador no elimina carpetas. Usa el Explorador para revisarlas."),
"Aguarde o fim da análise para modificar arquivos.":
 ("Wait for analysis to finish before modifying files.",
  "Espera a que termine el análisis antes de modificar archivos."),
"Protocolo em execução...":("Protocol running...","Protocolo en ejecución..."),
"Etapa adicionada ao Modo Visual.":
 ("Step added to Visual Mode.","Paso añadido al modo visual."),
})
