"""Opt-in per-user Windows startup registration for HDD and activated Fairy.

Windows Run entries are created/removed ONLY for these two names.
No administrator, Task Scheduler, service, shell elevation or persistence
outside HKCU. Existing programs' startup settings are never altered.
"""
from __future__ import annotations
import os,subprocess,sys
from pathlib import Path
import winreg

from hdd.paths import project_root
from hdd.ui.fairy_install_backend import installed_state
from hdd.ui.fairy_activation import activated

RUN_KEY=r"Software\Microsoft\Windows\CurrentVersion\Run"
HDD_NAME="HDD-System"
FAIRY_NAME="HDD-Fairy"
HDD_PREF="windows_start_hdd_v1"
FAIRY_PREF="windows_start_fairy_v1"
FAIRY_CHOICE_SET="windows_start_fairy_choice_recorded_v1"

class StartupError(RuntimeError):pass

def project():
    return project_root().resolve()

def fairy_target(settings):
    from hdd.ui.fairy_install_backend import default_target
    return Path(str(settings.value("fairy_install_target",str(default_target())))).resolve()

def _quote_win(arg):
    return subprocess.list2cmdline([str(arg)])

def hdd_command():
    root=project()
    py=root/".venv/Scripts/pythonw.exe"
    script=root/"main.py"
    if not py.is_file() or not script.is_file():
        raise StartupError("H.D.D. Python environment or main.py is missing.")
    return _quote_win(py)+" "+_quote_win(script)

def _script_path():
    local=Path(os.environ.get("LOCALAPPDATA",str(Path.home()/"AppData/Local")))
    return local/"HDD-System"/"Autostart"/"start_fairy_hdd.vbs"

def _fairy_script_content(install):
    # Let the official start_fairy.bat continue loading the user's private
    # settings as usual, including singleton protection and env config.
    path=str(Path(install).resolve()/"start_fairy.bat")
    if '"' in path or "\r" in path or "\n" in path:
        raise StartupError("Invalid Fairy installation path.")
    directory=str(Path(install).resolve())
    return ('Set shell = CreateObject("WScript.Shell")\r\n'
            'shell.CurrentDirectory = "'+directory+'"\r\n'
            'shell.Run Chr(34) & "'+path+'" & Chr(34), 0, False\r\n')

def fairy_command(settings):
    install=fairy_target(settings)
    if not installed_state(install) or not activated(install):
        raise StartupError("Fairy first activation is not complete.")
    if not (install/"start_fairy.bat").is_file():
        raise StartupError("Fairy startup launcher is unavailable.")
    runner=Path(os.environ.get("SystemRoot",r"C:\Windows"))/"System32/wscript.exe"
    if not runner.is_file():
        raise StartupError("Windows Script Host is not available.")
    dest=_script_path()
    return (_quote_win(runner)+" //B //nologo "+_quote_win(dest),dest,
            _fairy_script_content(install))

def _set_entry(name,value):
    with winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER,RUN_KEY,0,winreg.KEY_SET_VALUE) as key:
        winreg.SetValueEx(key,name,0,winreg.REG_SZ,value)

def _read_entry(name):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,RUN_KEY,0,winreg.KEY_READ) as key:
            result,kind=winreg.QueryValueEx(key,name)
            return str(result) if kind in (winreg.REG_SZ,winreg.REG_EXPAND_SZ) else ""
    except FileNotFoundError:return ""

def _delete_entry(name):
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER,RUN_KEY,0,winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key,name)
    except FileNotFoundError:pass

def hdd_enabled():
    try:return _read_entry(HDD_NAME)==hdd_command()
    except StartupError:return False

def fairy_enabled(settings):
    try:
        command,_,_ = fairy_command(settings)
        return _read_entry(FAIRY_NAME)==command
    except (StartupError,OSError):return False

def set_hdd_enabled(enabled):
    if enabled:
        _set_entry(HDD_NAME,hdd_command())
    else:
        _delete_entry(HDD_NAME)
    if hdd_enabled()!=bool(enabled):
        raise StartupError("Windows did not save H.D.D. startup choice.")

def set_fairy_enabled(settings,enabled):
    if not enabled:
        _delete_entry(FAIRY_NAME)
        if _read_entry(FAIRY_NAME):
            raise StartupError("Windows did not disable Fairy autostart.")
        return
    command,dest,script=fairy_command(settings)
    dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.is_symlink() or dest.parent.is_symlink():
        raise StartupError("Fairy startup script path is linked.")
    temporary=dest.with_suffix(".new")
    if temporary.exists() and temporary.is_symlink():
        raise StartupError("Fairy temporary script is linked.")
    try:
        temporary.write_text(script,encoding="utf-16")
        os.replace(temporary,dest)
    finally:
        temporary.unlink(missing_ok=True)
    _set_entry(FAIRY_NAME,command)
    if not fairy_enabled(settings):
        raise StartupError("Windows did not save Fairy autostart choice.")

def default_fairy_after_activation(settings):
    """Default ON for an activated Fairy; preserve all explicit choices."""
    install=fairy_target(settings)
    if not activated(install):
        return False
    if not settings.value(FAIRY_CHOICE_SET,False,type=bool):
        set_fairy_enabled(settings,True)
        settings.setValue(FAIRY_PREF,True)
        settings.setValue(FAIRY_CHOICE_SET,True)
        settings.sync()
        return True
    return False

def enable_preference(settings,which,enabled):
    # Don't change saved preferences until Windows confirms its registry value.
    if which=="hdd":
        set_hdd_enabled(enabled)
        settings.setValue(HDD_PREF,bool(enabled))
    elif which=="fairy":
        set_fairy_enabled(settings,enabled)
        settings.setValue(FAIRY_PREF,bool(enabled))
        settings.setValue(FAIRY_CHOICE_SET,True)
    else:raise StartupError("Unknown startup option.")
    settings.sync()

def sync_existing_preferences(settings):
    """Repair stale Run commands after moving a project or installing an update.

    Never ENABLE HDD by default. Fairy is only default enabled when activated.
    Failed attempts leave Windows/login usable and are reported to the UI.
    """
    if settings.value(HDD_PREF,False,type=bool):
        set_hdd_enabled(True)
    # Reconcile an explicit Fairy opt-in, or the post-activation default.
    if default_fairy_after_activation(settings):
        return
    if settings.value(FAIRY_CHOICE_SET,False,type=bool) and activated(fairy_target(settings)):
        set_fairy_enabled(settings,settings.value(FAIRY_PREF,True,type=bool))
    elif not activated(fairy_target(settings)):
        # Never retain an HDD-managed Fairy startup for uninstalled/unactivated modules.
        _delete_entry(FAIRY_NAME)
