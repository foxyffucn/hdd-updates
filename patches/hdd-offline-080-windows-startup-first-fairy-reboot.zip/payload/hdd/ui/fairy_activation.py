"""First Fairy activation is a one-time milestone per installed Fairy.

The old 2026 development handoff acknowledgment (phase 'visible') is accepted
for migration, so existing successfully activated Fairy installations do NOT
have to watch the cinematic again after this patch.
"""
from __future__ import annotations
import json,os, time
from pathlib import Path
from hdd.ui.fairy_install_backend import installed_state

MARKER=Path("userdata/hdd_first_reboot_complete_v1.json")
OLD_ACK=Path("userdata/hdd_boot_handoff_ack.json")

def _read(path):
    try:
        if path.is_symlink() or not path.is_file():return {}
        obj=json.loads(path.read_text(encoding="utf-8"))
        return obj if isinstance(obj,dict) else {}
    except (OSError,ValueError,TypeError):
        return {}

def activated(install,*,allow_migration=True):
    """Never unlock before an installed Fairy has acknowledged real visibility."""
    install=Path(install)
    if not installed_state(install):
        return False
    marker=_read(install/MARKER)
    if marker.get("format")=="hdd-first-fairy-activation-v1" and marker.get("complete") is True:
        return True
    if allow_migration:
        previous=_read(install/OLD_ACK)
        if previous.get("phase")=="visible" and bool(previous.get("request_id")):
            # The old confirmed FULLSCREEN Fairy acknowledgment is sufficient
            # to migrate prior users. Never use 'ready' or merely 'reveal'.
            complete_activation(install,migrate=True)
            return True
    return False

def complete_activation(install,*,migrate=False):
    install=Path(install).resolve()
    if not installed_state(install):
        raise RuntimeError("Fairy has not been installed.")
    marker=install/MARKER
    if marker.is_symlink() or marker.parent.is_symlink():
        raise RuntimeError("Activation data path is not safe.")
    if marker.exists():
        found=_read(marker)
        if found.get("format")=="hdd-first-fairy-activation-v1" and found.get("complete") is True:
            return marker
        raise RuntimeError("Existing Fairy activation marker is not valid.")
    marker.parent.mkdir(parents=True,exist_ok=True)
    payload={"format":"hdd-first-fairy-activation-v1",
             "complete":True,"source":"migration" if migrate else "confirmed-visual-reboot",
             "timestamp":int(time.time())}
    tmp=marker.with_suffix(".hddtmp")
    if tmp.is_symlink():raise RuntimeError("Activation marker temporary file is linked.")
    try:
        with tmp.open("x",encoding="utf-8") as f:
            json.dump(payload,f,indent=2)
            f.flush()
            os.fsync(f.fileno())
        os.replace(tmp,marker)
    finally:
        tmp.unlink(missing_ok=True)
    return marker
