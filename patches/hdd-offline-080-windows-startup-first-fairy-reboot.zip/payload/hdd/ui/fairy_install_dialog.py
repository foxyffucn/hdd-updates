"""H.D.D. external intelligence / real Fairy installer interface.

Explicit operator action starts a verified local factory package and its
ordinary dependency installer. Never reads or stores API keys. Keeps the
existing fake cinematic preview available independently.
"""
from __future__ import annotations

from pathlib import Path
import subprocess
import threading
import traceback
import time

from PySide6.QtCore import Qt, QSettings, QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QDialog,QFileDialog,QHBoxLayout,QLabel,QLineEdit,
    QMessageBox,QPlainTextEdit,QProgressBar,QPushButton,QVBoxLayout,QWidget
)

from hdd.ui.fairy_install_backend import (
    BUNDLED_PACKAGE, check_target, default_target, installed_state,
    python_command, run_factory_install,validate_package,
)
from hdd.ui.fairy_first_reveal import voice_pack_ready
from hdd.ui.fairy_handoff import FairyHandoff
from hdd.ui.fairy_activation import activated,complete_activation
from hdd.ui.windows_autostart import default_fairy_after_activation
from hdd.ui.fairy_setup_gate import readiness,prepare_first_launch
from hdd.ui.language_bridge import (
    set_localized_text, set_localized_window_title,
    translate_before_first_paint,
)


class _InstallerThread(QThread):
    message=Signal(str)
    installed=Signal(str)
    failed=Signal(str)

    def __init__(self,source,target,parent=None):
        super().__init__(parent)
        self.source=source
        self.target=target
        self.cancel=threading.Event()

    def run(self):
        try:
            result=run_factory_install(self.source,self.target,
                                       self.message.emit,self.cancel)
            self.installed.emit(str(result))
        except (RuntimeError,ValueError,InterruptedError,OSError,subprocess.SubprocessError) as exc:
            self.failed.emit(str(exc))


class _CinematicPreload(QThread):
    """Warm the video system and real Fairy without touching any Qt widget."""

    prepared=Signal()
    failed=Signal(str)

    def __init__(self,handoff,parent=None,canvas=(1440,900)):
        super().__init__(parent)
        self.handoff=handoff
        self.canvas=canvas

    def run(self):
        try:
            from hdd.ui.boot_install_video import VIDEO_PATH
            from hdd.ui.fairy_first_reveal import voice_pack_ready
            from hdd.ui.install_preview_audio import SOUND_DIR,STAGE_WAV
            # Import and verify the slow decoder BEFORE cinematic t=0.
            import cv2
            if not VIDEO_PATH.is_file():
                raise RuntimeError("Cinematic error video is missing.")
            cap=cv2.VideoCapture(str(VIDEO_PATH))
            try:
                if not cap.isOpened() or not cap.read()[0]:
                    raise RuntimeError("Cinematic error video could not be decoded.")
            finally:
                cap.release()
            if not voice_pack_ready():
                raise RuntimeError("Fairy introduction recordings unavailable.")
            # The logo is intentionally silent. All other stages must be
            # available before the audio clock starts.
            for stage in ("numeric","preview_error_video","loading"):
                wav=SOUND_DIR/STAGE_WAV[stage]
                if not wav.is_file():
                    raise RuntimeError("Missing cinematic soundtrack: "+stage)
            if self.isInterruptionRequested():return
            # The 2.45s film is decoded off-thread before the UI/audio clock.
            from hdd.ui.boot_install_video import PREPARED_FILM
            PREPARED_FILM.preload(self.canvas)
            if self.isInterruptionRequested():
                PREPARED_FILM.release()
                return
            # 719-frame logo decoded under the black screen, not at page cuts.
            from hdd.ui.boot_logo import LOGO_ATLAS
            if not LOGO_ATLAS.predecode_for_cinematic():
                raise RuntimeError("Full Helios logo pages could not be preloaded.")
            if self.isInterruptionRequested():
                LOGO_ATLAS.release_cinematic()
                PREPARED_FILM.release()
                return
            self.handoff.prewarm()
            if self.isInterruptionRequested():
                self.handoff.cancel()
                LOGO_ATLAS.release_cinematic()
                PREPARED_FILM.release()
                return
            self.prepared.emit()
        except Exception as exc:
            from hdd.ui.boot_logo import LOGO_ATLAS
            from hdd.ui.boot_install_video import PREPARED_FILM
            PREPARED_FILM.release()
            LOGO_ATLAS.release_cinematic()
            if not self.isInterruptionRequested():
                self.failed.emit(str(exc))


class _ActivationPlayback(QDialog):
    """Black preload gate, then H.D.D. cinematic, then the real Fairy."""

    def __init__(self,settings,handoff,on_finish,on_cancel,parent=None,on_confirm=None):
        super().__init__(parent)
        self.setObjectName("hddFairyActivationPlayback")
        self.setWindowTitle("H.D.D. // EXTERNAL MODULE")
        self.setWindowFlags(Qt.WindowType.Window|Qt.WindowType.FramelessWindowHint)
        self.setStyleSheet("background: #000000;")
        self._handoff=handoff
        self._on_finish=on_finish
        self._on_cancel=on_cancel
        self._on_confirm=on_confirm
        self._prewarmed=False
        self._film_started=False
        self._preloader=None
        self._preload_started=0.0
        self._preload_timer=QTimer(self)
        self._preload_timer.setInterval(50)
        self._preload_timer.timeout.connect(self._check_prepared)
        self._preload_finished=False
        self._preload_finished_at=0.0
        self._ended=False
        self._waiting=False
        self._hold_started=0.0
        self._ack_poll=QTimer(self)
        self._ack_poll.setInterval(35)
        self._ack_poll.timeout.connect(self._check_fairy_visible)
        self._settings=settings
        self.boot=None
        layout=QVBoxLayout(self)
        layout.setContentsMargins(0,0,0,0)
        self._film_layout=layout

    def start(self):
        # Nothing heavy is constructed before the black window is shown.
        self.showFullScreen()
        self.setFocus()
        self._preload_started=time.monotonic()
        QTimer.singleShot(0,self._start_preload)

    def _start_preload(self):
        if self._ended:return
        worker=_CinematicPreload(self._handoff,self,canvas=(self.width(),self.height()))
        self._preloader=worker
        worker.prepared.connect(self._preload_complete)
        worker.failed.connect(self._preload_failed)
        worker.start()
        self._preload_timer.start()

    def _preload_complete(self):
        self._preload_finished=True
        self._preload_finished_at=time.monotonic()
        self._check_prepared()

    def _check_prepared(self):
        if self._ended or self._film_started:
            return
        elapsed=time.monotonic()-self._preload_started
        # Existing sessions running code from before Patch 057 understand
        # "prewarm", but NEVER emit the READY acknowledgement. The old UI
        # cannot be hot-patched while running: report the actual remedy
        # instead of leaving a silent black screen for 45 seconds.
        if (self._preload_finished and
            getattr(self._handoff,"attached_to_running",False) and
            time.monotonic()-self._preload_finished_at>=12 and not self._handoff.is_ready()):
            self._preload_failed(
                "Fairy is already running with an older or unresponsive startup.\n"
                "Close the existing Fairy normally from its system-tray icon, "
                "then run REBOOT + INICIAR FAIRY again. "
                "Your settings and saved data are preserved.")
            return
        if elapsed>90:
            self._preload_failed(
                "Fairy did not confirm readiness. Check that the Fairy can "
                "start normally and review its logs if the issue continues.")
            return
        if not self._preload_finished or not self._handoff.is_ready():
            return
        self._preload_timer.stop()
        self._film_started=True
        from hdd.ui.boot_install_video import SimulatedInstallationBoot
        self.boot=SimulatedInstallationBoot(self._settings,self)
        # The black screen remains visible while GUI-only Qt caches warm.
        # The cinematic clock and soundtrack have NOT started yet.
        try:
            self.boot.resize(self.size())
            self.boot.prime_visual_pipeline()
        except Exception as exc:
            self._preload_failed("Visual resources could not be prepared: "+str(exc))
            return
        self._film_layout.addWidget(self.boot)
        self.boot.finished.connect(self._finished)
        self.boot.show()
        # A fresh timer starts here, after decoder and Fairy are ready.
        self.boot.begin(style="full")
        self.boot.setFocus()

    def _preload_failed(self,reason):
        if self._ended:return
        self._ended=True
        self._preload_timer.stop()
        self._handoff.cancel()
        self.close()
        QMessageBox.warning(self.parent(),"H.D.D. // EXTERNAL MODULE",
                            "Cinematic initialization could not complete.\n"+reason)

    def _finished(self):
        if self._ended or self._waiting:return
        if not bool(self.boot._natural_completion):
            self.close()
            return
        # Hold H.D.D. Loading's completed frame rather than revealing the
        # desktop while the original Fairy window is opening.
        self._waiting=True
        self.boot._stage_time=min(self.boot._stage_lengths[-1],1.999)
        self.boot.stop()
        import time
        self._hold_started=time.monotonic()
        try:
            self._on_finish()
        except Exception:
            self.close()
            raise
        # Fairy will acknowledge only when its ACTUAL fullscreen window is
        # exposed and opaque. No fixed delay, no duplicate preview avatar.
        self._ack_poll.start()

    def _check_fairy_visible(self):
        if self._ended or not self._waiting:return
        import time
        ready=False
        try:
            ready=bool(self.parent()._handoff.is_visible())
        except (AttributeError,OSError,ValueError):
            pass
        if ready:
            # Reboot is finished ONLY when the real Fairy confirmed
            # an opaque, visible fullscreen window. 'ready' alone is NOT enough.
            if self._on_confirm is not None:
                try:
                    self._on_confirm()
                except Exception as exc:
                    QMessageBox.warning(self.parent(),"H.D.D. // FAIRY",
                        "Fairy started, but activation preferences could not be saved:\n"+str(exc))
            self._waiting=False
            self._ended=True
            self._ack_poll.stop()
            self.close()
            return
        if time.monotonic()-self._hold_started>=25.0:
            self.close()
            QMessageBox.warning(
                self.parent(),"H.D.D. // EXTERNAL MODULE",
                "The Fairy did not confirm its fullscreen window. "
                "The startup sequence was interrupted. Check the Fairy logs.")

    def keyPressEvent(self,event):
        if event.key()==Qt.Key.Key_Escape:
            if self._waiting:
                self.close()
            elif self.boot is not None:
                self.boot.skip()
            else:
                self.close()
        else:super().keyPressEvent(event)

    def closeEvent(self,event):
        self._ack_poll.stop()
        self._preload_timer.stop()
        worker=self._preloader
        if worker is not None and worker.isRunning():
            worker.requestInterruption()
        if self.boot is not None:
            self.boot.stop()
        elif worker is None or not worker.isRunning():
            from hdd.ui.boot_logo import LOGO_ATLAS
            from hdd.ui.boot_install_video import PREPARED_FILM
            LOGO_ATLAS.release_cinematic()
            PREPARED_FILM.release()
        if not self._ended:
            self._ended=True
            self._on_cancel()
        super().closeEvent(event)


class FairyFactoryInstallDialog(QDialog):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.setObjectName("hddFairyFactoryInstallation")
        set_localized_window_title(self,"H.D.D. // INTEGRAÇÃO DE UNIDADE EXTERNA")
        self.setMinimumSize(770,580)
        self.resize(900,695)
        self.setStyleSheet("""
            QDialog#hddFairyFactoryInstallation{background:#06192b;color:#def9ff;}
            QLabel{color:#c9e8f4;background:transparent;}
            QLabel#head{font:800 24px 'zero 5','Segoe UI';color:#e8fbff;}
            QLabel#hint{font:11px Consolas;color:#9bcbdf;}
            QLineEdit,QPlainTextEdit{background:#081d31;color:#d9f3ff;
                border:1px solid #3d789b;border-radius:3px;padding:8px;
                font:12px Consolas;}
            QPlainTextEdit{font:11px Consolas;}
            QCheckBox{color:#c6e8f3;}
            QPushButton{background:#133e5c;color:#e4f8ff;
                border:1px solid #5b91ae;border-radius:4px;padding:8px 12px;
                font:700 11px 'Segoe UI';min-height:28px;}
            QPushButton:disabled{background:#0d2737;color:#728e9c;border-color:#2c4a5d;}
            QPushButton:hover{background:#276684;}
            QProgressBar{border:1px solid #4a8cad;background:#082339;height:12px;}
            QProgressBar::chunk{background:#72cae8;}
        """)
        self.settings=QSettings("HDD-Project","HDD-System")
        self.worker=None
        self._activation=None
        self._handoff=None
        self._installed=None
        layout=QVBoxLayout(self)
        layout.setContentsMargins(22,18,22,20)
        layout.setSpacing(12)
        headline=QLabel("HELIOS / INSTALAÇÃO DE UNIDADE EXTERNA")
        headline.setObjectName("head")
        layout.addWidget(headline)
        caption=QLabel("PACKAGE: FAIRY.DESKTOP  //  INSTALAÇÃO LOCAL  //  SEM DADOS DO CRIADOR")
        caption.setObjectName("hint")
        layout.addWidget(caption)
        self.state=QLabel("Carregando dados do módulo...")
        self.state.setWordWrap(True)
        layout.addWidget(self.state)
        path_line=QHBoxLayout()
        self.path=QLineEdit()
        self.path.setObjectName("fairyTarget")
        candidate=self.settings.value("fairy_install_target",str(default_target()))
        self.path.setText(str(candidate))
        self.path.textChanged.connect(self._check_state)
        path_line.addWidget(self.path,1)
        browse=QPushButton("ESCOLHER PASTA")
        browse.clicked.connect(self._choose)
        self.browse=browse
        path_line.addWidget(browse)
        layout.addLayout(path_line)
        self.notice=QLabel(
            "A instalação real cria uma pasta separada, instala bibliotecas Python e "
            "pode baixar o Chromium. Não copia APIs, voz confiável, histórico ou "
            "configurações da Fairy original. Sua confirmação é necessária."
        )
        self.notice.setWordWrap(True)
        layout.addWidget(self.notice)
        self.progress=QProgressBar()
        self.progress.setRange(0,1)
        self.progress.setValue(0)
        layout.addWidget(self.progress)
        self.logs=QPlainTextEdit()
        self.logs.setReadOnly(True)
        self.logs.setObjectName("fairyInstallLog")
        self.logs.setPlaceholderText("Log do instalador aparecerá aqui; chaves de API não são solicitadas neste painel.")
        self.logs.setMaximumBlockCount(700)
        layout.addWidget(self.logs,1)
        first_line=QHBoxLayout()
        self.install=QPushButton("INSTALAR FAIRY DE FÁBRICA")
        self.install.setObjectName("fairyRealInstall")
        self.install.clicked.connect(self._install_now)
        first_line.addWidget(self.install,2)
        self.cancel=QPushButton("INTERROMPER")
        self.cancel.clicked.connect(self._cancel)
        self.cancel.setEnabled(False)
        first_line.addWidget(self.cancel)
        layout.addLayout(first_line)

        second_line=QHBoxLayout()
        self.language=QPushButton("CONFIGURAR IDIOMA")
        self.language.clicked.connect(lambda:self._configure("language"))
        self.providers=QPushButton("CONFIGURAR PROVEDORES")
        self.providers.clicked.connect(lambda:self._configure("providers"))
        self.activation=QPushButton("REBOOT + INICIAR FAIRY")
        self.activation.setObjectName("fairyFirstActivationButton")
        self.activation.clicked.connect(self._activate)
        for button in (self.language,self.providers,self.activation):
            second_line.addWidget(button)
        layout.addLayout(second_line)
        self.fish=QPushButton("CONFIGURAR FISH AUDIO / VOZ  //  OBRIGATÓRIO")
        self.fish.setObjectName("fairyRequiredFishAudio")
        self.fish.setToolTip("Selecione Fish Audio, configure a chave e escolha uma voz antes do Reboot.")
        self.fish.clicked.connect(lambda:self._configure("fish"))
        layout.addWidget(self.fish)
        self.advanced=QPushButton("CONFIGURAÇÃO AVANÇADA // SISTEMAS OPCIONAIS")
        self.advanced.setObjectName("fairyAdvancedSetup")
        self.advanced.clicked.connect(lambda:self._configure("advanced"))
        layout.addWidget(self.advanced)
        # Gate becomes available only when Fairy's saved settings actually
        # contain a complete language profile and an enabled AI provider.
        # No self-confirmation checkbox or first-meeting spoilers.
        self.activation.setEnabled(False)
        self.activation.setToolTip("Requires configured Gemini, Groq and Fish Audio.")
        self.setup_status=QLabel("HELIOS  //  CONFIGURAÇÃO PENDENTE")
        self.setup_status.setObjectName("hint")
        layout.addWidget(self.setup_status)
        close=QPushButton("VOLTAR AO NÚCLEO")
        close.clicked.connect(self.close)
        layout.addWidget(close)
        self._check_state()
        # Prime all static labels, buttons and hints before show(): factory
        # English must be the FIRST visible frame, never a PT flash.
        translate_before_first_paint(self)
        # Provider/language settings open as separate Fairy windows, so
        # the H.D.D. refreshes readiness after their Save actions.
        self._setup_timer=QTimer(self)
        self._setup_timer.setInterval(1600)
        self._setup_timer.timeout.connect(self._check_state)
        self._setup_timer.start()

    def _choose(self):
        result=QFileDialog.getExistingDirectory(
            self,"Escolher pasta PAI para criar Fairy-HDD",
            str(Path(self.path.text()).parent))
        if result:self.path.setText(str(Path(result)/"Fairy-HDD"))

    def _check_state(self,*_):
        if self.worker is not None and self.worker.isRunning():return
        try:
            target=check_target(self.path.text())
            self._installed=installed_state(target)
            validate_package(BUNDLED_PACKAGE)
            if self._installed:
                set_localized_text(self.state,"PACOTE INSTALADO // UNIDADE EXTERNA DETECTADA")
            elif target.exists():
                set_localized_text(self.state,"INSTALAÇÃO PARCIAL // RETOMADA DISPONÍVEL")
            else:
                set_localized_text(self.state,"PACOTE DE FÁBRICA VERIFICADO // PRONTO PARA INSTALAR")
            ready,reason=readiness(target) if self._installed else (False,"INSTALLATION_REQUIRED")
            self._ready=ready
            labels={
                "READY":"HELIOS  //  UNIDADE EXTERNA PRONTA",
                "INSTALLATION_REQUIRED":"HELIOS  //  UNIDADE NÃO INSTALADA",
                "LANGUAGE_REQUIRED":"HELIOS  //  CONFIGURAÇÃO DE IDIOMA OBRIGATÓRIA",
                "PROVIDERS_REQUIRED":"HELIOS  //  APIS GEMINI + GROQ OBRIGATÓRIAS",
                "FISH_AUDIO_REQUIRED":"HELIOS  //  API FISH AUDIO + VOZ OBRIGATÓRIAS",
            }
            set_localized_text(self.setup_status,labels.get(reason,"HELIOS  //  CONFIGURAÇÃO PENDENTE"))
            self.install.setEnabled(not bool(self._installed))
            self.language.setEnabled(bool(self._installed))
            self.providers.setEnabled(bool(self._installed))
            self.fish.setEnabled(bool(self._installed))
            self.advanced.setEnabled(bool(self._installed))
            finished=bool(self._installed and activated(target))
            if finished:
                set_localized_text(self.activation,"START FAIRY")
                self.activation.setToolTip("Launch the installed Fairy normally, without the first-run movie.")
            else:
                set_localized_text(self.activation,"REBOOT + START FAIRY")
                self.activation.setToolTip("First activation only: cinematic reveal of the real Fairy.")
            self.activation.setEnabled(bool(self._installed and (ready or finished)))
        except (OSError,ValueError) as exc:
            set_localized_text(self.state,str(exc))
            self._installed=None
            self._ready=False
            set_localized_text(self.setup_status,"HELIOS  //  UNIDADE INDISPONÍVEL")
            self.install.setEnabled(False)
            self.language.setEnabled(False)
            self.providers.setEnabled(False)
            self.fish.setEnabled(False)
            self.advanced.setEnabled(False)
            self.activation.setEnabled(False)

    def _append(self,message):
        self.logs.appendPlainText(str(message))

    def _install_now(self):
        try:
            path=check_target(self.path.text())
            validate_package(BUNDLED_PACKAGE)
            if installed_state(path):
                self._check_state()
                return
        except (ValueError,OSError) as exc:
            QMessageBox.warning(self,"Instalação",str(exc))
            return
        answer=QMessageBox.question(
            self,"Instalar unidade externa?",
            "Instalar a Fairy nesta pasta? O processo instalará dependências "
            "e poderá baixar arquivos da internet. Não modifica a Fairy original.\n\n"
            +str(path),
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if answer!=QMessageBox.StandardButton.Yes:return
        self.settings.setValue("fairy_install_target",str(path))
        self._append("HELIOS / iniciando instalação REAL, autorizada pelo operador.")
        set_localized_text(self.state,"INSTALANDO... // NÃO ENCERRAR O H.D.D.")
        self.progress.setRange(0,0)
        self.install.setEnabled(False)
        self.browse.setEnabled(False)
        self.path.setEnabled(False)
        self.language.setEnabled(False)
        self.providers.setEnabled(False)
        self.fish.setEnabled(False)
        self.advanced.setEnabled(False)
        self.activation.setEnabled(False)
        self.cancel.setEnabled(True)
        worker=_InstallerThread(BUNDLED_PACKAGE,path,self)
        self.worker=worker
        worker.message.connect(self._append)
        worker.installed.connect(self._done)
        worker.failed.connect(self._failed)
        worker.finished.connect(self._worker_ended)
        worker.start()

    def _worker_ended(self):
        self.cancel.setEnabled(False)
        self.browse.setEnabled(True)
        self.path.setEnabled(True)
        self.progress.setRange(0,1)
        self.progress.setValue(1)
        self._check_state()

    def _done(self,target):
        self._append("INSTALAÇÃO CONCLUÍDA / "+target)
        self._check_state()

    def _failed(self,message):
        self._append("ERRO / "+message)
        QMessageBox.warning(self,"Fairy // Instalação",message[:650])

    def _cancel(self):
        if self.worker is not None and self.worker.isRunning():
            self._append("Solicitação de cancelamento. Encerrando instalador...")
            self.worker.cancel.set()
            self.cancel.setEnabled(False)

    def _configure(self,what):
        if not self._installed:
            self._check_state()
            return
        target=check_target(self.path.text())
        if not installed_state(target):
            self._check_state()
            return
        executable=target/".venv/Scripts/python.exe"
        commands={
            "language":[str(executable),"-m","fairy.ui.language_settings"],
            "providers":[str(executable),"tools/configure_ai_providers.py"],
            "fish":[str(executable),"-m","fairy.ui.hdd_preflight","--voice"],
            "advanced":[str(executable),"-m","fairy.ui.hdd_preflight"],
        }
        cmd=commands.get(what)
        if cmd is None:
            return
        if what=="fish":
            # The H.D.D. language is authoritative, and its factory default
            # is English. This detached Fairy process must not guess locale
            # from the assistant's microphone or spoken response language.
            lang=str(self.settings.value("interface_language","en-US"))
            if lang not in ("en-US","pt-BR","es-ES"):
                lang="en-US"
            cmd += ["--hdd-lang",lang]
        try:
            subprocess.Popen(cmd,cwd=str(target),
                 creationflags=getattr(subprocess,"CREATE_NEW_PROCESS_GROUP",0))
            self._append({
                "language":"LANGUAGE","providers":"AI PROVIDERS",
                "fish":"FISH AUDIO / VOICE", "advanced":"OPTIONAL SYSTEMS"}[what]
                +" / configuration window opened.")
        except OSError as exc:
            QMessageBox.warning(self,"Configuração indisponível",str(exc))

    def _prewarm_real_fairy(self):
        if self._handoff is None:
            raise RuntimeError("Fairy boot handoff not prepared.")
        self._handoff.prewarm()
        self._append("HELIOS / EXTERNAL MODULE PREPARED")

    def _after_boot(self):
        if self._handoff is None:return
        # HDD Loading has actually finished. The REAL Fairy owns the
        # fullscreen presentation and both recorded voice tracks.
        try:
            self._handoff.reveal()
            self._append("HELIOS / EXTERNAL INTELLIGENCE ONLINE")
            set_localized_text(self.state,"EXTERNAL LINK ESTABLISHED")
        except Exception as exc:
            QMessageBox.warning(self,"H.D.D. // EXTERNAL MODULE",str(exc))

    def _cancel_boot(self):
        if self._handoff is not None:
            self._handoff.cancel()

    def _activation_confirmed(self):
        # Called after Fairy's own real-window acknowledgment, never while
        # prewarming, installing or merely playing a cinematic preview.
        target=check_target(self.path.text())
        complete_activation(target)
        # Post-reboot default ON. An explicitly disabled preference remains OFF.
        default_fairy_after_activation(self.settings)
        self._check_state()

    def _launch_normal(self,target):
        if FairyHandoff._has_live_instance(target):
            set_localized_text(self.state,"FAIRY ALREADY RUNNING")
            return
        command=["cmd.exe","/d","/c",str(target/"start_fairy.bat")]
        subprocess.Popen(command,cwd=str(target),
                         creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        set_localized_text(self.state,"FAIRY STARTED")

    def _activate(self):
        # After the first confirmed activation, never run the cinematic again.
        target=check_target(self.path.text())
        if activated(target):
            try:self._launch_normal(target)
            except OSError as exc:
                QMessageBox.warning(self,"H.D.D. // FAIRY",str(exc))
            return
        ready,reason=readiness(target)
        if not ready:
            self._check_state()
            QMessageBox.information(
                self,"H.D.D. // EXTERNAL MODULE",
                "The external module is not configured yet. "
                "Complete language, Gemini, Groq, and Fish Audio voice/API "
                "configuration before initialization.")
            return
        # The REAL first activation alone uses a cinematic handoff.
        if self._activation is not None and self._activation.isVisible():
            return
        if not voice_pack_ready():
            QMessageBox.warning(
                self,"H.D.D. // EXTERNAL MODULE",
                "Required system resources are unavailable. "
                "Restore or update the H.D.D. before starting.")
            return
        choice=QMessageBox.question(
            self,"H.D.D. // EXTERNAL MODULE REBOOT",
            "Initialize the external intelligence module? "
            "Press Esc to cancel the startup sequence.",
            QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No)
        if choice!=QMessageBox.StandardButton.Yes:return
        self._handoff=FairyHandoff(target)
        self._activation=_ActivationPlayback(
            self.settings,self._handoff,
            self._after_boot,self._cancel_boot,self,
            on_confirm=self._activation_confirmed)
        self._activation.start()

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():
            QMessageBox.information(self,"Instalação em andamento",
                "Use INTERROMPER antes de fechar este painel para evitar arquivos incompletos.")
            event.ignore()
            return
        self._setup_timer.stop()
        super().closeEvent(event)
