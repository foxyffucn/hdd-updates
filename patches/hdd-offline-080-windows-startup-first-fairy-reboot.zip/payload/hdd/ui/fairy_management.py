"""Fairy Management: visible only when HDD installation is detected."""
from __future__ import annotations
from pathlib import Path
import subprocess
from PySide6.QtCore import Qt, QSettings, QThread, Signal
from PySide6.QtWidgets import (
    QWidget,QVBoxLayout,QHBoxLayout,QLabel,QFrame,QPushButton,
    QMessageBox,QInputDialog)
from hdd.ui.fairy_install_backend import default_target,installed_state
from hdd.ui.fairy_module_dialog import FairyUpdateDialog
from hdd.ui import windows_autostart
from hdd.ui.fairy_maintenance import (
    safe_install,cache_preview,clear_cache,reset_factory,
    uninstall_to_recycle_bin,MaintenanceError)

TEXT={
"en-US":{
"title":"FAIRY // MODULE MANAGEMENT","sub":"Installed external module • local controls",
 "status":"Installation","open":"OPEN FAIRY SETTINGS","cache":"CLEAR DISPOSABLE CACHE",
"updates":"CHECK FAIRY MODULE UPDATES",
"reset":"RESET TO FACTORY","uninstall":"UNINSTALL FAIRY","none":"Fairy is not installed.",
"preview":"Disposable cache: {files} files / {size:.1f} MiB.",
"confirm_cache":"Remove only Fairy logs and generated voice cache? Settings and chat stay untouched.",
"confirm_reset":"Factory reset moves personal data to a local private backup. API keys, voice enrollment, history and preferences will be reset. Type RESET FAIRY to confirm:",
"confirm_uninstall":"Move the complete installed Fairy to the Windows Recycle Bin (without touching the original Fairy project). Type UNINSTALL FAIRY to confirm:",
"busy":"Close the Fairy before maintenance.","done":"Operation completed.","fail":"Operation failed: ","saved":"Personal-data backup: ","running":"Maintenance in progress..."
},
"pt-BR":{
"title":"FAIRY // GERENCIAMENTO","sub":"Módulo externo instalado • controles locais",
 "status":"Instalação","open":"ABRIR CONFIGURAÇÕES DA FAIRY","cache":"LIMPAR CACHE DESCARTÁVEL",
"updates":"VERIFICAR ATUALIZAÇÕES DA FAIRY",
"reset":"RESTAURAR PADRÃO DE FÁBRICA","uninstall":"DESINSTALAR FAIRY","none":"Fairy não está instalada.",
"preview":"Cache descartável: {files} arquivos / {size:.1f} MiB.",
"confirm_cache":"Remover apenas logs e cache de voz gerado? Configurações e conversas serão mantidas.",
"confirm_reset":"Os dados pessoais serão movidos para um backup local. Chaves, histórico, Voice Trust e preferências serão zerados. Digite RESET FAIRY:",
"confirm_uninstall":"Enviar a instalação da Fairy para a Lixeira do Windows, sem tocar no projeto original. Digite UNINSTALL FAIRY:",
"busy":"Feche a Fairy antes da manutenção.","done":"Operação concluída.","fail":"Falha: ","saved":"Backup dos dados: ","running":"Manutenção em andamento..."
},
"es-ES":{
"title":"FAIRY // ADMINISTRACIÓN","sub":"Módulo externo instalado • controles locales",
 "status":"Instalación","open":"ABRIR AJUSTES DE FAIRY","cache":"LIMPIAR CACHÉ DESCARTABLE",
"updates":"BUSCAR ACTUALIZACIONES DE FAIRY",
"reset":"RESTABLECER DE FÁBRICA","uninstall":"DESINSTALAR FAIRY","none":"Fairy no está instalada.",
"preview":"Caché descartable: {files} archivos / {size:.1f} MiB.",
"confirm_cache":"¿Eliminar solo registros y caché de voz generado? Los ajustes y chats se conservarán.",
"confirm_reset":"Los datos personales se guardarán en una copia local. Se restablecerán claves, historial, Voice Trust y preferencias. Escribe RESET FAIRY:",
"confirm_uninstall":"Enviar Fairy a la Papelera de Windows, sin tocar el proyecto original. Escribe UNINSTALL FAIRY:",
"busy":"Cierra Fairy antes del mantenimiento.","done":"Operación terminada.","fail":"Error: ","saved":"Copia privada: ","running":"Mantenimiento en curso..."
}
}

class MaintenanceWorker(QThread):
    finished_result=Signal(bool,str)
    def __init__(self,path,kind,parent=None):
        super().__init__(parent);self.path=Path(path);self.kind=kind
    def run(self):
        try:
            if self.kind=="cache":
                count,bytes_=clear_cache(self.path)
                result=f"Cleared {count} files ({bytes_/1048576:.1f} MiB)."
            elif self.kind=="reset":
                result="Backup: "+str(reset_factory(self.path))
            elif self.kind=="uninstall":
                uninstall_to_recycle_bin(self.path)
                result="Fairy moved to Windows Recycle Bin."
            else:raise MaintenanceError("Unknown operation.")
            self.finished_result.emit(True,result)
        except Exception as exc:
            self.finished_result.emit(False,str(exc)[:350])

class FairyManagementPage(QWidget):
    installation_changed=Signal()
    def __init__(self,settings,parent=None):
        super().__init__(parent)
        self.settings=settings
        self.worker=None
        self._update_panel=None
        self.setObjectName("fairyManagerPage")
        self.setStyleSheet("""
            QWidget#fairyManagerPage{background:transparent;color:#d8f5ff;}
            QFrame#fairyManageCard{background:#0c283d;border:1px solid #315f79;border-radius:6px;}
            QLabel{color:#d8f4ff;background:transparent;font:12px 'Segoe UI';}
            QLabel#fairyManagerHead{font:700 22px 'Segoe UI';color:#a6e6ff;}
            QLabel#fairyManagerSub{color:#7dbed5;font:11px Consolas;}
            QPushButton{background:#17425b;border:1px solid #3c7c99;border-radius:4px;
              color:#e0f6ff;padding:11px;font:600 12px 'Segoe UI';min-height:24px;}
            QPushButton:hover{background:#24607b;}
            QPushButton:disabled{background:#0d293a;color:#678da2;}
            QPushButton#factoryDanger{border-color:#b47974;}
        """)
        layout=QVBoxLayout(self);layout.setContentsMargins(18,12,18,12);layout.setSpacing(13)
        self.head=QLabel();self.head.setObjectName("fairyManagerHead");layout.addWidget(self.head)
        self.sub=QLabel();self.sub.setObjectName("fairyManagerSub");layout.addWidget(self.sub)
        card=QFrame();card.setObjectName("fairyManageCard")
        inside=QVBoxLayout(card);inside.setContentsMargins(21,21,21,21);inside.setSpacing(13)
        self.status=QLabel();self.status.setWordWrap(True);inside.addWidget(self.status)
        self.cache_info=QLabel();inside.addWidget(self.cache_info)
        self.open=QPushButton();self.open.clicked.connect(self.open_settings);inside.addWidget(self.open)
        self.updates=QPushButton();self.updates.clicked.connect(self.open_updates);inside.addWidget(self.updates)
        self.cache=QPushButton();self.cache.clicked.connect(lambda:self.request("cache"));inside.addWidget(self.cache)
        self.reset=QPushButton();self.reset.setObjectName("factoryDanger")
        self.reset.clicked.connect(lambda:self.request("reset"));inside.addWidget(self.reset)
        self.remove=QPushButton();self.remove.setObjectName("factoryDanger")
        self.remove.clicked.connect(lambda:self.request("uninstall"));inside.addWidget(self.remove)
        layout.addWidget(card)
        self.message=QLabel("");self.message.setWordWrap(True);layout.addWidget(self.message)
        layout.addStretch()
        self.set_language(str(settings.value("interface_language","en-US")))
        self.refresh()

    def target(self):
        return Path(str(self.settings.value("fairy_install_target",str(default_target()))))

    def set_language(self,code):
        self.lang=code if code in TEXT else "en-US"
        t=TEXT[self.lang]
        self.head.setText(t["title"]);self.sub.setText(t["sub"])
        for attr,key in (("open","open"),("updates","updates"),
                         ("cache","cache"),("reset","reset"),("remove","uninstall")):
            getattr(self,attr).setText(t[key])
        self.refresh()
        if self._update_panel is not None:
            self._update_panel.apply_language(self.lang)

    def refresh(self):
        active=bool(installed_state(self.target()))
        disabled=self.worker is not None and self.worker.isRunning()
        for item in (self.open,self.updates,self.cache,self.reset,self.remove):
            item.setEnabled(active and not disabled)
        self.status.setText(TEXT[self.lang]["status"]+": "+(str(self.target()) if active else TEXT[self.lang]["none"]))
        if active:
            try:
                count,bytes_=cache_preview(self.target())
                self.cache_info.setText(TEXT[self.lang]["preview"].format(files=count,size=bytes_/1048576))
            except Exception:self.cache_info.setText("")
        else:self.cache_info.setText("")

    def open_settings(self):
        try:
            root=safe_install(self.target())
            exe=root/".venv/Scripts/pythonw.exe"
            if not exe.is_file():exe=root/".venv/Scripts/python.exe"
            if not exe.is_file():raise MaintenanceError("Fairy runtime unavailable.")
            subprocess.Popen([str(exe),"-m","fairy.ui.hdd_preflight"],cwd=str(root),
                             creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        except Exception as exc:
            QMessageBox.warning(self,"FAIRY",str(exc))

    def open_updates(self,auto=False):
        if not installed_state(self.target()):return
        panel=self._update_panel
        if panel is not None:
            if not auto:
                panel.show();panel.raise_()
                panel.check_now()
            return
        panel=FairyUpdateDialog(self.target(),self.settings,self.lang,auto=auto,parent=self)
        self._update_panel=panel
        panel.finished.connect(lambda _result,p=panel:self._forget_update_panel(p))
        if not auto:
            panel.show()
        # Auto-check starts on the worker shortly after creation.

    def _forget_update_panel(self,panel):
        if self._update_panel is panel:
            self._update_panel=None
        panel.deleteLater()

    def auto_check_updates_once(self):
        if not self.settings.value("updates_auto_check",True,type=bool):
            return
        if not self.settings.value("fairy_updates_auto_check",True,type=bool):
            return
        from hdd.ui.fairy_module_dialog import feed_url
        if installed_state(self.target()) and feed_url(self.settings):
            self.open_updates(auto=True)

    def request(self,kind):
        if self.worker is not None and self.worker.isRunning():return
        t=TEXT[self.lang]
        if kind=="cache":
            if QMessageBox.question(self,t["title"],t["confirm_cache"],
                QMessageBox.StandardButton.Yes|QMessageBox.StandardButton.No)!=QMessageBox.StandardButton.Yes:return
        else:
            phrase="RESET FAIRY" if kind=="reset" else "UNINSTALL FAIRY"
            answer,ok=QInputDialog.getText(self,t["title"],t["confirm_"+("reset" if kind=="reset" else "uninstall")])
            if not ok or answer.strip()!=phrase:return
        self.worker=MaintenanceWorker(self.target(),kind,self)
        worker=self.worker
        worker.finished_result.connect(self.finished)
        worker.finished.connect(lambda w=worker:self._worker_done(w))
        worker.start()
        self.message.setText(t["running"])
        self.refresh()

    def _worker_done(self,worker):
        # QThread.finished has fired. Drop the Python reference before Qt
        # deletes its C++ object, or the next periodic refresh can crash.
        if self.worker is worker:
            self.worker=None
        worker.deleteLater()
        self.refresh()

    def finished(self,success,result):
        self.message.setText((TEXT[self.lang]["done"]+" " if success else TEXT[self.lang]["fail"])+result)
        # A reset/uninstall removes the per-install activation marker.
        # Never leave a Windows startup command targeting an unconfigured
        # or removed Fairy. A future successful Reboot defaults to ON anew.
        if success and self.worker is not None and self.worker.kind in ("reset","uninstall"):
            try:
                windows_autostart.set_fairy_enabled(self.settings,False)
                self.settings.remove(windows_autostart.FAIRY_CHOICE_SET)
                self.settings.remove(windows_autostart.FAIRY_PREF)
                self.settings.sync()
            except (OSError,RuntimeError) as exc:
                self.message.setText(self.message.text()+"  /  Windows startup: "+str(exc))
        self.installation_changed.emit()

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():
            self.message.setText(TEXT[self.lang]["running"])
            event.ignore()
            return
        super().closeEvent(event)
