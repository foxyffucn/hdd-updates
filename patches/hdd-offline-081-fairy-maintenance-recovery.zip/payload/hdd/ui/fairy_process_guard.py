"""Safety-scoped shutdown for the INSTALLED Fairy runtime only.

No arbitrary process names, no other Fairy development project, no global
python/node kill. The GUI must get separate consent before force=True.
"""
from __future__ import annotations
import ctypes
from ctypes import wintypes
from pathlib import Path
import os,time,subprocess

class FairyBusyError(RuntimeError):pass

def _exe_pids(root):
    if os.name!="nt":return []
    root=Path(root).resolve()
    expected={os.path.normcase(str(root/".venv/Scripts/python.exe")),
              os.path.normcase(str(root/".venv/Scripts/pythonw.exe"))}
    psapi=ctypes.WinDLL("psapi",use_last_error=True)
    kernel=ctypes.WinDLL("kernel32",use_last_error=True)
    enum=psapi.EnumProcesses
    enum.argtypes=[ctypes.POINTER(wintypes.DWORD),wintypes.DWORD,
                   ctypes.POINTER(wintypes.DWORD)]
    enum.restype=wintypes.BOOL
    openprocess=kernel.OpenProcess
    openprocess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD]
    openprocess.restype=wintypes.HANDLE
    query=kernel.QueryFullProcessImageNameW
    query.argtypes=[wintypes.HANDLE,wintypes.DWORD,wintypes.LPWSTR,
                    ctypes.POINTER(wintypes.DWORD)]
    query.restype=wintypes.BOOL
    close=kernel.CloseHandle
    close.argtypes=[wintypes.HANDLE];close.restype=wintypes.BOOL
    length=4096
    pids=(wintypes.DWORD*length)()
    length_out=wintypes.DWORD()
    if not enum(pids,ctypes.sizeof(pids),ctypes.byref(length_out)):
        raise FairyBusyError("Could not inspect running Fairy processes.")
    matches=[]
    for pid in pids[:length_out.value//ctypes.sizeof(wintypes.DWORD)]:
        if not pid or pid==os.getpid():continue
        handle=openprocess(0x1000,False,pid)
        if not handle:continue
        try:
            buf=ctypes.create_unicode_buffer(32768)
            length=wintypes.DWORD(len(buf))
            if query(handle,0,buf,ctypes.byref(length)) and os.path.normcase(buf.value) in expected:
                matches.append(int(pid))
        finally:close(handle)
    return sorted(set(matches))

def _request_window_close(pids):
    if not pids or os.name!="nt":return
    user32=ctypes.WinDLL("user32",use_last_error=True)
    GetWindowThreadProcessId=user32.GetWindowThreadProcessId
    GetWindowThreadProcessId.argtypes=[wintypes.HWND,ctypes.POINTER(wintypes.DWORD)]
    GetWindowThreadProcessId.restype=wintypes.DWORD
    PostMessage=user32.PostMessageW
    PostMessage.argtypes=[wintypes.HWND,wintypes.UINT,wintypes.WPARAM,wintypes.LPARAM]
    PostMessage.restype=wintypes.BOOL
    Callback=ctypes.WINFUNCTYPE(wintypes.BOOL,wintypes.HWND,wintypes.LPARAM)
    expected=set(pids)
    def cb(hwnd,_):
        pid=wintypes.DWORD()
        GetWindowThreadProcessId(hwnd,ctypes.byref(pid))
        if pid.value in expected:
            PostMessage(hwnd,0x0010,0,0) # WM_CLOSE, cooperative
        return True
    proc=Callback(cb)
    user32.EnumWindows.argtypes=[Callback,wintypes.LPARAM]
    user32.EnumWindows(proc,0)

def close_for_maintenance(root,*,force=False,timeout=4):
    """Try graceful window-close first; do NOT force unless explicitly approved."""
    pids=_exe_pids(root)
    if not pids:return
    _request_window_close(pids)
    until=time.monotonic()+timeout
    while time.monotonic()<until:
        if not _exe_pids(root):return
        time.sleep(.2)
    remaining=_exe_pids(root)
    if remaining and not force:
        raise FairyBusyError("Fairy is still running (PID "+", ".join(map(str,remaining))+
            "). Close Fairy or choose FORCE CLOSE FAIRY and retry.")
    if remaining:
        # PID may have changed: re-check exact per-install executable path.
        targets=set(_exe_pids(root))
        for pid in remaining:
            if pid not in targets:continue
            proc=subprocess.run(["taskkill","/PID",str(pid),"/T","/F"],
                                capture_output=True,text=True,timeout=12,
                                creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            if proc.returncode and pid in _exe_pids(root):
                raise FairyBusyError("Windows could not stop Fairy PID "+str(pid))
        end=time.monotonic()+5
        while time.monotonic()<end:
            if not _exe_pids(root):return
            time.sleep(.2)
    if _exe_pids(root):
        raise FairyBusyError("Fairy remains open. No personal files were changed.")
