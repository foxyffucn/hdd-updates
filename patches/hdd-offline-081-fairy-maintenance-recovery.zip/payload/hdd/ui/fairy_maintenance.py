"""Fairy maintenance v2: scoped shutdown, transactional reset, Recycle Bin.

Operations only target the H.D.D.-installed Fairy, never the original
development source. Backups and user data are never permanently deleted
as an undocumented fallback.
"""
from __future__ import annotations
from pathlib import Path
from datetime import datetime
import ctypes,os,shutil,subprocess
from hdd.paths import project_root
from hdd.ui.fairy_install_backend import installed_state
from hdd.ui.fairy_process_guard import close_for_maintenance,FairyBusyError

class MaintenanceError(RuntimeError):pass

def safe_install(folder):
    raw=Path(folder).expanduser()
    if raw.is_symlink() or not raw.is_dir():
        raise MaintenanceError("Fairy installation folder is missing or linked.")
    folder=raw.resolve(strict=True)
    hdd=Path(project_root()).resolve()
    if (folder in (Path.home().resolve(),Path(folder.anchor),hdd)
        or folder.is_relative_to(hdd) or hdd.is_relative_to(folder)):
        raise MaintenanceError("Protected system folder.")
    if folder.name=="Fairy_v1_4_0_EdgeTTS_PRIVATE":
        raise MaintenanceError("Original Fairy development project is protected.")
    if not installed_state(folder):
        raise MaintenanceError("No valid H.D.D.-installed Fairy at this location.")
    return folder

def approved(base,path):
    path=Path(path)
    if not path.is_relative_to(base) or path.is_symlink():
        raise MaintenanceError("Unsafe linked file or folder.")
    for parent in path.parents:
        if parent==base:break
        if parent.is_symlink():
            raise MaintenanceError("Unsafe linked directory.")
    return path

def _prepare(folder,force):
    root=safe_install(folder)
    close_for_maintenance(root,force=force)
    return root

def cache_dirs(root):
    # Never touch voice trust, saved chats, API settings, user thumbnails or
    # persistent voices: these are NOT disposable caches.
    return (root/"logs",root/"userdata/voice_cache")

def cache_preview(folder):
    root=safe_install(folder)
    files=0;size=0
    for area in cache_dirs(root):
        approved(root,area)
        if not area.exists():continue
        for here,dirs,names in os.walk(area,followlinks=False):
            for dirname in dirs:approved(root,Path(here)/dirname)
            for name in names:
                f=approved(root,Path(here)/name)
                if not f.is_file():raise MaintenanceError("Unexpected cache entry.")
                files+=1;size+=f.stat().st_size
    return files,size

def clear_cache(folder,*,force_close=False):
    root=_prepare(folder,force_close)
    stats=cache_preview(root)
    errors=[]
    # Delete ONLY verified disposable files. If anything is still locked,
    # report partial cleanup instead of claiming everything succeeded.
    for area in cache_dirs(root):
        if not area.exists():continue
        approved(root,area)
        for here,dirs,names in os.walk(area,topdown=False,followlinks=False):
            for name in names:
                target=approved(root,Path(here)/name)
                try:target.unlink()
                except OSError as exc:errors.append(f"{target.name}: {exc.strerror or exc}")
            for name in dirs:
                target=approved(root,Path(here)/name)
                try:target.rmdir()
                except OSError as exc:errors.append(f"{target.name}: {exc.strerror or exc}")
    if errors:
        raise MaintenanceError(
            f"Some disposable files remain ({len(errors)}). First failure: {errors[0]}. "
            "Close any Fairy helper processes and retry.")
    return stats

def reset_factory(folder,*,force_close=False):
    root=_prepare(folder,force_close)
    status=root/"userdata/factory_install_status.json"
    if not status.is_file() or status.is_symlink():
        raise MaintenanceError("Factory installation record is missing.")
    backup_parent=root.parent/(root.name+"-Personal-Backups")
    if backup_parent.is_symlink():raise MaintenanceError("Backup folder is linked.")
    backup_parent.mkdir(mode=0o700,exist_ok=True)
    dest=backup_parent/("factory-reset-"+datetime.now().strftime("%Y%m%d_%H%M%S_%f"))
    dest.mkdir(mode=0o700)
    names=("userdata","logs",".env")
    moved=[]
    created=[]
    try:
        # Preserve originals by atomic, same-volume MOVE into backup.
        # Never copy/move the user's private files to a public project.
        for name in names:
            old=root/name
            if old.exists():
                approved(root,old)
                if (dest/name).exists():raise MaintenanceError("Backup destination collision.")
                os.replace(old,dest/name)
                moved.append(name)
        (root/"userdata").mkdir()
        created.append(root/"userdata")
        shutil.copy2(dest/"userdata/factory_install_status.json",status)
        (root/"logs").mkdir()
        created.append(root/"logs")
        if not installed_state(root):
            raise MaintenanceError("Factory reset could not preserve the installation.")
    except Exception as exc:
        # Rollback BEFORE returning any failure. Only delete the newly created
        # status file / empty folders; never recursively remove user data.
        try:
            if status.exists() and "userdata" in moved:
                status.unlink()
            for fresh in reversed(created):
                if fresh.is_dir():fresh.rmdir()
            for name in reversed(moved):
                if (root/name).exists():
                    raise MaintenanceError("Rollback blocked by a new file in "+str(root/name))
                os.replace(dest/name,root/name)
        except Exception as rollback_exc:
            raise MaintenanceError(
                "Reset interrupted. Original data are preserved at "+str(dest)+
                ". Automatic rollback was blocked: "+str(rollback_exc)) from exc
        raise MaintenanceError("Factory reset stopped safely: "+str(exc)) from exc
    return dest

def _shell_recycle(root):
    if os.name!="nt":raise MaintenanceError("Windows Recycle Bin is required.")
    from ctypes import wintypes
    class Op(ctypes.Structure):
        _fields_=[("hwnd",wintypes.HWND),("wFunc",wintypes.UINT),
                  ("pFrom",wintypes.LPCWSTR),("pTo",wintypes.LPCWSTR),
                  ("fFlags",wintypes.WORD),("fAnyOperationsAborted",wintypes.BOOL),
                  ("hNameMappings",wintypes.LPVOID),
                  ("lpszProgressTitle",wintypes.LPCWSTR)]
    name=ctypes.create_unicode_buffer(str(root)+"\0\0")
    op=Op()
    op.wFunc=3                 # FO_DELETE
    op.pFrom=ctypes.cast(name,wintypes.LPCWSTR)
    op.fFlags=0x0040|0x0010|0x0004|0x0400  # ALLOWUNDO, SILENT, NOCONFIRM, NOERRORUI
    shell32=ctypes.WinDLL("shell32",use_last_error=True)
    shell32.SHFileOperationW.argtypes=[ctypes.POINTER(Op)]
    shell32.SHFileOperationW.restype=ctypes.c_int
    result=shell32.SHFileOperationW(ctypes.byref(op))
    return result==0 and not bool(op.fAnyOperationsAborted) and not root.exists()

def _visualbasic_recycle(root):
    """Windows .NET fallback, no permanent-deletion fallback."""
    # Pass location through Base64, never interpolate an untrusted path into
    # PowerShell source code.
    import base64
    encoded=base64.b64encode(str(root).encode("utf-16le")).decode("ascii")
    script=(
       "Add-Type -AssemblyName Microsoft.VisualBasic;"
       "$p=[Text.Encoding]::Unicode.GetString([Convert]::FromBase64String('"+encoded+"'));"
       "[Microsoft.VisualBasic.FileIO.FileSystem]::DeleteDirectory("
       "$p,[Microsoft.VisualBasic.FileIO.UIOption]::OnlyErrorDialogs,"
       "[Microsoft.VisualBasic.FileIO.RecycleOption]::SendToRecycleBin,"
       "[Microsoft.VisualBasic.FileIO.UICancelOption]::ThrowException)"
    )
    p=subprocess.run(
       ["powershell.exe","-NoProfile","-NonInteractive","-Command",script],
       capture_output=True,text=True,timeout=90,
       creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
    return p.returncode==0 and not root.exists()

def uninstall_to_recycle_bin(folder,*,force_close=False):
    root=_prepare(folder,force_close)
    if _shell_recycle(root):return True
    # Some Win10 systems return an unsuccessful SHFileOperation despite
    # the item being movable to the bin through the .NET Shell API.
    if root.exists() and _visualbasic_recycle(root):return True
    raise MaintenanceError(
        "Windows could not move Fairy to the Recycle Bin. "
        "No permanent deletion was attempted. Check open processes and "
        "folder permissions, then retry.")
