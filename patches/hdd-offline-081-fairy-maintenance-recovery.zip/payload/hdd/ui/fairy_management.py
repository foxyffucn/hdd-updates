"""Fairy Management: visible only when HDD installation is detected."""
from __future__ import annotations
from pathlib import Path
import subprocess
from PySide6.QtCore import Qt, QSettings, QThread, Signal, QTimer
from PySide6.QtWidgets import (
    QWidget,QVBoxLayout,QHBoxLayout,QLabel,QFrame,QPushButton,
    QMessageBox)
from hdd.ui.fairy_install_backend import default_target,installed_state
from hdd.ui.fairy_module_dialog import FairyUpdateDialog
from hdd.ui import windows_autostart
from hdd.ui.fairy_maintenance import (
    safe_install,cache_preview,clear_cache,reset_factory,
    uninstall_to_recycle_bin,MaintenanceError)
from hdd.ui.fairy_process_guard import FairyBusyError

TEXT={
"en-US":{
"title":"FAIRY // MODULE MANAGEMENT","sub":"Installed external module • local controls",
 "status":"Installation","open":"OPEN FAIRY SETTINGS","cache":"CLEAR DISPOSABLE CACHE",
"updates":"CHECK FAIRY MODULE UPDATES",
"reset":"RESET TO FACTORY","uninstall":"UNINSTALL FAIRY","none":"Fairy is not installed.",
"preview":"Disposable cache: {files} files / {size:.1f} MiB.",
"confirm_cache":"Remove only Fairy logs and generated voice cache? Settings and chat stay untouched.",
"confirm_reset":"Fairy will be closed and its personal data moved to a private local backup. API keys, voice enrollment, chat history, and preferences will be reset. Continue?",
"confirm_uninstall":"Move the installed Fairy to the Windows Recycle Bin? The original developer project will not be touched. No permanent deletion will be used.",
"busy":"Close the Fairy before maintenance.","done":"Operation completed.","fail":"Operation failed: ","saved":"Personal-data backup: ","running":"Maintenance in progress..."
},
"pt-BR":{
"title":"FAIRY // GERENCIAMENTO","sub":"Módulo externo instalado • controles locais",
 "status":"Instalação","open":"ABRIR CONFIGURAÇÕES DA FAIRY","cache":"LIMPAR CACHE DESCARTÁVEL",
"updates":"VERIFICAR ATUALIZAÇÕES DA FAIRY",
"reset":"RESTAURAR PADRÃO DE FÁBRICA","uninstall":"DESINSTALAR FAIRY","none":"Fairy não está instalada.",
"preview":"Cache descartável: {files} arquivos / {size:.1f} MiB.",
"confirm_cache":"Remover apenas logs e cache de voz gerado? Configurações e conversas serão mantidas.",
"confirm_reset":"Fechar a Fairy e mover os dados pessoais para um backup privado local? Chaves, histórico, Voice Trust e preferências serão zerados.",
"confirm_uninstall":"Enviar a Fairy instalada para a Lixeira do Windows? O projeto original não será alterado. Nenhuma exclusão permanente será feita.",
"busy":"Feche a Fairy antes da manutenção.","done":"Operação concluída.","fail":"Falha: ","saved":"Backup dos dados: ","running":"Manutenção em andamento..."
},
"es-ES":{
"title":"FAIRY // ADMINISTRACIÓN","sub":"Módulo externo instalado • controles locales",
 "status":"Instalación","open":"ABRIR AJUSTES DE FAIRY","cache":"LIMPIAR CACHÉ DESCARTABLE",
"updates":"BUSCAR ACTUALIZACIONES DE FAIRY",
"reset":"RESTABLECER DE FÁBRICA","uninstall":"DESINSTALAR FAIRY","none":"Fairy no está instalada.",
"preview":"Caché descartable: {files} archivos / {size:.1f} MiB.",
"confirm_cache":"¿Eliminar solo registros y caché de voz generado? Los ajustes y chats se conservarán.",
"confirm_reset":"Cerrar Fairy y mover sus datos personales a una copia privada local? Se restablecerán claves, historial, Voice Trust y preferencias.",
"confirm_uninstall":"¿Mover la Fairy instalada a la Papelera de Windows? El proyecto original no se modificará. No se eliminará permanentemente.",
"busy":"Cierra Fairy antes del mantenimiento.","done":"Operación terminada.","fail":"Error: ","saved":"Copia privada: ","running":"Mantenimiento en curso..."
}
}

class MaintenanceWorker(QThread):
    finished_result=Signal(str,str)
    def __init__(self,path,kind,force_close=False,parent=None):
        super().__init__(parent)
        self.path=Path(path)
        self.kind=kind
        self.force_close=bool(force_close)

    def run(self):
        try:
            if self.kind=="cache":
                count,bytes_=clear_cache(self.path,force_close=self.force_close)
                result=f"Cleared {count} files ({bytes_/1048576:.1f} MiB)."
            elif self.kind=="reset":
                result="Private backup: "+str(reset_factory(self.path,force_close=self.force_close))
            elif self.kind=="uninstall":
                uninstall_to_recycle_bin(self.path,force_close=self.force_close)
                result="Fairy moved to the Windows Recycle Bin."
            else:
                raise MaintenanceError("Unknown maintenance operation.")
            self.finished_result.emit("ok",result)
        except FairyBusyError as exc:
            self.finished_result.emit("busy",str(exc)[:420])
        except Exception as exc:
            self.finished_result.emit("error",str(exc)[:420])

class FairyManagementPage(QWidget):
    installation_changed=Signal()
    def __init__(self,settings,parent=None):
        super().__init__(parent)
        self.settings=settings
        self.worker=None
        self._pending_force=None
        self._update_panel=None
        self.setObjectName("fairyManagerPage")
        self.setStyleSheet("""
            QWidget#fairyManagerPage{background:transparent;color:#d8f5ff;}
            QFrame#fairyManageCard{background:#0c283d;border:1px solid #315f79;border-radius:6px;}
            QLabel{color:#d8f4ff;background:transparent;font:12px 'Segoe UI';}
            QLabel#fairyManagerHead{font:700 22px 'Segoe UI';color:#a6e6ff;}
            QLabel#fairyManagerSub{color:#7dbed5;font:11px Consolas;}
            QPushButton{background:#17425b;border:1px solid #3c7c99;border-radius:4px;
              color:#e0f6ff;padding:11px;font:600 12px 'Segoe UI';min-height:24px;}
            QPushButton:hover{background:#24607b;}
            QPushButton:disabled{background:#0d293a;color:#678da2;}
            QPushButton#factoryDanger{border-color:#b47974;}
        """)
        layout=QVBoxLayout(self);layout.setContentsMargins(18,12,18,12);layout.setSpacing(13)
        self.head=QLabel();self.head.setObjectName("fairyManagerHead");layout.addWidget(self.head)
        self.sub=QLabel();self.sub.setObjectName("fairyManagerSub");layout.addWidget(self.sub)
        card=QFrame();card.setObjectName("fairyManageCard")
        inside=QVBoxLayout(card);inside.setContentsMargins(21,21,21,21);inside.setSpacing(13)
        self.status=QLabel();self.status.setWordWrap(True);inside.addWidget(self.status)
        self.cache_info=QLabel();inside.addWidget(self.cache_info)
        self.open=QPushButton();self.open.clicked.connect(self.open_settings);inside.addWidget(self.open)
        self.updates=QPushButton();self.updates.clicked.connect(self.open_updates);inside.addWidget(self.updates)
        self.cache=QPushButton();self.cache.clicked.connect(lambda:self.request("cache"));inside.addWidget(self.cache)
        self.reset=QPushButton();self.reset.setObjectName("factoryDanger")
        self.reset.clicked.connect(lambda:self.request("reset"));inside.addWidget(self.reset)
        self.remove=QPushButton();self.remove.setObjectName("factoryDanger")
        self.remove.clicked.connect(lambda:self.request("uninstall"));inside.addWidget(self.remove)
        layout.addWidget(card)
        self.message=QLabel("");self.message.setWordWrap(True);layout.addWidget(self.message)
        layout.addStretch()
        self.set_language(str(settings.value("interface_language","en-US")))
        self.refresh()

    def target(self):
        return Path(str(self.settings.value("fairy_install_target",str(default_target()))))

    def set_language(self,code):
        self.lang=code if code in TEXT else "en-US"
        t=TEXT[self.lang]
        self.head.setText(t["title"]);self.sub.setText(t["sub"])
        for attr,key in (("open","open"),("updates","updates"),
                         ("cache","cache"),("reset","reset"),("remove","uninstall")):
            getattr(self,attr).setText(t[key])
        self.refresh()
        if self._update_panel is not None:
            self._update_panel.apply_language(self.lang)

    def refresh(self):
        active=bool(installed_state(self.target()))
        disabled=self.worker is not None and self.worker.isRunning()
        for item in (self.open,self.updates,self.cache,self.reset,self.remove):
            item.setEnabled(active and not disabled)
        self.status.setText(TEXT[self.lang]["status"]+": "+(str(self.target()) if active else TEXT[self.lang]["none"]))
        if active:
            try:
                count,bytes_=cache_preview(self.target())
                self.cache_info.setText(TEXT[self.lang]["preview"].format(files=count,size=bytes_/1048576))
            except Exception:self.cache_info.setText("")
        else:self.cache_info.setText("")

    def open_settings(self):
        try:
            root=safe_install(self.target())
            exe=root/".venv/Scripts/pythonw.exe"
            if not exe.is_file():exe=root/".venv/Scripts/python.exe"
            if not exe.is_file():raise MaintenanceError("Fairy runtime unavailable.")
            subprocess.Popen([str(exe),"-m","fairy.ui.hdd_preflight"],cwd=str(root),
                             creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        except Exception as exc:
            QMessageBox.warning(self,"FAIRY",str(exc))

    def open_updates(self,auto=False):
        if not installed_state(self.target()):return
        panel=self._update_panel
        if panel is not None:
            if not auto:
                panel.show();panel.raise_()
                panel.check_now()
            return
        panel=FairyUpdateDialog(self.target(),self.settings,self.lang,auto=auto,parent=self)
        self._update_panel=panel
        panel.finished.connect(lambda _result,p=panel:self._forget_update_panel(p))
        if not auto:
            panel.show()
        # Auto-check starts on the worker shortly after creation.

    def _forget_update_panel(self,panel):
        if self._update_panel is panel:
            self._update_panel=None
        panel.deleteLater()

    def auto_check_updates_once(self):
        if not self.settings.value("updates_auto_check",True,type=bool):
            return
        if not self.settings.value("fairy_updates_auto_check",True,type=bool):
            return
        from hdd.ui.fairy_module_dialog import feed_url
        if installed_state(self.target()) and feed_url(self.settings):
            self.open_updates(auto=True)

    def request(self,kind):
        if self.worker is not None and self.worker.isRunning():
            return
        t=TEXT[self.lang]
        if kind not in ("cache","reset","uninstall"):
            return
        text=t["confirm_cache"] if kind=="cache" else t["confirm_"+kind]
        labels={
          "en-US":{"cache":"CLEAR CACHE","reset":"RESET FAIRY","uninstall":"UNINSTALL FAIRY",
                    "cancel":"CANCEL","force":"FORCE CLOSE FAIRY"},
          "pt-BR":{"cache":"LIMPAR CACHE","reset":"RESTAURAR FAIRY","uninstall":"DESINSTALAR FAIRY",
                    "cancel":"CANCELAR","force":"FORÇAR FECHAMENTO"},
          "es-ES":{"cache":"LIMPIAR CACHÉ","reset":"RESTABLECER FAIRY","uninstall":"DESINSTALAR FAIRY",
                    "cancel":"CANCELAR","force":"FORZAR CIERRE"},
        }[self.lang]
        dialog=QMessageBox(self)
        dialog.setWindowTitle(t["title"])
        dialog.setIcon(QMessageBox.Icon.Warning if kind!="cache" else QMessageBox.Icon.Question)
        dialog.setText(text)
        action=dialog.addButton(labels[kind],
            QMessageBox.ButtonRole.DestructiveRole if kind!="cache"
            else QMessageBox.ButtonRole.AcceptRole)
        dialog.addButton(labels["cancel"],QMessageBox.ButtonRole.RejectRole)
        dialog.exec()
        if dialog.clickedButton() is not action:
            return
        self._start_maintenance(kind,False)

    def _start_maintenance(self,kind,force_close=False):
        if self.worker is not None:
            return
        self._pending_force=None
        self.worker=MaintenanceWorker(self.target(),kind,force_close,parent=self)
        worker=self.worker
        worker.finished_result.connect(self.finished)
        worker.finished.connect(lambda w=worker:self._worker_done(w))
        worker.start()
        self.message.setText(TEXT[self.lang]["running"])
        self.refresh()

    def _worker_done(self,worker):
        if self.worker is worker:
            self.worker=None
        worker.deleteLater()
        self.refresh()
        if self._pending_force is not None:
            request=self._pending_force
            self._pending_force=None
            QTimer.singleShot(0,lambda k=request:self._offer_force(k))

    def _offer_force(self,kind):
        if self.worker is not None:
            return
        caption={
          "en-US":("Fairy is still running. Force-close ONLY the installed Fairy, then retry?",
                   "FORCE CLOSE FAIRY","CANCEL"),
          "pt-BR":("A Fairy ainda está aberta. Forçar o encerramento SOMENTE da Fairy instalada e tentar de novo?",
                   "FORÇAR FECHAMENTO","CANCELAR"),
          "es-ES":("Fairy sigue ejecutándose. ¿Forzar el cierre SOLO de Fairy instalada y reintentar?",
                   "FORZAR CIERRE","CANCELAR"),
        }[self.lang]
        popup=QMessageBox(self)
        popup.setWindowTitle(TEXT[self.lang]["title"])
        popup.setIcon(QMessageBox.Icon.Warning)
        popup.setText(caption[0])
        force=popup.addButton(caption[1],QMessageBox.ButtonRole.DestructiveRole)
        popup.addButton(caption[2],QMessageBox.ButtonRole.RejectRole)
        popup.exec()
        if popup.clickedButton() is force:
            self._start_maintenance(kind,True)

    def finished(self,status,result):
        success=status=="ok"
        self.message.setText(
            (TEXT[self.lang]["done"]+" " if success else TEXT[self.lang]["fail"])+result)
        if status=="busy" and self.worker is not None:
            self._pending_force=self.worker.kind
        if success and self.worker is not None and self.worker.kind in ("reset","uninstall"):
            try:
                windows_autostart.set_fairy_enabled(self.settings,False)
                self.settings.remove(windows_autostart.FAIRY_CHOICE_SET)
                self.settings.remove(windows_autostart.FAIRY_PREF)
                self.settings.sync()
            except (OSError,RuntimeError) as exc:
                self.message.setText(
                    self.message.text()+" / Windows startup: "+str(exc))
        if success:
            self.installation_changed.emit()

    def closeEvent(self,event):
        if self.worker is not None and self.worker.isRunning():
            self.message.setText(TEXT[self.lang]["running"])
            event.ignore()
            return
        super().closeEvent(event)
